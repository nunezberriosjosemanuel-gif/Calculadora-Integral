package com.calculadora.utils;

public final class Constants {

    public static final String VARIABLE_X = "x";

    private Constants() {
    }
}

