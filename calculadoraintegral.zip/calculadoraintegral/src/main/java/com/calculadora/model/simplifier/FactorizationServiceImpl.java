package com.calculadora.model.simplifier;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Implementación de referencia de {@link FactorizationService}.
 *
 * Cubre, con reconocimiento por patrones de texto, los casos más frecuentes
 * del formulario (factor común, diferencia de cuadrados, trinomio cuadrado
 * perfecto, trinomio x²+bx+c y suma/diferencia de cubos). Los casos que
 * requieren álgebra entera más general (agrupación, trinomio ax²+bx+c
 * arbitrario, cubo perfecto de binomio, potencias impares n-ésimas) quedan
 * documentados como extensión futura -- ver "Plan de migración" -- y hoy
 * delegan al {@link Factorization} legado cuando aplica un caso trivial
 * conocido, o devuelven {@link Optional#empty()} en caso contrario.
 */
public class FactorizationServiceImpl implements FactorizationService {

    private final Factorization legacy = new Factorization();

    @Override
    public Optional<String> factorComun(String expresion) {
        String e = normalizar(expresion);
        Matcher m = Pattern.compile("^(-?\\d+)\\*?([a-zA-Z]\\^?\\d*)\\+(-?\\d+)\\*?([a-zA-Z]\\^?\\d*)$").matcher(e);
        if (!m.matches()) {
            return Optional.empty();
        }
        long a = Long.parseLong(m.group(1));
        long b = Long.parseLong(m.group(3));
        long comun = mcd(a, b);
        if (comun <= 1) {
            return Optional.empty();
        }
        return Optional.of(comun + "*(" + (a / comun) + "*" + m.group(2) + "+" + (b / comun) + "*" + m.group(4) + ")");
    }

    @Override
    public Optional<String> diferenciaDeCuadrados(String expresion) {
        String e = normalizar(expresion);
        Matcher m = Pattern.compile("^x\\^2-(\\d+)$").matcher(e);
        if (!m.matches()) {
            return Optional.empty();
        }
        long n = Long.parseLong(m.group(1));
        long raiz = Math.round(Math.sqrt(n));
        if (raiz * raiz != n) {
            return Optional.empty();
        }
        return Optional.of("(x+" + raiz + ")*(x-" + raiz + ")");
    }

    @Override
    public Optional<String> trinomioCuadradoPerfecto(String expresion) {
        String e = normalizar(expresion);
        Matcher m = Pattern.compile("^x\\^2\\+(\\d+)\\*?x\\+(\\d+)$").matcher(e);
        if (!m.matches()) {
            return Optional.empty();
        }
        long dosB = Long.parseLong(m.group(1));
        long c = Long.parseLong(m.group(2));
        if (dosB % 2 != 0) {
            return Optional.empty();
        }
        long b = dosB / 2;
        if (b * b != c) {
            return Optional.empty();
        }
        return Optional.of("(x+" + b + ")^2");
    }

    @Override
    public Optional<String> trinomioXCuadradoMasBxMasC(String expresion) {
        String e = normalizar(expresion);
        Matcher m = Pattern.compile("^x\\^2([+-]\\d+)\\*?x([+-]\\d+)$").matcher(e);
        if (!m.matches()) {
            return Optional.empty();
        }
        long b = Long.parseLong(m.group(1));
        long c = Long.parseLong(m.group(2));
        for (long r = -Math.abs(c) - 1; r <= Math.abs(c) + 1; r++) {
            if (r == 0 || c % r != 0) {
                continue;
            }
            long s = c / r;
            if (r + s == b) {
                return Optional.of("(x" + conSigno(r) + ")*(x" + conSigno(s) + ")");
            }
        }
        return Optional.empty();
    }

    @Override
    public Optional<String> trinomioAxCuadradoMasBxMasC(String expresion) {
        // Caso general ax^2+bx+c: requiere buscar dos enteros p,q tales que
        // p*q = a*c y p+q = b, para luego dividir por a. Se deja como
        // extensión futura del plan de migración; hoy no se reconoce.
        return Optional.empty();
    }

    @Override
    public Optional<String> sumaODiferenciaDeCubos(String expresion) {
        String e = normalizar(expresion);
        Matcher m = Pattern.compile("^x\\^3([+-])(\\d+)$").matcher(e);
        if (!m.matches()) {
            return Optional.empty();
        }
        long n = Long.parseLong(m.group(2));
        long raiz = Math.round(Math.cbrt(n));
        if (raiz * raiz * raiz != n) {
            return Optional.empty();
        }
        boolean esSuma = m.group(1).equals("+");
        String signoBinomio = esSuma ? "+" : "-";
        String signoMedio = esSuma ? "-" : "+";
        return Optional.of("(x" + signoBinomio + raiz + ")*(x^2" + signoMedio + raiz + "*x+" + (raiz * raiz) + ")");
    }

    @Override
    public Optional<String> cuboPerfectoDeBinomio(String expresion) {
        // Requiere comparar los cuatro términos de un desarrollo cúbico
        // completo (a^3 +/- 3a^2b + 3ab^2 +/- b^3); extensión futura.
        return Optional.empty();
    }

    @Override
    public Optional<String> factorizar(String expresion) {
        return factorComun(expresion)
                .or(() -> diferenciaDeCuadrados(expresion))
                .or(() -> trinomioCuadradoPerfecto(expresion))
                .or(() -> trinomioXCuadradoMasBxMasC(expresion))
                .or(() -> trinomioAxCuadradoMasBxMasC(expresion))
                .or(() -> sumaODiferenciaDeCubos(expresion))
                .or(() -> cuboPerfectoDeBinomio(expresion))
                .or(() -> delegarALegado(expresion));
    }

    private Optional<String> delegarALegado(String expresion) {
        String resultado = legacy.apply(expresion);
        return resultado.equals(expresion) ? Optional.empty() : Optional.of(resultado);
    }

    private static String normalizar(String expresion) {
        return expresion == null ? "" : expresion.replaceAll("\\s+", "");
    }

    private static String conSigno(long v) {
        return v >= 0 ? "+" + v : String.valueOf(v);
    }

    private static long mcd(long a, long b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b != 0) {
            long t = b;
            b = a % b;
            a = t;
        }
        return a == 0 ? 1 : a;
    }
}
