package com.calculadora.services;

import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;

public class IntegralService {

    private final ValidationService validationService;
    private final SolverService solverService;
    private final HistoryService historyService;

    public IntegralService(ValidationService validationService, SolverService solverService,
            HistoryService historyService) {
        this.validationService = validationService;
        this.solverService = solverService;
        this.historyService = historyService;
    }

    public IntegralResponse resolve(IntegralRequest request) {
        validationService.validate(request);
        IntegralResponse response = solverService.solve(request);
        historyService.save(request, response);
        return response;
    }
}
