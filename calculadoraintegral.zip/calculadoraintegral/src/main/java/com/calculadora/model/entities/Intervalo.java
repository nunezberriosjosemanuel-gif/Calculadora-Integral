package com.calculadora.model.entities;

public class Intervalo {

    private final double limiteInferior;
    private final double limiteSuperior;

    public Intervalo(double limiteInferior, double limiteSuperior) {
        this.limiteInferior = limiteInferior;
        this.limiteSuperior = limiteSuperior;
    }

    public double getLimiteInferior() {
        return limiteInferior;
    }

    public double getLimiteSuperior() {
        return limiteSuperior;
    }
}
