package com.calculadora.model.methods;

import net.objecthunter.exp4j.ExpressionBuilder;
import net.objecthunter.exp4j.Expression;
import com.calculadora.utils.ExpressionNormalizer;

/**
 * Integrador simbólico extendido.
 * Soporta: polinomios (x^n), sin, cos, tan, sec, csc, cot, arcsin, arccos, arctan,
 * e^x, exp(kx), ln(x), log(x), sqrt(x), cbrt(x), 1/x, funciones compuestas con
 * coeficiente, fracciones polinómicas simples. Fallback numérico (cuadratura
 * de Gauss–Legendre compuesta) para el resto.
 *
 * @deprecated Motor legado: mezcla parsing de términos, detección de regla,
 * formato LaTeX y fallback numérico en una sola clase (viola SRP). Se
 * mantiene como implementación interna de {@code AntiderivativeMethod}
 * mientras se extrae, método por método, hacia las clases nuevas descritas
 * en el plan de migración ({@code FactorizationService}, estrategias
 * dedicadas por tipo, etc.). No agregar lógica nueva aquí: agregarla en una
 * estrategia nueva registrada en {@code DependencyContainer}.
 */
@Deprecated
public final class AntiderivativeEngine {

    public static class Resultado {
        public final String antiderivadaLatex;
        public final String antiderivadaExpr;
        public final boolean exito;
        public final boolean esNumerica;
        public final String mensajeError;
        /** Lista de pasos por término: {termLatex, antiderivadaTermLatex, nombreRegla} */
        public java.util.List<String[]> terminos = new java.util.ArrayList<>();

        public Resultado(String latex, String expr) {
            this.antiderivadaLatex = latex;
            this.antiderivadaExpr  = expr;
            this.exito      = true;
            this.esNumerica = false;
            this.mensajeError = null;
        }
        public Resultado(String latex, String expr, boolean numerica) {
            this.antiderivadaLatex = latex;
            this.antiderivadaExpr  = expr;
            this.exito      = true;
            this.esNumerica = numerica;
            this.mensajeError = null;
        }
        public Resultado(String error) {
            this.antiderivadaLatex = null;
            this.antiderivadaExpr  = null;
            this.exito      = false;
            this.esNumerica = false;
            this.mensajeError = error;
        }
    }

    // -----------------------------------------------------------------------
    // Punto de entrada principal
    // -----------------------------------------------------------------------
    public static Resultado integrar(String funcion) {
        if (funcion == null || funcion.trim().isEmpty())
            return new Resultado("La función no puede estar vacía.");

        String f = ExpressionNormalizer.forSymbolic(funcion);
        // Multiplicación implícita: 3x -> 3*x, 2sin -> 2*sin, 3(x -> 3*(x
        f = f;
        // pi -> pi ya es reconocido por exp4j; E -> E también

        try {
            return integrarExpr(f);
        } catch (Exception e) {
            return new Resultado("No se pudo procesar: " + funcion);
        }
    }

    // -----------------------------------------------------------------------
    // Descompone la expresión en sumandos y los integra
    // -----------------------------------------------------------------------
    private static Resultado integrarExpr(String expr) {
        java.util.List<String> sumandos = dividirEnSumandos(expr);
        if (sumandos == null || sumandos.isEmpty())
            return new Resultado("Expresión no reconocida: " + expr);

        StringBuilder latexTotal = new StringBuilder();
        StringBuilder exprTotal  = new StringBuilder();
        boolean primero = true;
        boolean algunoNumerico = false;
        Resultado resultado = null;

        java.util.List<String[]> terminos = new java.util.ArrayList<>();

        for (String s : sumandos) {
            String trimmed = s.trim();
            if (trimmed.isEmpty()) continue;
            // Guardar latex original del término para el procedimiento
            String termLatexOrig = termToLatex(trimmed);
            String[] conRegla = integrarTerminoConRegla(trimmed);
            // conRegla = {latexAntiderivada, exprAntiderivada, nombreRegla, esNumerica}
            if (conRegla.length > 3 && Boolean.parseBoolean(conRegla[3])) {
                algunoNumerico = true;
            }
            Resultado r = new Resultado(conRegla[0], conRegla[1]);
            if (!r.exito) return r;

            String lt = r.antiderivadaLatex;
            String et = r.antiderivadaExpr;

            terminos.add(new String[]{termLatexOrig, lt, conRegla[2]});

            if (primero) {
                latexTotal.append(lt);
                exprTotal.append(et);
                primero = false;
            } else {
                if (lt.startsWith("-")) {
                    latexTotal.append(lt);
                    if (et.startsWith("-")) {
                        exprTotal.append(et);
                    } else {
                        exprTotal.append("+").append(et);
                    }
                } else {
                    latexTotal.append("+").append(lt);
                    exprTotal.append("+").append(et);
                }
            }
        }
        if (algunoNumerico) {
            // Al menos un término no tiene antiderivada elemental reconocida:
            // se marca todo el resultado como numérico para que se use la
            // cuadratura de Gauss-Legendre
            Resultado res = new Resultado("\\text{[numérico]}", expr, true);
            return res;
        }
        Resultado res = new Resultado(latexTotal.toString(), exprTotal.toString());
        res.terminos = terminos;
        return res;
    }

    /** Convierte un término de expr a LaTeX legible para mostrar */
    private static String termToLatex(String t) {
        String s = t;
        // coeficiente*x^n → \coef x^{n}
        s = s.replaceAll("\\^\\(([^)]+)\\)", "^{$1}");
        s = s.replaceAll("\\*", "");
        return s;
    }

    /** Integra un término y retorna {latexResult, exprResult, nombreRegla} */
    private static String[] integrarTerminoConRegla(String t) {
        if (t.isEmpty()) return new String[]{"0", "0", "Constante"};

        int signo = 1;
        String orig = t;
        if (t.startsWith("-")) { signo = -1; t = t.substring(1); }
        else if (t.startsWith("+")) { t = t.substring(1); }

        double coef = 1.0;
        String resto = t;
        java.util.regex.Matcher mCoef = java.util.regex.Pattern
                .compile("^(\\d+\\.?\\d*)\\*(.+)$").matcher(t);
        if (mCoef.matches()) {
            coef = Double.parseDouble(mCoef.group(1));
            resto = mCoef.group(2);
        }
        coef *= signo;

        String regla = detectarRegla(resto, coef);
        Resultado r = integrarFormaBase(coef, resto);

        // Si la forma base no fue reconocida (cayó a numérico), intentar
        // resolverla mediante un cambio de variable u = g(x) antes de
        // rendirse a la integración numérica.
        if (r.esNumerica) {
            SubstitutionMethod.Resultado sub = SubstitutionMethod.intentar(coef, resto);
            if (sub != null) {
                return new String[]{
                    sub.antiderivadaLatex,
                    sub.antiderivadaExpr,
                    sub.reglaLatex,
                    "false"
                };
            }
        }

        return new String[]{
            r.exito ? r.antiderivadaLatex : "?",
            r.exito ? r.antiderivadaExpr  : "?",
            regla,
            String.valueOf(r.esNumerica)
        };
    }

    /** Detecta el nombre de la regla de integración para un término base */
    private static String detectarRegla(String f, double coef) {
        if (f.matches("-?\\d+(\\.\\d+)?") || f.equals("pi") || f.equals("π"))
            return "Integral de constante: \\int k\\,dx = kx";
        if (f.equals("x"))
            return "Regla de la potencia: \\int x\\,dx = \\frac{x^{2}}{2}";
        if (f.matches("x\\^\\(?-?\\d+\\.?\\d*(?:/\\d+)?\\)?"))
            return "Regla de la potencia: \\int x^{n}\\,dx = \\frac{x^{n+1}}{n+1}";
        if (f.equals("1/x") || f.matches("1/x\\^\\d+.*"))
            return "Integral logarítmica: \\int \\frac{1}{x}\\,dx = \\ln|x|";
        if (f.equals("sqrt(x)"))
            return "Regla de la potencia: \\int \\sqrt{x}\\,dx = \\frac{2}{3}x^{\\frac{3}{2}}";
        if (f.equals("cbrt(x)"))
            return "Regla de la potencia: \\int \\sqrt[3]{x}\\,dx = \\frac{3}{4}x^{\\frac{4}{3}}";
        if (f.equals("e^x") || f.equals("exp(x)"))
            return "Integral exponencial: \\int e^{x}\\,dx = e^{x}";
        if (f.matches("(?:e\\^|exp)\\(.*\\)"))
            return "Integral exponencial: \\int e^{kx}\\,dx = \\frac{e^{kx}}{k}";
        if (f.matches("\\d+\\.?\\d*\\^x.*") || f.matches("[a-zA-Z]+\\^x"))
            return "Integral exponencial: \\int a^{x}\\,dx = \\frac{a^{x}}{\\ln a}";
        if (f.equals("ln(x)") || f.equals("log(x)"))
            return "Integral de logaritmo: \\int \\ln x\\,dx = x\\ln x - x";
        if (f.equals("sin(x)"))
            return "Integral trigonométrica: \\int \\sin x\\,dx = -\\cos x";
        if (f.equals("cos(x)"))
            return "Integral trigonométrica: \\int \\cos x\\,dx = \\sin x";
        if (f.equals("tan(x)"))
            return "Integral trigonométrica: \\int \\tan x\\,dx = -\\ln|\\cos x|";
        if (f.equals("cot(x)"))
            return "Integral trigonométrica: \\int \\cot x\\,dx = \\ln|\\sin x|";
        if (f.equals("sec(x)"))
            return "Integral trigonométrica: \\int \\sec x\\,dx = \\ln|\\sec x+\\tan x|";
        if (f.equals("csc(x)"))
            return "Integral trigonométrica: \\int \\csc x\\,dx = -\\ln|\\csc x+\\cot x|";
        if (f.matches("sin\\(.*x\\)"))
            return "Regla de sustitución: \\int \\sin(kx)\\,dx = -\\frac{\\cos(kx)}{k}";
        if (f.matches("cos\\(.*x\\)"))
            return "Regla de sustitución: \\int \\cos(kx)\\,dx = \\frac{\\sin(kx)}{k}";
        if (f.matches("cot\\(.*x\\)"))
            return "Regla de sustitución: \\int \\cot(kx)\\,dx = \\frac{1}{k}\\ln|\\sin(kx)|";
        if (f.matches("sec\\(.*x\\)"))
            return "Regla de sustitución: \\int \\sec(kx)\\,dx = \\frac{1}{k}\\ln|\\sec(kx)+\\tan(kx)|";
        if (f.matches("csc\\(.*x\\)"))
            return "Regla de sustitución: \\int \\csc(kx)\\,dx = -\\frac{1}{k}\\ln|\\csc(kx)+\\cot(kx)|";
        if (f.equals("sec(x)^2") || f.equals("sec^2(x)") || f.equals("(sec(x))^2"))
            return "Integral trigonométrica: \\int \\sec^{2} x\\,dx = \\tan x";
        if (f.equals("csc(x)^2") || f.equals("csc^2(x)") || f.equals("(csc(x))^2"))
            return "Integral trigonométrica: \\int \\csc^{2} x\\,dx = -\\cot x";
        if (f.matches(".*arcsin.*") || f.matches(".*asin.*") || f.matches(".*1/sqrt.*"))
            return "Integral trigonométrica inversa: \\int \\frac{1}{\\sqrt{1-x^2}}\\,dx = \\arcsin x";
        if (f.matches(".*arccos.*") || f.matches(".*acos.*"))
            return "Integral trigonométrica inversa: \\int \\frac{-1}{\\sqrt{1-x^2}}\\,dx = \\arccos x";
        if (f.matches(".*arctan.*") || f.matches(".*atan.*") || f.matches(".*1/\\(1.*x.*2.*\\).*"))
            return "Integral trigonométrica inversa: \\int \\frac{1}{1+x^2}\\,dx = \\arctan x";
        if (f.matches("1/\\(\\d+\\.?\\d*\\+x\\^2\\)") || f.matches("1/\\(x\\^2\\+\\d+\\.?\\d*\\)"))
            return "Integral trigonométrica inversa: \\int \\frac{1}{a^2+x^2}\\,dx = \\frac{1}{a}\\arctan\\left(\\frac{x}{a}\\right)";
        if (f.equals("sinh(x)")) return "Integral hiperbólica: \\int \\sinh x\\,dx = \\cosh x";
        if (f.equals("cosh(x)")) return "Integral hiperbólica: \\int \\cosh x\\,dx = \\sinh x";
        if (f.equals("tanh(x)")) return "Integral hiperbólica: \\int \\tanh x\\,dx = \\ln(\\cosh x)";
        if (f.matches("sinh\\(.*x\\)"))
            return "Regla de sustitución: \\int \\sinh(kx)\\,dx = \\frac{1}{k}\\cosh(kx)";
        if (f.matches("cosh\\(.*x\\)"))
            return "Regla de sustitución: \\int \\cosh(kx)\\,dx = \\frac{1}{k}\\sinh(kx)";
        if (f.matches("tanh\\(.*x\\)"))
            return "Regla de sustitución: \\int \\tanh(kx)\\,dx = \\frac{1}{k}\\ln(\\cosh(kx))";
        return "Regla de integración directa";
    }

    private static java.util.List<String> dividirEnSumandos(String expr) {
        java.util.List<String> result = new java.util.ArrayList<>();
        int depth = 0;
        int inicio = 0;
        for (int i = 0; i < expr.length(); i++) {
            char c = expr.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (depth == 0 && (c == '+' || c == '-') && i > 0) {
                result.add(expr.substring(inicio, i));
                inicio = i;
            }
        }
        result.add(expr.substring(inicio));
        return result;
    }

    // -----------------------------------------------------------------------
    // Integrar un término individual (puede tener coeficiente y signo)
    // -----------------------------------------------------------------------
    private static Resultado integrarTermino(String t) {
        if (t.isEmpty()) return new Resultado("0", "0");

        int signo = 1;
        if (t.startsWith("-")) { signo = -1; t = t.substring(1); }
        else if (t.startsWith("+")) { t = t.substring(1); }

        // Extraer coeficiente numérico: "3.5*expr" o "3*expr"
        double coef = 1.0;
        String resto = t;
        java.util.regex.Matcher mCoef = java.util.regex.Pattern
                .compile("^(\\d+\\.?\\d*)\\*(.+)$").matcher(t);
        if (mCoef.matches()) {
            coef = Double.parseDouble(mCoef.group(1));
            resto = mCoef.group(2);
        }
        coef *= signo;

        return integrarFormaBase(coef, resto);
    }

    // -----------------------------------------------------------------------
    // Formas base conocidas — catálogo extendido
    // -----------------------------------------------------------------------
    private static Resultado integrarFormaBase(double coef, String f) {
        Resultado productoPolinomico = integrarProductoPolinomico(coef, f);
        if (productoPolinomico != null) return productoPolinomico;

        // --- Constante numérica pura ---
        if (f.matches("-?\\d+(\\.\\d+)?")) {
            double k = coef * Double.parseDouble(f);
            return termino(k, "x", "x");
        }

        // --- pi como constante ---
        if (f.equals("pi") || f.equals("π")) {
            return termino(coef * Math.PI, "x", "x");
        }

        // --- x ---
        if (f.equals("x")) return termino(coef / 2.0, "x^{2}", "x^2");

        // --- x^n (cualquier exponente real, incluyendo fracciones) ---
        java.util.regex.Matcher mPow = java.util.regex.Pattern
                .compile("^x\\^\\(?(-?\\d+\\.?\\d*(?:/\\d+)?)\\)?$").matcher(f);
        if (mPow.matches()) {
            String expStr = mPow.group(1);
            double n = evaluarFraccion(expStr);
            if (n == -1) return termino(coef, "\\ln|x|", "log(abs(x))");
            double exp = n + 1;
            return termino(coef / exp,
                "x^{" + pasarAFraccionLatex(exp) + "}",
                "x^(" + fmt(exp) + ")");
        }

        // --- 1/x ---
        if (f.equals("1/x")) return termino(coef, "\\ln|x|", "log(abs(x))");

        // --- Fracciones polinómicas simples: 1/(x^n) ---
        java.util.regex.Matcher mFracPow = java.util.regex.Pattern
                .compile("^1/x\\^(\\d+\\.?\\d*)$").matcher(f);
        if (mFracPow.matches()) {
            double n = Double.parseDouble(mFracPow.group(1));
            // ∫ x^(-n) dx = x^(-n+1)/(-n+1)
            double exp = -n + 1;
            if (exp == 0) return termino(coef, "\\ln|x|", "log(abs(x))");
            return termino(coef / exp,
                "x^{" + pasarAFraccionLatex(exp) + "}",
                "x^(" + fmt(exp) + ")");
        }

        // --- sqrt(x) ---
        if (f.equals("sqrt(x)")) return termino(coef * 2.0/3.0, "x^{\\frac{3}{2}}", "x^(1.5)");
        // --- cbrt(x) (raíz cúbica) ---
        if (f.equals("cbrt(x)")) return termino(coef * 3.0/4.0, "x^{\\frac{4}{3}}", "x^(4.0/3.0)");

        Resultado sustitucionTrig = integrarSustitucionTrigonometrica(coef, f);
        if (sustitucionTrig != null) return sustitucionTrig;

        // --- e^x / exp(x) ---
        if (f.equals("e^x") || f.equals("exp(x)")) return termino(coef, "e^{x}", "exp(x)");

        // --- e^(k*x) o exp(k*x) ---
        java.util.regex.Matcher mExpKx = java.util.regex.Pattern
                .compile("^(?:e\\^|exp)\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mExpKx.matches()) {
            double k = Double.parseDouble(mExpKx.group(1));
            return termino(coef / k, "e^{" + fmt(k) + "x}", "exp(" + fmt(k) + "*x)");
        }

        // --- a^x (base arbitraria) ---
        java.util.regex.Matcher mAx = java.util.regex.Pattern
                .compile("^(\\d+\\.?\\d*)\\^x$").matcher(f);
        if (mAx.matches()) {
            double a = Double.parseDouble(mAx.group(1));
            double lna = Math.log(a);
            // ∫ a^x = a^x / ln(a)
            return termino(coef / lna,
                a + "^{x}",
                "pow(" + fmt(a) + ",x)");
        }

        // --- ln(x) / log(x) ---
        if (f.equals("ln(x)") || f.equals("log(x)")) {
            String latex = coef == 1.0 ? "x\\ln(x)-x" : pasarAFraccionLatex(coef) + "(x\\ln(x)-x)";
            String expr  = coef == 1.0 ? "x*log(x)-x" : fmt(coef) + "*(x*log(x)-x)";
            return new Resultado(latex, expr);
        }

        // --- log2(x) ---
        if (f.equals("log2(x)")) {
            double c2 = coef / Math.log(2);
            String latex = pasarAFraccionLatex(c2) + "(x\\ln(x)-x)";
            String expr  = fmt(c2) + "*(x*log(x)-x)";
            return new Resultado(latex, expr);
        }

        // --- Funciones trigonométricas simples ---
        if (f.equals("sin(x)")) return termino(-coef, "\\cos(x)", "cos(x)");
        if (f.equals("cos(x)")) return termino(coef,  "\\sin(x)", "sin(x)");
        if (f.equals("tan(x)")) return termino(-coef, "\\ln|\\cos(x)|", "log(abs(cos(x)))");
        if (f.equals("cot(x)")) return termino(coef,  "\\ln|\\sin(x)|", "log(abs(sin(x)))");

        // sec(x): ∫sec(x)dx = ln|sec(x)+tan(x)|
        if (f.equals("sec(x)")) {
            String latex = pasarAFraccionLatex(coef) + "\\ln|\\sec(x)+\\tan(x)|";
            String expr  = fmt(coef) + "*log(abs(1/cos(x)+tan(x)))";
            return coef == 1.0
                ? new Resultado("\\ln|\\sec(x)+\\tan(x)|", "log(abs(1/cos(x)+tan(x)))")
                : new Resultado(latex, expr);
        }

        // csc(x): ∫csc(x)dx = -ln|csc(x)+cot(x)|
        if (f.equals("csc(x)")) {
            return termino(-coef, "\\ln|\\csc(x)+\\cot(x)|", "log(abs(1/sin(x)+cos(x)/sin(x)))");
        }

        // --- sin(kx) / cos(kx) / tan(kx) ---
        java.util.regex.Matcher mSin = java.util.regex.Pattern
                .compile("^sin\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mSin.matches()) {
            double k = Double.parseDouble(mSin.group(1));
            return termino(-coef/k, "\\cos(" + fmt(k) + "x)", "cos(" + fmt(k) + "*x)");
        }
        java.util.regex.Matcher mCos = java.util.regex.Pattern
                .compile("^cos\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mCos.matches()) {
            double k = Double.parseDouble(mCos.group(1));
            return termino(coef/k, "\\sin(" + fmt(k) + "x)", "sin(" + fmt(k) + "*x)");
        }
        java.util.regex.Matcher mTan = java.util.regex.Pattern
                .compile("^tan\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mTan.matches()) {
            double k = Double.parseDouble(mTan.group(1));
            return termino(-coef/k, "\\ln|\\cos(" + fmt(k) + "x)|", "log(abs(cos(" + fmt(k) + "*x)))");
        }
        java.util.regex.Matcher mCotK = java.util.regex.Pattern
                .compile("^cot\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mCotK.matches()) {
            double k = Double.parseDouble(mCotK.group(1));
            return termino(coef/k, "\\ln|\\sin(" + fmt(k) + "x)|", "log(abs(sin(" + fmt(k) + "*x)))");
        }
        java.util.regex.Matcher mSecK = java.util.regex.Pattern
                .compile("^sec\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mSecK.matches()) {
            double k = Double.parseDouble(mSecK.group(1));
            return termino(coef/k, "\\ln|\\sec(" + fmt(k) + "x)+\\tan(" + fmt(k) + "x)|",
                    "log(abs(1/cos(" + fmt(k) + "*x)+tan(" + fmt(k) + "*x)))");
        }
        java.util.regex.Matcher mCscK = java.util.regex.Pattern
                .compile("^csc\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mCscK.matches()) {
            double k = Double.parseDouble(mCscK.group(1));
            return termino(-coef/k, "\\ln|\\csc(" + fmt(k) + "x)+\\cot(" + fmt(k) + "x)|",
                    "log(abs(1/sin(" + fmt(k) + "*x)+cos(" + fmt(k) + "*x)/sin(" + fmt(k) + "*x)))");
        }

        // --- Potencias de trig: sin^2(x) y cos^2(x) via identidad ---
        if (f.equals("sin^2(x)") || f.equals("(sin(x))^2")) {
            // ∫sin²(x) = x/2 - sin(2x)/4
            String latex = coef == 1.0
                ? "\\frac{x}{2}-\\frac{\\sin(2x)}{4}"
                : pasarAFraccionLatex(coef) + "\\left(\\frac{x}{2}-\\frac{\\sin(2x)}{4}\\right)";
            String expr = fmt(coef) + "*(x/2-sin(2*x)/4)";
            return new Resultado(latex, expr);
        }
        if (f.equals("cos^2(x)") || f.equals("(cos(x))^2")) {
            // ∫cos²(x) = x/2 + sin(2x)/4
            String latex = coef == 1.0
                ? "\\frac{x}{2}+\\frac{\\sin(2x)}{4}"
                : pasarAFraccionLatex(coef) + "\\left(\\frac{x}{2}+\\frac{\\sin(2x)}{4}\\right)";
            String expr = fmt(coef) + "*(x/2+sin(2*x)/4)";
            return new Resultado(latex, expr);
        }

        // --- Funciones trigonométricas inversas ---
        if (f.equals("sec^2(x)") || f.equals("(sec(x))^2")) {
            return termino(coef, "\\tan(x)", "tan(x)");
        }
        if (f.equals("csc^2(x)") || f.equals("(csc(x))^2")) {
            return termino(-coef, "\\cot(x)", "1/tan(x)");
        }
        if (f.equals("sin^3(x)") || f.equals("(sin(x))^3")) {
            String latex = coef == 1.0
                ? "-\\cos(x)+\\frac{\\cos^{3}(x)}{3}"
                : pasarAFraccionLatex(coef) + "\\left(-\\cos(x)+\\frac{\\cos^{3}(x)}{3}\\right)";
            String expr = fmt(coef) + "*(-cos(x)+(cos(x)^3)/3)";
            return new Resultado(latex, expr);
        }
        if (f.equals("cos^3(x)") || f.equals("(cos(x))^3")) {
            String latex = coef == 1.0
                ? "\\sin(x)-\\frac{\\sin^{3}(x)}{3}"
                : pasarAFraccionLatex(coef) + "\\left(\\sin(x)-\\frac{\\sin^{3}(x)}{3}\\right)";
            String expr = fmt(coef) + "*(sin(x)-(sin(x)^3)/3)";
            return new Resultado(latex, expr);
        }
        if (f.equals("sin^4(x)") || f.equals("(sin(x))^4")) {
            String latex = coef == 1.0
                ? "\\frac{3x}{8}-\\frac{\\sin(2x)}{4}+\\frac{\\sin(4x)}{32}"
                : pasarAFraccionLatex(coef) + "\\left(\\frac{3x}{8}-\\frac{\\sin(2x)}{4}+\\frac{\\sin(4x)}{32}\\right)";
            String expr = fmt(coef) + "*(3*x/8-sin(2*x)/4+sin(4*x)/32)";
            return new Resultado(latex, expr);
        }
        if (f.equals("cos^4(x)") || f.equals("(cos(x))^4")) {
            String latex = coef == 1.0
                ? "\\frac{3x}{8}+\\frac{\\sin(2x)}{4}+\\frac{\\sin(4x)}{32}"
                : pasarAFraccionLatex(coef) + "\\left(\\frac{3x}{8}+\\frac{\\sin(2x)}{4}+\\frac{\\sin(4x)}{32}\\right)";
            String expr = fmt(coef) + "*(3*x/8+sin(2*x)/4+sin(4*x)/32)";
            return new Resultado(latex, expr);
        }
        if (f.equals("(sin(x))^2*(cos(x))^2") || f.equals("sin^2(x)*cos^2(x)")) {
            String latex = coef == 1.0
                ? "\\frac{x}{8}-\\frac{\\sin(4x)}{32}"
                : pasarAFraccionLatex(coef) + "\\left(\\frac{x}{8}-\\frac{\\sin(4x)}{32}\\right)";
            String expr = fmt(coef) + "*(x/8-sin(4*x)/32)";
            return new Resultado(latex, expr);
        }

        Resultado productoTrig = integrarProductoTrigonometrico(coef, f);
        if (productoTrig != null) return productoTrig;

        Resultado parciales = integrarFraccionesParcialesLineales(coef, f);
        if (parciales != null) return parciales;

        if (f.equals("asin(x)") || f.equals("arcsin(x)")) {
            // ∫arcsin(x) = x·arcsin(x) + sqrt(1-x²)
            return new Resultado(
                "x\\arcsin(x)+\\sqrt{1-x^{2}}",
                "x*asin(x)+sqrt(1-x^2)");
        }
        if (f.equals("acos(x)") || f.equals("arccos(x)")) {
            return new Resultado(
                "x\\arccos(x)-\\sqrt{1-x^{2}}",
                "x*acos(x)-sqrt(1-x^2)");
        }
        if (f.equals("atan(x)") || f.equals("arctan(x)")) {
            // ∫arctan(x) = x·arctan(x) - ln(1+x²)/2
            return new Resultado(
                "x\\arctan(x)-\\frac{\\ln(1+x^{2})}{2}",
                "x*atan(x)-log(1+x^2)/2");
        }

        // --- 1/(1+x^2) -> arctan ---
        if (f.equals("1/(1+x^2)") || f.equals("1/(x^2+1)")) {
            return termino(coef, "\\arctan(x)", "atan(x)");
        }

        // --- 1/(a^2+x^2) -> (1/a)arctan(x/a)  (forma generalizada) ---
        java.util.regex.Matcher mArctanGenA = java.util.regex.Pattern
                .compile("^1/\\((\\d+\\.?\\d*)\\+x\\^2\\)$").matcher(f);
        java.util.regex.Matcher mArctanGenB = java.util.regex.Pattern
                .compile("^1/\\(x\\^2\\+(\\d+\\.?\\d*)\\)$").matcher(f);
        if (mArctanGenA.matches() || mArctanGenB.matches()) {
            double a2 = Double.parseDouble((mArctanGenA.matches() ? mArctanGenA : mArctanGenB).group(1));
            double a = Math.sqrt(a2);
            return termino(coef / a, "\\arctan\\left(\\frac{x}{" + fmt(a) + "}\\right)",
                    "atan(x/(" + fmt(a) + "))");
        }

        // --- 1/sqrt(1-x^2) -> arcsin ---
        if (f.equals("1/sqrt(1-x^2)")) {
            return termino(coef, "\\arcsin(x)", "asin(x)");
        }

        // --- 1/sqrt(a^2-x^2) -> arcsin(x/a)  (forma generalizada) ---
        java.util.regex.Matcher mArcsinGen = java.util.regex.Pattern
                .compile("^1/sqrt\\((\\d+\\.?\\d*)-x\\^2\\)$").matcher(f);
        if (mArcsinGen.matches()) {
            double a2 = Double.parseDouble(mArcsinGen.group(1));
            double a = Math.sqrt(a2);
            return termino(coef, "\\arcsin\\left(\\frac{x}{" + fmt(a) + "}\\right)",
                    "asin(x/(" + fmt(a) + "))");
        }

        // --- arcsin(kx) / arccos(kx) / arctan(kx) ---
        java.util.regex.Matcher mAsinK = java.util.regex.Pattern
                .compile("^(?:asin|arcsin)\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mAsinK.matches()) {
            double k = Double.parseDouble(mAsinK.group(1));
            String kx = fmt(k) + "x", kxE = fmt(k) + "*x";
            String inner = "x\\arcsin(" + kx + ")+\\frac{\\sqrt{1-" + fmt(k * k) + "x^{2}}}{" + fmt(k) + "}";
            String innerE = "x*asin(" + kxE + ")+sqrt(1-(" + fmt(k * k) + ")*x^2)/(" + fmt(k) + ")";
            return coef == 1.0 ? new Resultado(inner, innerE)
                    : new Resultado(pasarAFraccionLatex(coef) + "\\left(" + inner + "\\right)",
                            fmt(coef) + "*(" + innerE + ")");
        }
        java.util.regex.Matcher mAcosK = java.util.regex.Pattern
                .compile("^(?:acos|arccos)\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mAcosK.matches()) {
            double k = Double.parseDouble(mAcosK.group(1));
            String kx = fmt(k) + "x", kxE = fmt(k) + "*x";
            String inner = "x\\arccos(" + kx + ")-\\frac{\\sqrt{1-" + fmt(k * k) + "x^{2}}}{" + fmt(k) + "}";
            String innerE = "x*acos(" + kxE + ")-sqrt(1-(" + fmt(k * k) + ")*x^2)/(" + fmt(k) + ")";
            return coef == 1.0 ? new Resultado(inner, innerE)
                    : new Resultado(pasarAFraccionLatex(coef) + "\\left(" + inner + "\\right)",
                            fmt(coef) + "*(" + innerE + ")");
        }
        java.util.regex.Matcher mAtanK = java.util.regex.Pattern
                .compile("^(?:atan|arctan)\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mAtanK.matches()) {
            double k = Double.parseDouble(mAtanK.group(1));
            String kx = fmt(k) + "x", kxE = fmt(k) + "*x";
            String inner = "x\\arctan(" + kx + ")-\\frac{\\ln(1+" + fmt(k * k) + "x^{2})}{" + fmt(2 * k) + "}";
            String innerE = "x*atan(" + kxE + ")-log(1+(" + fmt(k * k) + ")*x^2)/(" + fmt(2 * k) + ")";
            return coef == 1.0 ? new Resultado(inner, innerE)
                    : new Resultado(pasarAFraccionLatex(coef) + "\\left(" + inner + "\\right)",
                            fmt(coef) + "*(" + innerE + ")");
        }

        // --- sinh / cosh / tanh ---
        if (f.equals("sinh(x)")) return termino(coef, "\\cosh(x)", "cosh(x)");
        if (f.equals("cosh(x)")) return termino(coef, "\\sinh(x)", "sinh(x)");
        if (f.equals("tanh(x)")) return termino(coef, "\\ln(\\cosh(x))", "log(cosh(x))");

        // --- sinh(kx) / cosh(kx) / tanh(kx) ---
        java.util.regex.Matcher mSinhK = java.util.regex.Pattern
                .compile("^sinh\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mSinhK.matches()) {
            double k = Double.parseDouble(mSinhK.group(1));
            return termino(coef/k, "\\cosh(" + fmt(k) + "x)", "cosh(" + fmt(k) + "*x)");
        }
        java.util.regex.Matcher mCoshK = java.util.regex.Pattern
                .compile("^cosh\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mCoshK.matches()) {
            double k = Double.parseDouble(mCoshK.group(1));
            return termino(coef/k, "\\sinh(" + fmt(k) + "x)", "sinh(" + fmt(k) + "*x)");
        }
        java.util.regex.Matcher mTanhK = java.util.regex.Pattern
                .compile("^tanh\\((-?\\d+\\.?\\d*)\\*x\\)$").matcher(f);
        if (mTanhK.matches()) {
            double k = Double.parseDouble(mTanhK.group(1));
            return termino(coef/k, "\\ln(\\cosh(" + fmt(k) + "x))", "log(cosh(" + fmt(k) + "*x))");
        }

        // Forma no reconocida: intentar integración numérica simbólica
        return new Resultado("\\text{[numérico]}", f, true);
    }

    private static Resultado integrarProductoPolinomico(double coef, String f) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^x\\*\\(x([+-]\\d+(?:\\.\\d+)?)\\)$")
                .matcher(f);
        if (!m.matches()) return null;

        double c = Double.parseDouble(m.group(1));
        String latex = pasarAFraccionLatex(coef / 3.0) + "x^{3}"
                + (coef * c / 2.0 < 0 ? "" : "+")
                + pasarAFraccionLatex(coef * c / 2.0) + "x^{2}";
        String expr = "(" + fmtExacto(coef / 3.0) + ")*x^3+("
                + fmtExacto(coef * c / 2.0) + ")*x^2";
        return new Resultado(latex, expr);
    }

    private static Resultado integrarSustitucionTrigonometrica(double coef, String f) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^sqrt\\((\\d+(?:\\.\\d+)?)\\-x\\^2\\)$")
                .matcher(f);
        if (m.matches()) {
            double a2 = Double.parseDouble(m.group(1));
            double a = Math.sqrt(a2);
            String inside = fmt(a2) + "-x^2";
            String latex = pasarAFraccionLatex(coef) + "\\left(\\frac{x}{2}\\sqrt{" + fmt(a2)
                    + "-x^{2}}+\\frac{" + fmt(a2) + "}{2}\\arcsin\\left(\\frac{x}{"
                    + fmt(a) + "}\\right)\\right)";
            String expr = fmt(coef) + "*(x/2*sqrt(" + inside + ")+" + fmt(a2)
                    + "/2*asin(x/" + fmt(a) + "))";
            return new Resultado(latex, expr);
        }

        m = java.util.regex.Pattern
                .compile("^sqrt\\((\\d+(?:\\.\\d+)?)\\+x\\^2\\)$")
                .matcher(f);
        if (m.matches()) {
            double a2 = Double.parseDouble(m.group(1));
            String inside = "x^2+" + fmt(a2);
            String latex = pasarAFraccionLatex(coef) + "\\left(\\frac{x}{2}\\sqrt{x^{2}+"
                    + fmt(a2) + "}+\\frac{" + fmt(a2)
                    + "}{2}\\ln\\left|x+\\sqrt{x^{2}+" + fmt(a2) + "}\\right|\\right)";
            String expr = fmt(coef) + "*(x/2*sqrt(" + inside + ")+" + fmt(a2)
                    + "/2*log(abs(x+sqrt(" + inside + "))))";
            return new Resultado(latex, expr);
        }

        m = java.util.regex.Pattern
                .compile("^sqrt\\(x\\^2\\-(\\d+(?:\\.\\d+)?)\\)$")
                .matcher(f);
        if (m.matches()) {
            double a2 = Double.parseDouble(m.group(1));
            String inside = "x^2-" + fmt(a2);
            String latex = pasarAFraccionLatex(coef) + "\\left(\\frac{x}{2}\\sqrt{x^{2}-"
                    + fmt(a2) + "}-\\frac{" + fmt(a2)
                    + "}{2}\\ln\\left|x+\\sqrt{x^{2}-" + fmt(a2) + "}\\right|\\right)";
            String expr = fmt(coef) + "*(x/2*sqrt(" + inside + ")-" + fmt(a2)
                    + "/2*log(abs(x+sqrt(" + inside + "))))";
            return new Resultado(latex, expr);
        }
        return null;
    }

    private static Resultado integrarProductoTrigonometrico(double coef, String f) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^sin\\((-?\\d+(?:\\.\\d+)?)\\*x\\)\\*sin\\((-?\\d+(?:\\.\\d+)?)\\*x\\)$")
                .matcher(f);
        if (m.matches()) {
            double a = Double.parseDouble(m.group(1));
            double b = Double.parseDouble(m.group(2));
            double c1 = coef * 0.5;
            double k1 = a - b;
            double k2 = a + b;
            String latex = pasarAFraccionLatex(coef) + "\\frac{1}{2}\\left(\\int\\cos(" + fmt(k1)
                    + "x)\\,dx-\\int\\cos(" + fmt(k2) + "x)\\,dx\\right)";
            String expr = "";
            if (Math.abs(k1) > 1e-12) {
                expr += fmt(c1 / k1) + "*sin(" + fmt(k1) + "*x)";
            } else {
                expr += fmt(c1) + "*x";
            }
            expr += "-" + fmt(c1 / k2) + "*sin(" + fmt(k2) + "*x)";
            return new Resultado(latex, expr);
        }
        return null;
    }

    private static Resultado integrarFraccionesParcialesLineales(double coef, String f) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^(.+)/\\(\\((-?\\d*(?:\\.\\d+)?)\\*?x([+-]\\d+(?:\\.\\d+)?)?\\)\\*\\((-?\\d*(?:\\.\\d+)?)\\*?x([+-]\\d+(?:\\.\\d+)?)?\\)\\)$")
                .matcher(f);
        if (!m.matches()) {
            return null;
        }
        double[] num = parseLineal(m.group(1));
        if (!Double.isFinite(num[0]) || !Double.isFinite(num[1])) {
            return null;
        }
        double a1 = parseCoeficienteX(m.group(2));
        double b1 = m.group(3) == null ? 0.0 : Double.parseDouble(m.group(3));
        double a2 = parseCoeficienteX(m.group(4));
        double b2 = m.group(5) == null ? 0.0 : Double.parseDouble(m.group(5));
        double det = a2 * b1 - a1 * b2;
        if (Math.abs(det) < 1e-12 || Math.abs(a1) < 1e-12 || Math.abs(a2) < 1e-12) {
            return null;
        }
        double p = coef * num[0];
        double q = coef * num[1];
        double A = (p * b1 - q * a1) / det;
        double B = (q * a2 - p * b2) / det;
        double c1 = A / a1;
        double c2 = B / a2;
        String factor1 = factorLineal(a1, b1);
        String factor2 = factorLineal(a2, b2);
        String latex = pasarAFraccionLatex(c1) + "\\ln|" + factor1 + "|"
                + (c2 < 0 ? "" : "+") + pasarAFraccionLatex(c2) + "\\ln|" + factor2 + "|";
        String expr = "(" + fmtExacto(c1) + ")*log(abs(" + factor1 + "))"
                + "+(" + fmtExacto(c2) + ")*log(abs(" + factor2 + "))";
        return new Resultado(latex, expr);
    }

    private static double[] parseLineal(String raw) {
        if (raw.equals("x")) return new double[]{1.0, 0.0};
        if (raw.matches("-?\\d+(?:\\.\\d+)?")) return new double[]{0.0, Double.parseDouble(raw)};
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^(-?\\d*(?:\\.\\d+)?)\\*?x([+-]\\d+(?:\\.\\d+)?)?$")
                .matcher(raw);
        if (!m.matches()) return new double[]{Double.NaN, Double.NaN};
        return new double[]{
                parseCoeficienteX(m.group(1)),
                m.group(2) == null ? 0.0 : Double.parseDouble(m.group(2))
        };
    }

    private static double parseCoeficienteX(String raw) {
        if (raw == null || raw.isEmpty() || raw.equals("+")) return 1.0;
        if (raw.equals("-")) return -1.0;
        return Double.parseDouble(raw);
    }

    private static String factorLineal(double a, double b) {
        String xPart;
        if (Math.abs(a - 1.0) < 1e-12) xPart = "x";
        else if (Math.abs(a + 1.0) < 1e-12) xPart = "-x";
        else xPart = fmt(a) + "*x";
        if (Math.abs(b) < 1e-12) return xPart;
        return xPart + signo(b);
    }

    private static String signo(double v) {
        if (v < 0) return fmt(v);
        return "+" + fmt(v);
    }

    // -----------------------------------------------------------------------
    // Helper para construir Resultado  coef * expr
    // -----------------------------------------------------------------------
    private static Resultado termino(double coef, String latexExpr, String evalExpr) {
        String latex, eval;
        if (Math.abs(coef - 1.0) < 1e-12) {
            latex = latexExpr; eval = evalExpr;
        } else if (Math.abs(coef + 1.0) < 1e-12) {
            latex = "-" + latexExpr; eval = "-" + evalExpr;
        } else {
            String cL = pasarAFraccionLatex(coef);
            // Para la expresión evaluable, usar fracción exacta en lugar de decimal
            String cE = fmtExacto(coef);
            latex = cL + latexExpr;
            eval  = "(" + cE + ")*" + evalExpr;
        }
        return new Resultado(latex, eval);
    }

    /** Representa el coeficiente como fracción exacta para evitar errores de punto flotante */
    public static String fmtExacto(double decimal) {
        if (Double.isNaN(decimal) || Double.isInfinite(decimal)) return fmt(decimal);
        if (decimal == Math.floor(decimal) && Math.abs(decimal) < 1e9)
            return String.valueOf((long) decimal);

        boolean neg = decimal < 0;
        double num = Math.abs(decimal);
        double tol = 1.0e-9;
        double h1 = 1, h2 = 0, k1 = 0, k2 = 1, b = num;
        do {
            double a = Math.floor(b);
            double aux = h1; h1 = a*h1+h2; h2 = aux;
            aux = k1; k1 = a*k1+k2; k2 = aux;
            b = 1.0/(b-a);
        } while (Math.abs(num - h1/k1) > num*tol && k1 < 1e6);

        long numerador = (long) h1, denominador = (long) k1;
        String signo = neg ? "-" : "";
        if (denominador == 1) return signo + numerador;
        return signo + numerador + ".0/" + denominador + ".0";
    }

    // -----------------------------------------------------------------------
    // Integración numérica: cuadratura de Gauss–Legendre compuesta (5 puntos
    // por subintervalo, 2000 subintervalos = 10000 evaluaciones), en
    // reemplazo de la antigua Regla de Simpson.
    // -----------------------------------------------------------------------
    private static final double[] GL5_NODOS = {
        -0.9061798459386640, -0.5384693101056831, 0.0,
         0.5384693101056831,  0.9061798459386640
    };
    private static final double[] GL5_PESOS = {
        0.2369268850561891, 0.4786286704993665, 0.5688888888888889,
        0.4786286704993665, 0.2369268850561891
    };

    public static double integrarNumericamente(String funcion, double a, double b) {
        try {
            Expression expr = new ExpressionBuilder(ExpressionNormalizer.forEvaluation(funcion)).variable("x").build();
            int subintervalos = com.calculadora.config.AppConfig.NUMERIC_QUADRATURE_SUBINTERVALS;
            double h = (b - a) / subintervalos;
            double total = 0;
            for (int i = 0; i < subintervalos; i++) {
                double x0 = a + i * h;
                double x1 = x0 + h;
                double mid = (x0 + x1) / 2.0;
                double halfLen = (x1 - x0) / 2.0;
                double sub = 0;
                for (int k = 0; k < GL5_NODOS.length; k++) {
                    double x = mid + halfLen * GL5_NODOS[k];
                    double fx = expr.setVariable("x", x).evaluate();
                    if (!Double.isFinite(fx)) continue;
                    sub += GL5_PESOS[k] * fx;
                }
                total += sub * halfLen;
            }
            return total;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    // -----------------------------------------------------------------------
    // Evaluar antiderivada en un punto — con corrección de redondeo
    // -----------------------------------------------------------------------
    public static double evaluar(String exprEvaluable, double x) {
        double raw = new ExpressionBuilder(ExpressionNormalizer.forEvaluation(exprEvaluable))
                .variable("x").build()
                .setVariable("x", x)
                .evaluate();
        // Redondear a fracción racional simple si está muy cerca (evita errores de punto flotante)
        return redondearRacional(raw);
    }

    /**
     * Redondea a la fracción p/q más simple con denominador pequeño (<= 1000)
     * si el error es < 1e-9. Su único propósito es limpiar ruido de punto
     * flotante (ej. 2.9999999999 -> 3); NO debe usarse para forzar números
     * irracionales (ln 2, sqrt 2, etc.) a una fracción — con un denominador
     * demasiado grande cualquier número puede "aproximarse" y el resultado
     * deja de ser matemáticamente representativo (bug: fracciones como
     * 25469/36744 en vez de mostrar el decimal).
     */
    private static double redondearRacional(double v) {
        if (!Double.isFinite(v)) return v;
        for (int denom = 1; denom <= 1000; denom++) {
            double numer = Math.round(v * denom);
            double candidate = numer / denom;
            if (Math.abs(candidate - v) < 1e-9) return candidate;
        }
        return v;
    }

    // -----------------------------------------------------------------------
    // Utilidades
    // -----------------------------------------------------------------------
    private static double evaluarFraccion(String s) {
        if (s.contains("/")) {
            String[] parts = s.split("/");
            return Double.parseDouble(parts[0]) / Double.parseDouble(parts[1]);
        }
        return Double.parseDouble(s);
    }

    public static String pasarAFraccionLatex(double decimal) {
        if (Double.isNaN(decimal) || Double.isInfinite(decimal)) return "\\infty";
        if (decimal == Math.floor(decimal) && Math.abs(decimal) < 1e9)
            return String.valueOf((long) decimal);

        // Si el número es (aproximadamente) un múltiplo racional simple de pi
        // o de e, se muestra usando el símbolo correspondiente en vez de la
        // fracción racional que lo aproxima (ej: 51819/32989 -> \frac{1}{2}\pi,
        // 103993/33102 -> \pi, 49171/18089 -> e)
        String formaPi = intentarFormaConstante(decimal, Math.PI, "\\pi");
        if (formaPi != null) return formaPi;

        String formaE = intentarFormaConstante(decimal, Math.E, "e");
        if (formaE != null) return formaE;

        boolean neg = decimal < 0;
        double num = Math.abs(decimal);
        double tol = 1.0e-9;
        // Límite de "fracción razonable": si no existe una fracción de
        // denominador pequeño que reproduzca el valor con precisión, no
        // tiene sentido mostrar una fracción "fea" (p. ej. 25469/36744 para
        // aproximar ln(2), que es irracional) — se prefiere el decimal.
        final long MAX_DEN_RAZONABLE = 1000;
        double h1 = 1, h2 = 0, k1 = 0, k2 = 1, b = num;
        do {
            double a = Math.floor(b);
            double aux = h1; h1 = a*h1+h2; h2 = aux;
            aux = k1; k1 = a*k1+k2; k2 = aux;
            if (b - a < 1e-12) break; // evita división por cero en el último paso
            b = 1.0/(b-a);
        } while (Math.abs(num - h1/k1) > num*tol && k1 < MAX_DEN_RAZONABLE);

        long numerador = (long) h1, denominador = (long) k1;
        boolean fraccionValida = denominador >= 1 && denominador <= MAX_DEN_RAZONABLE
                && Math.abs(num - (double) numerador / denominador) <= Math.max(num * 1e-6, 1e-9);

        String signo = neg ? "-" : "";
        if (!fraccionValida) {
            return signo + formatDecimalLimpio(num);
        }
        if (denominador == 1) return signo + numerador;
        return signo + "\\frac{" + numerador + "}{" + denominador + "}";
    }

    /** Formatea un decimal positivo con hasta 6 decimales, sin ceros/punto sobrantes. */
    private static String formatDecimalLimpio(double v) {
        String s = String.format(java.util.Locale.US, "%.6f", v);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    /**
     * Intenta expresar {@code decimal} como (p/q)*constante con p y q pequeños
     * (q <= 12). Devuelve el LaTeX correspondiente (ej: "\\pi", "\\frac{1}{2}e",
     * "2e") o {@code null} si el valor no es (dentro de la tolerancia) un
     * múltiplo racional simple de esa constante.
     */
    private static String intentarFormaConstante(double decimal, double constante, String simbolo) {
        double ratio = decimal / constante;
        if (Math.abs(ratio) < 1e-9) return null; // es 0 u otro caso trivial

        boolean neg = ratio < 0;
        double r = Math.abs(ratio);

        for (int q = 1; q <= 12; q++) {
            long p = Math.round(r * q);
            if (p == 0) continue;
            double candidato = ((double) p / q) * constante;
            if (Math.abs(candidato - Math.abs(decimal)) < 1e-9) {
                long g = mcd(p, q);
                p /= g;
                long qq = q / g;
                String signo = neg ? "-" : "";
                if (qq == 1) {
                    return signo + (p == 1 ? "" : String.valueOf(p)) + simbolo;
                }
                return signo + "\\frac{" + p + "}{" + qq + "}" + simbolo;
            }
        }
        return null;
    }

    /** Máximo común divisor (Euclides) */
    private static long mcd(long a, long b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b != 0) {
            long t = b;
            b = a % b;
            a = t;
        }
        return a == 0 ? 1 : a;
    }

    public static String fmt(double v) {
        if (v == Math.floor(v) && !Double.isInfinite(v) && Math.abs(v) < 1e9)
            return String.valueOf((long) v);
        String s = String.format(java.util.Locale.US, "%.4f", v);
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}
