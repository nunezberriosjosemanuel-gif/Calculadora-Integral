package com.calculadora.model.parser;

import java.util.ArrayList;
import java.util.List;

public class Lexer {

    public List<String> tokenize(String expression) {
        List<String> tokens = new ArrayList<>();
        if (expression == null) {
            return tokens;
        }
        StringBuilder current = new StringBuilder();
        for (char c : expression.toCharArray()) {
            if ("+-*/^()".indexOf(c) >= 0) {
                flush(tokens, current);
                tokens.add(String.valueOf(c));
            } else if (!Character.isWhitespace(c)) {
                current.append(c);
            }
        }
        flush(tokens, current);
        return tokens;
    }

    private void flush(List<String> tokens, StringBuilder current) {
        if (current.length() > 0) {
            tokens.add(current.toString());
            current.setLength(0);
        }
    }
}
