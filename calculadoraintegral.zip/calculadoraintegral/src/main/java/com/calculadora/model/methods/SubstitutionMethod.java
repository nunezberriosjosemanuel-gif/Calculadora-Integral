package com.calculadora.model.methods;

import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;
import com.calculadora.model.strategies.IntegrationStrategy;

public class SubstitutionMethod implements IntegrationStrategy {

    private final AntiderivativeMethod delegate;

    public SubstitutionMethod() {
        this(new AntiderivativeMethod());
    }

    public SubstitutionMethod(AntiderivativeMethod delegate) {
        this.delegate = delegate;
    }

    @Override
    public ResultadoIntegral integrate(String function) {
        return delegate.integrate(function);
    }

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.SUSTITUCION;
    }

    /** Estrategia de respaldo genérica: acepta cualquier función, última en probarse. */
    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return true;
    }

    @Override
    public int prioridad() {
        return 999;
    }

    // =====================================================================
    // DETECCIÓN AUTOMÁTICA DE SUSTITUCIÓN (u = g(x))
    // =====================================================================
    // Busca si un término f(x) puede escribirse como  k * u'(x) * h(u(x))
    // para alguna función interna u = g(x) y alguna forma "externa" h
    // conocida (1/u, u^n, sin(u), cos(u), e^u, sqrt(u)). Si la encuentra,
    // aplica la regla de integración correspondiente en términos de u y
    // deshace el cambio de variable. El resultado se valida derivando
    // numéricamente la antiderivada propuesta y comparándola con la
    // función original, para evitar falsos positivos.
    // =====================================================================

    /** Resultado de una sustitución exitosa. */
    public static final class Resultado {
        public final String antiderivadaLatex;
        public final String antiderivadaExpr;
        public final String reglaLatex;

        Resultado(String latex, String expr, String regla) {
            this.antiderivadaLatex = latex;
            this.antiderivadaExpr = expr;
            this.reglaLatex = regla;
        }
    }

    private static final double[] PUNTOS = {0.35, 0.8, 1.25, 1.9, 2.6, -0.6, -1.4, -2.2};
    private static final double H = 1e-4;
    private static final double TOL_REL = 2e-3;

    /**
     * Intenta resolver el término {@code coef * f} mediante un cambio de
     * variable u = g(x). Devuelve {@code null} si no encuentra ninguna
     * sustitución válida (en cuyo caso el motor debe recurrir a otro método).
     */
    public static Resultado intentar(double coef, String f) {
        if (f == null || f.isEmpty()) return null;
        try {
            Resultado r = intentarRacional(coef, f);
            if (r != null) return r;
            r = intentarProducto(coef, f);
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Caso 1:  N(x) / D(x)   o   N(x) / D(x)^n
    // ------------------------------------------------------------------
    private static Resultado intentarRacional(double coef, String f) {
        int idx = splitTopLevel(f, '/');
        if (idx < 0) return null;
        String num = f.substring(0, idx);
        String den = f.substring(idx + 1);
        if (num.isEmpty() || den.isEmpty()) return null;

        String base;
        double n;
        java.util.regex.Matcher mPow = java.util.regex.Pattern
                .compile("^\\((.+)\\)\\^(-?\\d+\\.?\\d*)$").matcher(den);
        if (mPow.matches()) {
            base = mPow.group(1);
            n = Double.parseDouble(mPow.group(2));
        } else if (den.startsWith("(") && den.endsWith(")") && envuelveTodo(den)) {
            base = den.substring(1, den.length() - 1);
            n = 1;
        } else {
            base = den;
            n = 1;
        }
        if (esTrivial(base)) return null; // formas ya cubiertas por reglas directas

        Double k0 = detectarProporcionalidad(num, base);
        if (k0 == null) return null;
        double k = coef * k0;

        String uLatex = aLatex(base);
        String antLatex, antExpr, formaU;
        if (Math.abs(n - 1.0) < 1e-9) {
            antLatex = fmtCoefLatex(k) + "\\ln|" + uLatex + "|";
            antExpr = fmtCoefExpr(k) + "*log(abs(" + base + "))";
            formaU = "\\frac{1}{u}";
        } else {
            double exp = 1 - n;
            double kk = k / exp;
            antLatex = fmtCoefLatex(kk) + "(" + uLatex + ")^{" + AntiderivativeEngine.pasarAFraccionLatex(exp) + "}";
            antExpr = fmtCoefExpr(kk) + "*(" + base + ")^(" + AntiderivativeEngine.fmt(exp) + ")";
            formaU = "u^{" + AntiderivativeEngine.fmt(-n) + "}";
        }

        if (!validar(coef, f, antExpr)) return null;
        return new Resultado(antLatex, antExpr, reglaTexto(uLatex, formaU));
    }

    // ------------------------------------------------------------------
    // Caso 2:  extra(x) * h(E(x))   (incluye un solo factor, extra = 1)
    // ------------------------------------------------------------------
    private static Resultado intentarProducto(double coef, String f) {
        java.util.List<String> factores = splitFactores(f);
        if (factores.isEmpty()) return null;

        for (int i = 0; i < factores.size(); i++) {
            String cand = factores.get(i);
            String[] outer = detectarOuter(cand);
            if (outer == null) continue;
            String tipo = outer[0];
            String E = outer[1];
            if (esTrivial(E)) continue;

            StringBuilder extraSb = new StringBuilder();
            for (int j = 0; j < factores.size(); j++) {
                if (j == i) continue;
                if (extraSb.length() > 0) extraSb.append("*");
                extraSb.append(factores.get(j));
            }
            String extra = extraSb.length() == 0 ? "1" : extraSb.toString();

            Double k0 = detectarProporcionalidad(extra, E);
            if (k0 == null) continue;
            double k = coef * k0;

            String uLatex = aLatex(E);
            String antLatex, antExpr, formaU;
            switch (tipo) {
                case "sin":
                    antLatex = fmtCoefLatex(-k) + "\\cos(" + uLatex + ")";
                    antExpr = fmtCoefExpr(-k) + "*cos(" + E + ")";
                    formaU = "\\sin(u)";
                    break;
                case "cos":
                    antLatex = fmtCoefLatex(k) + "\\sin(" + uLatex + ")";
                    antExpr = fmtCoefExpr(k) + "*sin(" + E + ")";
                    formaU = "\\cos(u)";
                    break;
                case "exp":
                    antLatex = fmtCoefLatex(k) + "e^{" + uLatex + "}";
                    antExpr = fmtCoefExpr(k) + "*exp(" + E + ")";
                    formaU = "e^{u}";
                    break;
                case "sqrt": {
                    double kk23 = k * 2.0 / 3.0;
                    antLatex = fmtCoefLatex(kk23) + "(" + uLatex + ")^{\\frac{3}{2}}";
                    antExpr = fmtCoefExpr(kk23) + "*(" + E + ")^(1.5)";
                    formaU = "\\sqrt{u}";
                    break;
                }
                case "cbrt": {
                    double kk34 = k * 3.0 / 4.0;
                    antLatex = fmtCoefLatex(kk34) + "(" + uLatex + ")^{\\frac{4}{3}}";
                    antExpr = fmtCoefExpr(kk34) + "*(" + E + ")^(4.0/3.0)";
                    formaU = "\\sqrt[3]{u}";
                    break;
                }
                case "tan":
                    antLatex = fmtCoefLatex(-k) + "\\ln|\\cos(" + uLatex + ")|";
                    antExpr = fmtCoefExpr(-k) + "*log(abs(cos(" + E + ")))";
                    formaU = "\\tan(u)";
                    break;
                case "cot":
                    antLatex = fmtCoefLatex(k) + "\\ln|\\sin(" + uLatex + ")|";
                    antExpr = fmtCoefExpr(k) + "*log(abs(sin(" + E + ")))";
                    formaU = "\\cot(u)";
                    break;
                case "sec":
                    antLatex = fmtCoefLatex(k) + "\\ln|\\sec(" + uLatex + ")+\\tan(" + uLatex + ")|";
                    antExpr = fmtCoefExpr(k) + "*log(abs(1/cos(" + E + ")+tan(" + E + ")))";
                    formaU = "\\sec(u)";
                    break;
                case "csc":
                    antLatex = fmtCoefLatex(-k) + "\\ln|\\csc(" + uLatex + ")+\\cot(" + uLatex + ")|";
                    antExpr = fmtCoefExpr(-k) + "*log(abs(1/sin(" + E + ")+cos(" + E + ")/sin(" + E + ")))";
                    formaU = "\\csc(u)";
                    break;
                case "ln":
                    antLatex = fmtCoefLatex(k) + "\\left(" + uLatex + "\\ln(" + uLatex + ")-" + uLatex + "\\right)";
                    antExpr = fmtCoefExpr(k) + "*((" + E + ")*log(" + E + ")-(" + E + "))";
                    formaU = "\\ln(u)";
                    break;
                case "sinh":
                    antLatex = fmtCoefLatex(k) + "\\cosh(" + uLatex + ")";
                    antExpr = fmtCoefExpr(k) + "*cosh(" + E + ")";
                    formaU = "\\sinh(u)";
                    break;
                case "cosh":
                    antLatex = fmtCoefLatex(k) + "\\sinh(" + uLatex + ")";
                    antExpr = fmtCoefExpr(k) + "*sinh(" + E + ")";
                    formaU = "\\cosh(u)";
                    break;
                case "tanh":
                    antLatex = fmtCoefLatex(k) + "\\ln(\\cosh(" + uLatex + "))";
                    antExpr = fmtCoefExpr(k) + "*log(cosh(" + E + "))";
                    formaU = "\\tanh(u)";
                    break;
                case "pow": {
                    double n = Double.parseDouble(outer[2]);
                    double exp = n + 1;
                    if (Math.abs(exp) < 1e-9) {
                        antLatex = fmtCoefLatex(k) + "\\ln|" + uLatex + "|";
                        antExpr = fmtCoefExpr(k) + "*log(abs(" + E + "))";
                        formaU = "\\frac{1}{u}";
                    } else {
                        double kk = k / exp;
                        antLatex = fmtCoefLatex(kk) + "(" + uLatex + ")^{" + AntiderivativeEngine.pasarAFraccionLatex(exp) + "}";
                        antExpr = fmtCoefExpr(kk) + "*(" + E + ")^(" + AntiderivativeEngine.fmt(exp) + ")";
                        formaU = "u^{" + AntiderivativeEngine.fmt(n) + "}";
                    }
                    break;
                }
                default:
                    continue;
            }

            if (!validar(coef, f, antExpr)) continue;
            return new Resultado(antLatex, antExpr, reglaTexto(uLatex, formaU));
        }
        return null;
    }

    /** Detecta si {@code cand} es una función conocida aplicada a una expresión interna. */
    private static String[] detectarOuter(String cand) {
        java.util.regex.Matcher m;
        m = java.util.regex.Pattern.compile("^sin\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"sin", m.group(1)};
        m = java.util.regex.Pattern.compile("^cos\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"cos", m.group(1)};
        m = java.util.regex.Pattern.compile("^tan\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"tan", m.group(1)};
        m = java.util.regex.Pattern.compile("^cot\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"cot", m.group(1)};
        m = java.util.regex.Pattern.compile("^sec\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"sec", m.group(1)};
        m = java.util.regex.Pattern.compile("^csc\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"csc", m.group(1)};
        m = java.util.regex.Pattern.compile("^(?:ln|log)\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"ln", m.group(1)};
        m = java.util.regex.Pattern.compile("^sinh\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"sinh", m.group(1)};
        m = java.util.regex.Pattern.compile("^cosh\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"cosh", m.group(1)};
        m = java.util.regex.Pattern.compile("^tanh\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"tanh", m.group(1)};
        m = java.util.regex.Pattern.compile("^(?:exp|e\\^)\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"exp", m.group(1)};
        m = java.util.regex.Pattern.compile("^sqrt\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"sqrt", m.group(1)};
        m = java.util.regex.Pattern.compile("^cbrt\\((.+)\\)$").matcher(cand);
        if (m.matches()) return new String[]{"cbrt", m.group(1)};
        m = java.util.regex.Pattern.compile("^\\((.+)\\)\\^(-?\\d+\\.?\\d*)$").matcher(cand);
        if (m.matches()) return new String[]{"pow", m.group(1), m.group(2)};
        return null;
    }

    /**
     * Verifica si {@code extra(x) ≈ k * d/dx[base](x)} para alguna constante k,
     * evaluando en varios puntos de prueba. Devuelve k o {@code null} si no
     * hay proporcionalidad consistente.
     */
    private static Double detectarProporcionalidad(String extra, String base) {
        Double primerK = null;
        double sumaK = 0;
        int usados = 0;
        for (double x : PUNTOS) {
            try {
                double gPrime = derivadaNumerica(base, x);
                if (!Double.isFinite(gPrime) || Math.abs(gPrime) < 1e-8) continue;
                double valExtra = new net.objecthunter.exp4j.ExpressionBuilder(extra)
                        .variable("x").build().setVariable("x", x).evaluate();
                if (!Double.isFinite(valExtra)) continue;
                double k = valExtra / gPrime;
                if (primerK == null) {
                    primerK = k;
                } else if (Math.abs(k - primerK) > TOL_REL * Math.max(1.0, Math.abs(primerK))) {
                    return null;
                }
                sumaK += k;
                usados++;
            } catch (Exception ignored) {
                // punto fuera de dominio: se descarta
            }
        }
        if (usados < 3 || primerK == null) return null;
        return sumaK / usados;
    }

    private static double derivadaNumerica(String expr, double x) {
        net.objecthunter.exp4j.Expression e = new net.objecthunter.exp4j.ExpressionBuilder(expr)
                .variable("x").build();
        double f1 = e.setVariable("x", x + H).evaluate();
        double f2 = e.setVariable("x", x - H).evaluate();
        return (f1 - f2) / (2 * H);
    }

    /** Deriva numéricamente la antiderivada propuesta y la compara contra {@code coef*f}. */
    private static boolean validar(double coef, String fOriginal, String antiderivadaExpr) {
        int ok = 0, total = 0;
        for (double x : PUNTOS) {
            try {
                double original = coef * new net.objecthunter.exp4j.ExpressionBuilder(fOriginal)
                        .variable("x").build().setVariable("x", x).evaluate();
                if (!Double.isFinite(original)) continue;
                double derivada = derivadaNumerica(antiderivadaExpr, x);
                if (!Double.isFinite(derivada)) continue;
                total++;
                double tol = Math.max(1e-3, Math.abs(original) * 1e-2);
                if (Math.abs(derivada - original) < tol) ok++;
            } catch (Exception ignored) {
                // punto fuera de dominio: se descarta
            }
        }
        return total >= 3 && ok == total;
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------
    private static boolean esTrivial(String s) {
        return s.equals("x") || s.matches("-?\\d+(\\.\\d+)?");
    }

    /** true si toda la cadena está envuelta en un único par de paréntesis balanceado */
    private static boolean envuelveTodo(String s) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') {
                depth--;
                if (depth == 0 && i != s.length() - 1) return false;
            }
        }
        return depth == 0;
    }

    private static int splitTopLevel(String s, char c) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '(') depth++;
            else if (ch == ')') depth--;
            else if (depth == 0 && ch == c) return i;
        }
        return -1;
    }

    private static java.util.List<String> splitFactores(String s) {
        java.util.List<String> out = new java.util.ArrayList<>();
        int depth = 0, inicio = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (depth == 0 && c == '*') {
                out.add(s.substring(inicio, i));
                inicio = i + 1;
            }
        }
        out.add(s.substring(inicio));
        return out;
    }

    /** Convierte una subexpresión a un LaTeX legible simple (mismo criterio que el motor). */
    private static String aLatex(String expr) {
        String s = expr.replaceAll("\\*", "");
        s = s.replaceAll("\\^\\(([^)]+)\\)", "^{$1}");
        return s;
    }

    private static String fmtCoefLatex(double k) {
        if (Math.abs(k - 1.0) < 1e-9) return "";
        if (Math.abs(k + 1.0) < 1e-9) return "-";
        return AntiderivativeEngine.pasarAFraccionLatex(k);
    }

    private static String fmtCoefExpr(double k) {
        if (Math.abs(k - 1.0) < 1e-9) return "1";
        return "(" + AntiderivativeEngine.fmtExacto(k) + ")";
    }

    private static String reglaTexto(String uLatex, String formaU) {
        return "Regla de sustitución (cambio de variable): u=" + uLatex
                + ",\\ du=u'(x)\\,dx \\Rightarrow \\int \\ldots\\,dx=\\int " + formaU + "\\,du";
    }
}