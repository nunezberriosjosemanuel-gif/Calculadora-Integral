package com.calculadora.services;

import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;
import com.calculadora.model.repository.HistoryRepository;
import java.util.List;

public class HistoryService {

    private final HistoryRepository repository;

    public HistoryService(HistoryRepository repository) {
        this.repository = repository;
    }

    public void save(IntegralRequest request, IntegralResponse response) {
        repository.save(request, response);
    }

    public List<IntegralResponse> list() {
        return repository.list();
    }
}
