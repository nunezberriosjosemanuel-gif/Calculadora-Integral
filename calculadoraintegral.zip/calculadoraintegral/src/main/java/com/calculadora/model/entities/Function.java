package com.calculadora.model.entities;

public class Function {

    private final String expression;
    private final Variable variable;

    public Function(String expression, Variable variable) {
        this.expression = expression;
        this.variable = variable;
    }

    public String getExpression() {
        return expression;
    }

    public Variable getVariable() {
        return variable;
    }
}
