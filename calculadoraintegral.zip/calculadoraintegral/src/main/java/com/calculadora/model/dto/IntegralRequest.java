package com.calculadora.model.dto;

import com.calculadora.model.entities.Intervalo;

public class IntegralRequest {

    private final String funcion;
    private final Intervalo intervalo;

    public IntegralRequest(String funcion, double limiteInferior, double limiteSuperior) {
        this.funcion = funcion;
        this.intervalo = new Intervalo(limiteInferior, limiteSuperior);
    }

    public String getFuncion() {
        return funcion;
    }

    public Intervalo getIntervalo() {
        return intervalo;
    }
}
