package com.calculadora.config;

public final class RouteManager {

    private static final String VIEW_ROOT = "/com/calculadora/views/";

    private RouteManager() {
    }

    public static String view(String name) {
        return VIEW_ROOT + name + ".fxml";
    }
}
