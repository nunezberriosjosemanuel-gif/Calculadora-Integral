package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones irracionales/radicales: sqrt(...), cbrt(...). */
public class IrrationalDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("sqrt") || f.contains("cbrt");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.IRRACIONAL;
    }

    @Override
    public int prioridad() {
        return 40;
    }
}
