package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones cuadráticas: presencia del término x^2. */
public class QuadraticDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("x^2");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.CUADRATICA;
    }

    @Override
    public int prioridad() {
        return 60;
    }
}
