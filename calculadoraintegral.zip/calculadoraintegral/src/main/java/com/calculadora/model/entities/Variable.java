package com.calculadora.model.entities;

public class Variable {

    private final String name;

    public Variable(String name) {
        this.name = name == null || name.isBlank() ? "x" : name;
    }

    public String getName() {
        return name;
    }
}
