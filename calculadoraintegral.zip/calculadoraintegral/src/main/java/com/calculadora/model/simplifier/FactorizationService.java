package com.calculadora.model.simplifier;

import java.util.Optional;

/**
 * Álgebra de factorización reutilizable (los casos del "Formulario Unificado
 * de Matemáticas"). Pensada para ser inyectada en las estrategias que la
 * necesitan (fracciones parciales, sustitución trigonométrica) en vez de que
 * cada una reimplemente su propia factorización (principio DIP).
 *
 * Cada método intenta un caso específico y devuelve {@link Optional#empty()}
 * si la expresión no encaja en ese patrón — así se pueden encadenar con
 * {@code Optional::or} sin lanzar excepciones de control de flujo.
 */
public interface FactorizationService {

    /** Caso 1: factor común. ax + ay = a(x + y). */
    Optional<String> factorComun(String expresion);

    /** Caso 4: diferencia de cuadrados. a² - b² = (a + b)(a - b). */
    Optional<String> diferenciaDeCuadrados(String expresion);

    /** Caso 3: trinomio cuadrado perfecto. a² ± 2ab + b² = (a ± b)². */
    Optional<String> trinomioCuadradoPerfecto(String expresion);

    /** Caso 6: trinomio x² + bx + c = (x + r)(x + s). */
    Optional<String> trinomioXCuadradoMasBxMasC(String expresion);

    /** Caso 7: trinomio ax² + bx + c (factor común + trinomio simple). */
    Optional<String> trinomioAxCuadradoMasBxMasC(String expresion);

    /** Caso 9: suma o diferencia de cubos. a³ ± b³ = (a ± b)(a² ∓ ab + b²). */
    Optional<String> sumaODiferenciaDeCubos(String expresion);

    /** Caso 8: cubo perfecto de un binomio. a³ ± 3a²b + 3ab² ± b³ = (a ± b)³. */
    Optional<String> cuboPerfectoDeBinomio(String expresion);

    /** Intenta, en orden, todos los casos soportados y devuelve el primero que aplique. */
    Optional<String> factorizar(String expresion);
}
