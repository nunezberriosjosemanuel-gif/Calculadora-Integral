package com.calculadora.model.parser;

public class ExpressionValidator {

    public boolean isValid(String expression) {
        return expression != null && !expression.trim().isEmpty();
    }
}
