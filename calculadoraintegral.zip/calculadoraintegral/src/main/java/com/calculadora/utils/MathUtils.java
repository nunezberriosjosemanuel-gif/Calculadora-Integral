package com.calculadora.utils;

import com.calculadora.model.methods.AntiderivativeEngine;

public final class MathUtils {

    private MathUtils() {
    }

    public static double evaluar(String expresion, double x) {
        return AntiderivativeEngine.evaluar(expresion, x);
    }
}

