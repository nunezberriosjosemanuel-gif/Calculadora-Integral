package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/**
 * Sustitución trigonométrica para eliminar radicales de segundo grado:
 * sqrt(a^2-x^2) -> x = a sin(t), sqrt(a^2+x^2) -> x = a tan(t),
 * sqrt(x^2-a^2) -> x = a sec(t).
 */
public class TrigonometricSubstitutionMethod extends SubstitutionMethod {

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.SUSTITUCION_TRIGONOMETRICA;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        String f = function == null ? "" : function.toLowerCase();
        return f.contains("sqrt(1-x^2)") || f.contains("sqrt(1+x^2)") || f.contains("sqrt(x^2-");
    }

    @Override
    public int prioridad() {
        return 10;
    }
}
