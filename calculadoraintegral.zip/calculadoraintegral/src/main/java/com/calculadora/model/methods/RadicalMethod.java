package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/** Funciones irracionales/radicales (sqrt(u)) resueltas por sustitución. */
public class RadicalMethod extends SubstitutionMethod {

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.SUSTITUCION;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return tipo == TipoFuncion.IRRACIONAL;
    }

    @Override
    public int prioridad() {
        return 60;
    }
}
