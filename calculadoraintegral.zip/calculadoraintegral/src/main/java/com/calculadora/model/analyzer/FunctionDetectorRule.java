package com.calculadora.model.analyzer;

import com.calculadora.model.enums.TipoFuncion;

/**
 * Contrato de una regla de clasificación individual.
 *
 * Sustituye la cadena de {@code if/else} que antes vivía en
 * {@code FunctionDetector}: cada {@link TipoFuncion} tiene ahora su propia
 * clase, así que agregar un tipo nuevo significa "crear una clase e
 * inscribirla" en vez de "editar un método existente" (principio
 * Abierto/Cerrado).
 */
public interface FunctionDetectorRule {

    /** Indica si la expresión pertenece al {@link TipoFuncion} de esta regla. */
    boolean matches(String expression);

    /** Tipo de función que esta regla reconoce. */
    TipoFuncion tipo();

    /**
     * Orden de evaluación (menor número = mayor precedencia). Se usa para
     * decidir qué tipo "gana" cuando una expresión coincide con más de una
     * regla, replicando el orden que tenía la cadena de if/else original.
     */
    int prioridad();
}
