package com.calculadora.model.solver;

import com.calculadora.model.analyzer.FunctionClassifier;
import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;
import com.calculadora.model.strategies.IntegrationStrategy;
import com.calculadora.model.strategies.StrategyRegistry;
import com.calculadora.utils.ExpressionNormalizer;

import java.util.List;

/**
 * Orquestador central de la resolución simbólica: parsea (delegado a las
 * estrategias, que aún reciben el texto crudo), clasifica, selecciona la
 * estrategia adecuada y cae a la siguiente candidata si la primera no
 * devuelve una antiderivada elemental. Tiene una sola responsabilidad:
 * coordinar — a diferencia del antiguo {@code AntiderivativeEngine} estático,
 * que mezclaba parsing, reglas y formateo en una sola clase de 600+ líneas.
 */
public class SolverEngine {

    private final FunctionClassifier classifier;
    private final StrategyRegistry registry;

    public SolverEngine(FunctionClassifier classifier, StrategyRegistry registry) {
        this.classifier = classifier;
        this.registry = registry;
    }

    public SolverResult resolver(String expresion) {
        String normalizada = ExpressionNormalizer.forSymbolic(expresion);
        TipoFuncion tipo = classifier.classify(normalizada);
        List<IntegrationStrategy> candidatas = registry.candidatos(normalizada, tipo);

        IntegrationStrategy mejorNumerica = null;
        ResultadoIntegral mejorNumericaResultado = null;

        for (IntegrationStrategy estrategia : candidatas) {
            ResultadoIntegral resultado = estrategia.integrate(normalizada);
            if (resultado.isExito() && !resultado.isNumerica()) {
                return new SolverResult(resultado, tipo, estrategia.getMethod());
            }
            if (resultado.isExito() && mejorNumerica == null) {
                mejorNumerica = estrategia;
                mejorNumericaResultado = resultado;
            }
        }

        if (mejorNumerica != null) {
            return new SolverResult(mejorNumericaResultado, tipo, MetodoIntegracion.NUMERICA);
        }

        // Ninguna estrategia registrada logró procesar la expresión: se cae al
        // marcador numérico genérico para que SolverService use cuadratura
        // de Gauss-Legendre sobre la función completa (igual que el
        // comportamiento previo, sin depender de la Regla de Simpson).
        ResultadoIntegral numerico = new ResultadoIntegral(
                "\\text{[numérico]}", expresion, true, true, null, List.of());
        return new SolverResult(numerico, tipo, MetodoIntegracion.NUMERICA);
    }

    /** Resultado agregado de la resolución: antiderivada + tipo detectado + método usado. */
    public static final class SolverResult {
        private final ResultadoIntegral resultado;
        private final TipoFuncion tipo;
        private final MetodoIntegracion metodo;

        public SolverResult(ResultadoIntegral resultado, TipoFuncion tipo, MetodoIntegracion metodo) {
            this.resultado = resultado;
            this.tipo = tipo;
            this.metodo = metodo;
        }

        public ResultadoIntegral getResultado() {
            return resultado;
        }

        public TipoFuncion getTipo() {
            return tipo;
        }

        public MetodoIntegracion getMetodo() {
            return metodo;
        }
    }
}
