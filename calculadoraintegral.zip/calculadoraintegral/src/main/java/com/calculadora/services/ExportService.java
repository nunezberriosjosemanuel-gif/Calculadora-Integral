package com.calculadora.services;

import com.calculadora.model.dto.IntegralResponse;

public class ExportService {

    public String toPlainText(IntegralResponse response) {
        if (response == null || response.getResultado() == null) {
            return "";
        }
        return "Metodo: " + response.getMetodoIntegracion()
                + System.lineSeparator()
                + "Resultado: " + response.getValorDefinido();
    }
}
