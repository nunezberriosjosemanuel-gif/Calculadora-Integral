package com.calculadora.model.repository;

import java.util.HashMap;
import java.util.Map;

public class SettingsRepository {

    private final Map<String, String> settings = new HashMap<>();

    public String get(String key, String defaultValue) {
        return settings.getOrDefault(key, defaultValue);
    }

    public void set(String key, String value) {
        settings.put(key, value);
    }
}
