package com.calculadora.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ExpressionNormalizer {

    private static final Pattern TRIG_POWER = Pattern.compile("\\b(sin|cos|tan|sec|csc|cot)\\^(\\d+)\\(([^()]+)\\)");

    private ExpressionNormalizer() {
    }

    public static String forSymbolic(String expression) {
        String s = base(expression);
        s = normalizeTrigPowers(s);
        return insertImplicitMultiplication(s);
    }

    public static String forEvaluation(String expression) {
        String s = forSymbolic(expression);
        s = s.replaceAll("\\bln\\(", "log(");
        s = replaceFunction(s, "sec", "1/cos");
        s = replaceFunction(s, "csc", "1/sin");
        s = replaceFunction(s, "cot", "1/tan");
        return s;
    }

    private static String base(String expression) {
        if (expression == null) {
            return "";
        }
        return expression.trim()
                .replaceAll("\\s+", "")
                .replace("π", "pi")
                .replace("Ï€", "pi")
                .replace("−", "-")
                .replace("×", "*");
    }

    private static String normalizeTrigPowers(String s) {
        String current = s;
        boolean changed;
        do {
            Matcher m = TRIG_POWER.matcher(current);
            StringBuffer out = new StringBuffer();
            changed = false;
            while (m.find()) {
                changed = true;
                String replacement = "(" + m.group(1) + "(" + m.group(3) + "))^" + m.group(2);
                m.appendReplacement(out, Matcher.quoteReplacement(replacement));
            }
            m.appendTail(out);
            current = out.toString();
        } while (changed);
        return current;
    }

    private static String insertImplicitMultiplication(String s) {
        String current = s;
        current = current.replaceAll("(\\d)(\\(|[a-zA-Z])", "$1*$2");
        current = current.replaceAll("(x|pi|e)(\\d)", "$1*$2");
        current = current.replaceAll("(x|pi|e)\\(", "$1*(");
        current = current.replaceAll("\\)(\\d|x|pi|e|[a-zA-Z]+\\()", ")*$1");
        return current;
    }

    private static String replaceFunction(String expression, String name, String replacementPrefix) {
        String token = name + "(";
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < expression.length()) {
            if (expression.startsWith(token, i)) {
                int open = i + name.length();
                int close = findClose(expression, open);
                if (close > open) {
                    String inner = expression.substring(open + 1, close);
                    out.append("(").append(replacementPrefix).append("(").append(inner).append("))");
                    i = close + 1;
                    continue;
                }
            }
            out.append(expression.charAt(i));
            i++;
        }
        return out.toString();
    }

    private static int findClose(String s, int openIndex) {
        int depth = 0;
        for (int i = openIndex; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }
}
