package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/**
 * Integración trigonométrica directa (potencias impares/pares, productos de
 * ángulos distintos, identidades tan²/cot²).
 */
public class TrigonometricMethod extends SubstitutionMethod {

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.INTEGRACION_TRIGONOMETRICA;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return tipo == TipoFuncion.TRIGONOMETRICA;
    }

    @Override
    public int prioridad() {
        return 30;
    }
}
