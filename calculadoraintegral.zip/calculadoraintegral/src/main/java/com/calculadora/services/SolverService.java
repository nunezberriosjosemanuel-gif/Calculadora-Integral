package com.calculadora.services;

import com.calculadora.model.methods.AntiderivativeEngine;
import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;
import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;
import com.calculadora.model.solver.SolverEngine;
import com.calculadora.utils.ExpressionNormalizer;

public class SolverService {

    private final SolverEngine solverEngine;

    public SolverService(SolverEngine solverEngine) {
        this.solverEngine = solverEngine;
    }

    public IntegralResponse solve(IntegralRequest request) {
        String funcion = ExpressionNormalizer.forSymbolic(request.getFuncion());
        SolverEngine.SolverResult solved = solverEngine.resolver(funcion);
        ResultadoIntegral result = solved.getResultado();
        TipoFuncion type = solved.getTipo();
        MetodoIntegracion method = solved.getMetodo();

        double definedValue = Double.NaN;

        if (result.isExito()) {
            if (result.isNumerica()) {
                definedValue = AntiderivativeEngine.integrarNumericamente(
                        funcion,
                        request.getIntervalo().getLimiteInferior(),
                        request.getIntervalo().getLimiteSuperior());
                method = MetodoIntegracion.NUMERICA;
            } else {
                double fb = AntiderivativeEngine.evaluar(result.getAntiderivadaExpr(),
                        request.getIntervalo().getLimiteSuperior());
                double fa = AntiderivativeEngine.evaluar(result.getAntiderivadaExpr(),
                        request.getIntervalo().getLimiteInferior());
                definedValue = fb - fa;
            }
        }

        return new IntegralResponse(result, type, method, definedValue);
    }
}
