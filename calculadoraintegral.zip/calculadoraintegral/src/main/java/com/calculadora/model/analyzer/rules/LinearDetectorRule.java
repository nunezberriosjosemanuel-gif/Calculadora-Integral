package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/**
 * Detecta funciones lineales: contienen la variable "x" pero sin ningún
 * exponente explícito ("x^..."). Antes {@code TipoFuncion.LINEAL} existía en
 * el enum pero el {@code FunctionDetector} original nunca lo producía; esta
 * regla lo vuelve alcanzable sin afectar el resultado numérico (las
 * estrategias directas ya trataban lineal/polinómica/cuadrática por igual).
 */
public class LinearDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("x") && !f.contains("x^");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.LINEAL;
    }

    @Override
    public int prioridad() {
        return 70;
    }
}
