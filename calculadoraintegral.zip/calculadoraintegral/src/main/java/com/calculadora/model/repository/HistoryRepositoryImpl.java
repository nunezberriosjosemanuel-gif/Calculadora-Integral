package com.calculadora.model.repository;

import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HistoryRepositoryImpl implements HistoryRepository {

    private final List<IntegralResponse> history = new ArrayList<>();

    @Override
    public void save(IntegralRequest request, IntegralResponse response) {
        history.add(response);
    }

    @Override
    public List<IntegralResponse> list() {
        return Collections.unmodifiableList(history);
    }
}
