package com.calculadora.controllers;

import com.calculadora.config.DependencyContainer;
import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;
import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.services.IntegralService;
import com.calculadora.utils.LatexGenerator;
import com.calculadora.utils.MathUtils;
import com.calculadora.utils.ExpressionNormalizer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.web.WebView;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import javafx.stage.Modality;

import java.io.IOException;

public class MainController {

    @FXML private WebView webCalc;

    private WebEngine engine;
    private final IntegralService integralService = DependencyContainer.getIntegralService();

    @FXML
    public void initialize() {
        engine = webCalc.getEngine();
        engine.setJavaScriptEnabled(true);

        // Interceptar navegación: JS llama a  app://calcular?f=...&a=...&b=...
        engine.locationProperty().addListener((obs, oldLoc, newLoc) -> {
            if (newLoc != null && newLoc.startsWith("app://")) {
                // Devolver la URL al HTML (evitar que WebView realmente navegue)
                javafx.application.Platform.runLater(() -> engine.loadContent(buildCalculadoraHTML()));
                handleAppUrl(newLoc);
            }
        });

        // Alternativa más limpia: escuchar antes de cargar via prompt-trick
        engine.setOnAlert(ev -> handleAlert(ev.getData()));

        engine.loadContent(buildCalculadoraHTML());
    }

    /** JS llama: window.alert("CMD|arg1|arg2|arg3") */
    private void handleAlert(String data) {
        if (data == null || !data.contains("|")) return;
        String[] parts = data.split("\\|", 4);
        String cmd = parts[0];
        String f   = parts.length > 1 ? parts[1] : "";
        String a   = parts.length > 2 ? parts[2] : "";
        String b   = parts.length > 3 ? parts[3] : "";
        if ("CALCULAR".equals(cmd))  javafx.application.Platform.runLater(() -> calcularIntegral(f, a, b));
        if ("GRAFICAR".equals(cmd))  javafx.application.Platform.runLater(() -> abrirGrafica(f, a, b));
    }

    private void handleAppUrl(String url) { /* reservado */ }

    // Evalúa un límite que puede ser una expresión numérica simple,
    // incluyendo constantes como "pi" o "E" (ej: "pi/2", "-3", "2*pi").
    private double evaluarLimite(String expr) {
        // exp4j solo reconoce la constante de Euler en minúscula ("e").
        // Normalizamos una "E" mayúscula suelta (no parte de notación
        // científica como "2E3") para que también sea válida como límite.
        String normalizado = expr.replaceAll("(?<![0-9.])E(?![0-9])", "e");
        return new net.objecthunter.exp4j.ExpressionBuilder(normalizado).build().evaluate();
    }

    // -----------------------------------------------------------------------
    private void calcularIntegral(String funcTex, String aStr, String bStr) {
        try {
            if (funcTex.isEmpty() || aStr.isEmpty() || bStr.isEmpty()) {
                engine.executeScript("mostrarError('Completa función y límites')");
                return;
            }

            // Convertir la notación "display" a exp4j
            String funcEval = texToExp4j(funcTex);

            double a = evaluarLimite(aStr);
            double b = evaluarLimite(bStr);

            IntegralResponse response = integralService.resolve(new IntegralRequest(funcEval, a, b));
            ResultadoIntegral res = response.getResultado();

            if (res == null || !res.isExito()) {
                engine.executeScript("mostrarError(" + jsStr(res != null ? res.getMensajeError() : "Error") + ")");
                return;
            }

            String html;
            if (res.isNumerica()) {
                double resultado = response.getValorDefinido();
                if (!Double.isFinite(resultado)) {
                    engine.executeScript("mostrarError('No se pudo calcular un resultado finito. Revisa dominio, parentesis y discontinuidades del intervalo.')");
                    return;
                }
                String aFrac = LatexGenerator.fraccion(a);
                String bFrac = LatexGenerator.fraccion(b);
                html = buildResultHTML(funcTex, aFrac, bFrac, null, null, null, null,
                        String.format(java.util.Locale.US, "%.6f", resultado), true);
            } else {
                String Fx  = res.getAntiderivadaLatex();
                String FxE = res.getAntiderivadaExpr();
                double Fb  = MathUtils.evaluar(FxE, b);
                double Fa  = MathUtils.evaluar(FxE, a);
                double resultado = Fb - Fa;
                if (!Double.isFinite(Fb) || !Double.isFinite(Fa) || !Double.isFinite(resultado)) {
                    engine.executeScript("mostrarError('La integral no tiene un valor definido finito en ese intervalo.')");
                    return;
                }

                String aFrac   = LatexGenerator.fraccion(a);
                String bFrac   = LatexGenerator.fraccion(b);
                String FbFrac  = LatexGenerator.fraccion(Fb);
                String FaFrac  = LatexGenerator.fraccion(Fa);
                String resFrac = LatexGenerator.fraccion(resultado);
                // Decimal: evitar mostrar 0.000000 cuando resFrac ya dice "0"
                String resDecimal;
                if (Math.abs(resultado) < 1e-10) {
                    resDecimal = "0";
                } else {
                    resDecimal = String.format(java.util.Locale.US, "%.6f", resultado)
                        .replaceAll("0+$", "").replaceAll("\\.$", "");
                }

                // Construir paso 3: F(b) - F(a) con formato correcto
                // Si Fa es negativo → FbFrac - (FaFrac) visualmente queda Fb + |Fa|
                // Si Fa >= 0      → FbFrac - FaFrac
                String paso3;
                if (FaFrac.startsWith("-")) {
                    paso3 = FbFrac + "-\\left(" + FaFrac + "\\right)";
                } else {
                    paso3 = FbFrac + "-" + FaFrac;
                }

                html = buildResultHTML(funcTex, aFrac, bFrac, Fx, FbFrac, FaFrac,
                        resFrac, resDecimal, false, paso3, res.getTerminos());
            }

            engine.executeScript("mostrarResultado(" + jsStr(html) + ")");

        } catch (IllegalArgumentException e) {
            String msg = e.getMessage() != null ? e.getMessage() : "Límites inválidos";
            engine.executeScript("mostrarError(" + jsStr(msg) + ")");
        } catch (Exception e) {
            e.printStackTrace();
            engine.executeScript("mostrarError('Error interno: " + e.getMessage() + "')");
        }
    }

    private void abrirGrafica(String funcTex, String aStr, String bStr) {
        try {
            String funcEval = texToExp4j(funcTex);
            double a = evaluarLimite(aStr);
            double b = evaluarLimite(bStr);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/calculadora/views/Graph.fxml"));
            Parent root = loader.load();

            GraphController sc = loader.getController();
            sc.graficarFuncion(funcEval, funcTex, a, b);

            Stage stage = new Stage();
            stage.setTitle("Plano Cartesiano — f(x) = " + funcEval);
            stage.initModality(Modality.NONE);
            Scene scene = new Scene(root, 820, 620);
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            engine.executeScript("mostrarError('Error al abrir gráfica: " + e.getMessage() + "')");
        }
    }

    // -----------------------------------------------------------------------
    // Convierte la expresión "de pantalla" a sintaxis exp4j
    // -----------------------------------------------------------------------
    private static String texToExp4j(String s) {
        // La calculadora ya envía el formato evaluable directamente (almacenado en data-expr)
        return ExpressionNormalizer.forSymbolic(s);
    }

    private static String jsStr(String s) {
        if (s == null) s = "";
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'";
    }

    // -----------------------------------------------------------------------
    /**
     * Convierte LaTeX de fracción a HTML visual sin depender de MathJax.
     * \frac{a}{b} → <span class='frac'><span>a</span><span>b</span></span>
     */
    private String latexToHTML(String latex) {
        if (latex == null) return "";
        String s = latex;
        // Fracciones \frac{num}{den}
        int safety = 0;
        while (s.contains("\\frac{") && safety++ < 20) {
            int idx = s.indexOf("\\frac{");
            // Extraer numerador
            int n1 = idx + 5, n2 = findClose(s, n1);
            String num = s.substring(n1 + 1, n2);
            // Extraer denominador
            int d1 = n2 + 1, d2 = findClose(s, d1);
            String den = s.substring(d1 + 1, d2);
            String frac = "<span class='frac'><span>" + latexToHTML(num) + "</span><span>" + latexToHTML(den) + "</span></span>";
            s = s.substring(0, idx) + frac + s.substring(d2 + 1);
        }
        // \Big[...\Big] y \Bigl[...\Bigr] → [ ... ]
        s = s.replaceAll("\\\\Big\\[|\\\\Bigl\\[", "<span style='font-size:1.4em'>[</span>");
        s = s.replaceAll("\\\\Big\\]|\\\\Bigr\\]", "<span style='font-size:1.4em'>]</span>");
        // \left( y \right)
        s = s.replaceAll("\\\\left\\(", "(");
        s = s.replaceAll("\\\\right\\)", ")");
        s = s.replaceAll("\\\\left\\[", "[");
        s = s.replaceAll("\\\\right\\]", "]");
        // Símbolos
        s = s.replace("\\ln", "ln");
        s = s.replace("\\log", "log");
        s = s.replace("\\sin", "sin");
        s = s.replace("\\cos", "cos");
        s = s.replace("\\tan", "tan");
        s = s.replace("\\sec", "sec");
        s = s.replace("\\csc", "csc");
        s = s.replace("\\cot", "cot");
        s = s.replace("\\sinh", "sinh");
        s = s.replace("\\cosh", "cosh");
        s = s.replace("\\tanh", "tanh");
        s = s.replace("\\arcsin", "arcsin");
        s = s.replace("\\arccos", "arccos");
        s = s.replace("\\arctan", "arctan");
        // Multiplicación: igual que en el JS del teclado, \times/\cdot deben
        // traducirse a un símbolo visible en vez de perderse en la limpieza
        // final de comandos LaTeX (bug que rompía la vista al combinar
        // multiplicación con funciones trigonométricas/logarítmicas).
        s = s.replace("\\times", "×");
        s = s.replace("\\cdot", "·");
        // \sqrt[3]{...} (raíz cúbica) → ∛(...) — debe resolverse antes que
        // \sqrt{...} para no confundir el índice del radical con el contenido.
        safety = 0;
        while (s.contains("\\sqrt[3]{") && safety++ < 20) {
            int idx = s.indexOf("\\sqrt[3]{");
            int openBrace = idx + 8;
            int close = findClose(s, openBrace);
            String inner = s.substring(openBrace + 1, close);
            s = s.substring(0, idx) + "∛(" + latexToHTML(inner) + ")" + s.substring(close + 1);
        }
        // \sqrt{...} → √(...)  (usa findClose para no romper llaves de ^{} y _{} que vienen después)
        safety = 0;
        while (s.contains("\\sqrt{") && safety++ < 20) {
            int idx = s.indexOf("\\sqrt{");
            int openBrace = idx + 5; // posición de '{'
            int close = findClose(s, openBrace);
            String inner = s.substring(openBrace + 1, close);
            s = s.substring(0, idx) + "√(" + latexToHTML(inner) + ")" + s.substring(close + 1);
        }
        // sqrt(...) sin backslash (viene de la expresión evaluable exp4j, ej: "4*sqrt(x)")
        safety = 0;
        while (s.contains("sqrt(") && safety++ < 20) {
            int idx = s.indexOf("sqrt(");
            int openParen = idx + 4; // posición de '('
            int close = findCloseParen(s, openParen);
            String inner = s.substring(openParen + 1, close);
            s = s.substring(0, idx) + "√(" + latexToHTML(inner) + ")" + s.substring(close + 1);
        }
        s = s.replace("\\approx", "≈");
        s = s.replace("\\pi", "π");
        s = s.replace("\\infty", "∞");
        // Potencias x^{n} → x<sup>n</sup>
        safety = 0;
        while (s.contains("^{") && safety++ < 20) {
            int idx = s.indexOf("^{");
            int close = findClose(s, idx + 1);
            String exp = s.substring(idx + 2, close);
            s = s.substring(0, idx) + "<sup>" + latexToHTML(exp) + "</sup>" + s.substring(close + 1);
        }
        // Superíndice simple: x^2 (sin llaves)
        s = s.replaceAll("\\^(-?\\d+)", "<sup>$1</sup>");
        // Subíndices _{n}
        safety = 0;
        while (s.contains("_{") && safety++ < 20) {
            int idx = s.indexOf("_{");
            int close = findClose(s, idx + 1);
            String sub = s.substring(idx + 2, close);
            s = s.substring(0, idx) + "<sub>" + latexToHTML(sub) + "</sub>" + s.substring(close + 1);
        }
        // Integral \int → ∫
        s = s.replace("\\int", "<span style='font-size:1.4em'>∫</span>");
        // Limpiar backslashes restantes
        s = s.replaceAll("\\\\[a-zA-Z]+", "");
        return s;
    }

    private int findClose(String s, int openIdx) {
        // openIdx apunta a '{', devuelve índice del '}' correspondiente
        int depth = 0;
        for (int i = openIdx; i < s.length(); i++) {
            if (s.charAt(i) == '{') depth++;
            else if (s.charAt(i) == '}') { depth--; if (depth == 0) return i; }
        }
        return s.length() - 1;
    }

    private int findCloseParen(String s, int openIdx) {
        // openIdx apunta a '(', devuelve índice del ')' correspondiente
        int depth = 0;
        for (int i = openIdx; i < s.length(); i++) {
            if (s.charAt(i) == '(') depth++;
            else if (s.charAt(i) == ')') { depth--; if (depth == 0) return i; }
        }
        return s.length() - 1;
    }

    private String buildResultHTML(String funcTex, String aFrac, String bFrac,
            String Fx, String FbFrac, String FaFrac,
            String resFrac, String resDecimal, boolean numerica) {
        return buildResultHTML(funcTex, aFrac, bFrac, Fx, FbFrac, FaFrac,
                resFrac, resDecimal, numerica, null, null);
    }

    private String buildResultHTML(String funcTex, String aFrac, String bFrac,
            String Fx, String FbFrac, String FaFrac,
            String resFrac, String resDecimal, boolean numerica, String paso3Override) {
        return buildResultHTML(funcTex, aFrac, bFrac, Fx, FbFrac, FaFrac,
                resFrac, resDecimal, numerica, paso3Override, null);
    }

    private String buildResultHTML(String funcTex, String aFrac, String bFrac,
            String Fx, String FbFrac, String FaFrac,
            String resFrac, String resDecimal, boolean numerica,
            String paso3Override,
            java.util.List<String[]> terminos) {

        StringBuilder sb = new StringBuilder();
        String aH = latexToHTML(aFrac);
        String bH = latexToHTML(bFrac);
        String fH = latexToHTML(funcTex);

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // PASO 1 — Integral planteada
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        sb.append("<div class='proc-title'>PASO 1 &mdash; Plantear la integral</div>");
        String intSym =
            "<span class='int-sym'>∫</span>" +
            "<span class='int-limits'><span>" + bH + "</span><span>" + aH + "</span></span>";
        sb.append("<div class='step'><span class='fn'>")
          .append(intSym)
          .append("<span class='fn'>(" + fH + ")&thinsp;dx</span>")
          .append("</span></div>");

        if (numerica) {
            // ── Numérico
            sb.append("<div class='proc-title'>PROCEDIMIENTO &mdash; Integración numérica</div>");
            sb.append("<div class='step-note'>No se encontro un procedimiento simbolico para esta entrada.<br>" +
                      "Se aplica <strong>cuadratura numérica de Gauss&ndash;Legendre</strong> compuesta con subintervalos.</div>");
            sb.append("<div class='step'><span class='fn'>" +
                      "<span class='int-sym'>∫</span>" +
                      "<span class='int-limits'><span>" + bH + "</span><span>" + aH + "</span></span>" +
                      "f(x)&thinsp;dx &asymp; " +
                      "<span class='fn'>&sum;</span><sub>k</sub> w<sub>k</sub>&thinsp;f(x<sub>k</sub>)" +
                      "</span></div>");
            sb.append("<div class='step-note'>con x<sub>k</sub> y w<sub>k</sub> los nodos y pesos de Gauss&ndash;Legendre " +
                      "de cada subintervalo de [" + aH + ", " + bH + "]</div>");
            sb.append("<div class='final'><span class='eq' style='color:#00c896'>&asymp;</span>&nbsp;" +
                      "<span class='fn'>" + resDecimal + "</span></div>");
            return sb.toString();
        }

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // PASO 2 — Regla(s) aplicadas por término
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        sb.append("<div class='proc-title'>PASO 2 &mdash; Calcular la antiderivada</div>");

        if (terminos != null && !terminos.isEmpty()) {
            if (terminos.size() > 1) {
                sb.append("<div class='step-note'>Se integra término a término (linealidad de la integral):</div>");
                // Mostrar separación por término
                for (String[] t : terminos) {
                    String tOrig = latexToHTML(t[0]);
                    String tAnti = latexToHTML(t[1]);
                    String tRegla= t[2];
                    // Separar el nombre de la regla de la fórmula (viene separado por ":")
                    String[] partes = tRegla.split(":", 2);
                    String nombreRegla = partes[0].trim();
                    String formulaRegla = partes.length > 1 ? latexToHTML(partes[1].trim()) : "";
                    sb.append("<div class='term-block'>");
                    sb.append("<div class='term-rule'><span class='rule-name'>").append(nombreRegla).append("</span>");
                    if (!formulaRegla.isEmpty())
                        sb.append("<span class='rule-formula'>").append(formulaRegla).append("</span>");
                    sb.append("</div>");
                    sb.append("<div class='step'>");
                    sb.append("<span class='fn'><span class='int-sym' style='font-size:1.3em'>∫</span>(")
                      .append(tOrig).append(")&thinsp;dx = ").append(tAnti).append("</span>");
                    sb.append("</div></div>");
                }
            } else {
                // Un solo término
                String[] t = terminos.get(0);
                String[] partes = t[2].split(":", 2);
                String nombreRegla = partes[0].trim();
                String formulaRegla = partes.length > 1 ? latexToHTML(partes[1].trim()) : "";
                sb.append("<div class='term-block'>");
                sb.append("<div class='term-rule'><span class='rule-name'>").append(nombreRegla).append("</span>");
                if (!formulaRegla.isEmpty())
                    sb.append("<span class='rule-formula'>").append(formulaRegla).append("</span>");
                sb.append("</div></div>");
            }
        }

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // PASO 3 — Antiderivada F(x) + C
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        sb.append("<div class='proc-title'>PASO 3 &mdash; Antiderivada F(x)</div>");
        String FxH = latexToHTML(Fx);
        String antd =
            "<span class='bracket-eval'>" +
            "<span class='bk'>[</span>" +
            "<span class='fn'>" + FxH + "</span>" +
            "<span class='bk'>]</span>" +
            "<span class='bk-limits'><span class='bk-sup'>" + bH + "</span>" +
            "<span class='bk-sub'>" + aH + "</span></span>" +
            "</span>";
        // F(x) + C (sin evaluar)
        sb.append("<div class='step'><span class='fn'>F(x) = ").append(FxH).append(" + C</span></div>");
        // Corchete de evaluación
        sb.append("<div class='step'><span class='eq'>=</span>&nbsp;").append(antd).append("</div>");

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // PASO 4 — Sustitución explícita de los límites
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        sb.append("<div class='proc-title'>PASO 4 &mdash; Sustituir los límites</div>");
        sb.append("<div class='step-note'>Se evalúa F(" + bH + ") &minus; F(" + aH + "):</div>");

        String FxB = FxH.replace("x", "(" + bH + ")");
        String FxA = FxH.replace("x", "(" + aH + ")");
        sb.append("<div class='step'><span class='fn'>" +
            "F(" + bH + ") = " + FxB + "</span></div>");
        sb.append("<div class='step'><span class='fn'>" +
            "F(" + aH + ") = " + FxA + "</span></div>");

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // PASO 5 — Valores numéricos F(b) y F(a)
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        sb.append("<div class='proc-title'>PASO 5 &mdash; Calcular F(b) &minus; F(a)</div>");
        String FbH = latexToHTML(FbFrac);
        String FaH = latexToHTML(FaFrac);
        String sust;
        if (paso3Override != null) {
            sust = latexToHTML(paso3Override);
        } else if (FaFrac.startsWith("-")) {
            sust = FbH + " &minus; (" + FaH + ")";
        } else {
            sust = FbH + " &minus; " + FaH;
        }
        sb.append("<div class='step'><span class='eq'>=</span>&nbsp;<span class='fn'>")
          .append(sust).append("</span></div>");

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // RESULTADO FINAL
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        String resH = latexToHTML(resFrac);
        String finalContent;
        if (resDecimal.equals("0") || resDecimal.isEmpty() || resFrac.equals(resDecimal)) {
            finalContent = "<span class='fn'>" + resH + "</span>";
        } else {
            finalContent = "<span class='fn'>" + resH +
                "</span>&nbsp;<span style='color:#aaa;font-size:.82em'>&asymp; " + resDecimal + "</span>";
        }
        sb.append("<div class='final'>" +
            "<span class='eq' style='color:#00c896'>=</span>&nbsp;")
          .append(finalContent).append("</div>");

        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // HTML COMPLETO DE LA CALCULADORA
    // -----------------------------------------------------------------------
    private String buildCalculadoraHTML() {
        return "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>" +
        "<script>window.confirm=function(){return true;};</script>" +
        "<!-- sin CDN externo: renderizado con HTML/CSS puro -->" +
        "<style>" +
        ":root{--bg:#0d0d0f;--panel:#17171c;--card:#1e1e24;--border:#2d2d36;" +
        "      --green:#00c896;--green2:#009970;--amber:#f0a500;--red:#f75a68;" +
        "      --text:#e8e8f0;--muted:#6b6b7e;--white:#ffffff;}" +
        "*{box-sizing:border-box;margin:0;padding:0;}" +
        "html,body{width:100%;height:100%;background:var(--bg);color:var(--text);" +
        "  font-family:'Segoe UI',sans-serif;overflow:hidden;}" +
        ".app{display:grid;grid-template-columns:1fr 1fr;grid-template-rows:auto 1fr;" +
        "  height:100vh;gap:0;}" +

        /* ── HEADER ── */
        ".header{grid-column:1/-1;background:var(--panel);border-bottom:1px solid var(--border);" +
        "  padding:10px 18px;display:flex;align-items:center;gap:12px;}" +
        ".header h1{font-size:15px;font-weight:700;color:var(--white);letter-spacing:.5px;}" +
        ".header p{font-size:11px;color:var(--muted);}" +

        /* ── PANEL IZQUIERDO: CALCULADORA ── */
        ".calc-panel{background:var(--panel);border-right:1px solid var(--border);" +
        "  display:flex;flex-direction:column;padding:14px;gap:10px;overflow-y:auto;}" +

        /* Display de la función */
        ".display-wrap{background:var(--card);border:1.5px solid var(--border);" +
        "  border-radius:10px;padding:10px 14px;min-height:70px;}" +
        ".display-label{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}" +
        "#display-math{min-height:42px;font-size:20px;color:var(--white);word-break:break-all;" +
        "  font-family:'Cambria Math','Segoe UI',serif;display:flex;align-items:center;flex-wrap:wrap;}" +
        "#display-raw{font-size:10px;color:var(--muted);margin-top:4px;word-break:break-all;}" +

        /* Límites */
        ".limits-row{display:flex;gap:8px;}" +
        ".limit-box{flex:1;background:var(--card);border:1.5px solid var(--border);" +
        "  border-radius:8px;padding:6px 10px;}" +
        ".limit-box label{font-size:9px;color:var(--muted);display:block;margin-bottom:2px;}" +
        ".limit-box .lval{font-size:16px;color:var(--white);min-height:22px;cursor:text;}" +

        /* Teclado */
        ".kb{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;}" +
        ".kb button{background:var(--card);color:var(--text);border:1px solid var(--border);" +
        "  border-radius:7px;padding:0;height:40px;font-size:12px;font-weight:600;cursor:pointer;" +
        "  transition:background .12s,transform .08s;}" +
        ".kb button:hover{background:#28282f;border-color:var(--green);color:var(--green);}" +
        ".kb button:active{transform:scale(.95);}" +
        ".kb .fn{font-size:10px;}" +
        ".kb .op{color:var(--amber);border-color:#3a3000;}" +
        ".kb .op:hover{background:#2a2000;border-color:var(--amber);color:var(--amber);}" +
        ".kb .eq{background:var(--green);color:#000;border-color:var(--green);font-size:16px;}" +
        ".kb .eq:hover{background:var(--green2);}" +
        ".kb .del{color:var(--red);border-color:#3a1015;}" +
        ".kb .del:hover{background:#2a0810;border-color:var(--red);color:var(--red);}" +
        ".kb .clr{color:var(--amber);}" +
        ".kb .grph{background:#1a2060;color:#7090ff;border-color:#253080;grid-column:span 2;}" +
        ".kb .grph:hover{background:#202870;}" +
        ".kb .num{font-size:15px;}" +
        ".kb .x-btn{color:var(--green);border-color:#003020;background:#0d1a14;font-size:15px;font-weight:700;}" +
        ".kb .x-btn:hover{background:#102218;border-color:var(--green);}" +

        /* Secciones del teclado */
        ".kb-section{}" +
        ".kb-label{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;" +
        "  margin-bottom:4px;padding-left:2px;}" +

        /* ── PANEL DERECHO: RESULTADO ── */
        ".result-panel{background:var(--bg);display:flex;flex-direction:column;overflow:hidden;}" +
        ".result-header{padding:12px 16px;border-bottom:1px solid var(--border);" +
        "  font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;flex-shrink:0;}" +
        "#result-content{flex:1;overflow-y:auto;padding:18px 20px;}" +
        ".empty-msg{color:var(--muted);text-align:center;margin-top:60px;font-size:13px;}" +

        /* Títulos de cada paso */
        ".proc-title{font-size:10px;color:var(--green);text-transform:uppercase;letter-spacing:1.2px;" +
        "  padding:14px 0 5px;border-top:1px solid #1e1e26;margin-top:6px;font-weight:700;}" +
        ".proc-title:first-child{border-top:none;margin-top:0;}" +

        /* Bloque de cada paso del procedimiento */
        ".step{text-align:center;padding:10px 4px;font-size:1.05em;color:var(--text);" +
        "  line-height:2.2;display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap;}" +

        /* Nota explicativa debajo del título */
        ".step-note{font-size:11px;color:var(--muted);padding:3px 6px 8px;text-align:center;" +
        "  line-height:1.5;}" +

        /* Bloque por término individual */
        ".term-block{background:#1a1a22;border:1px solid #2a2a36;border-radius:8px;" +
        "  margin:6px 0;padding:8px 12px;}" +
        ".term-rule{margin-bottom:4px;display:flex;flex-wrap:wrap;align-items:baseline;gap:8px;}" +
        ".rule-name{font-size:10px;color:#7090ff;font-weight:700;text-transform:uppercase;" +
        "  letter-spacing:.5px;background:#1a1a30;border:1px solid #3040a0;border-radius:4px;" +
        "  padding:2px 7px;}" +
        ".rule-formula{font-size:11px;color:var(--muted);font-family:'Cambria Math','Segoe UI',serif;}" +

        /* Resultado final */
        ".final{background:#0f2820;border:1.5px solid var(--green);border-radius:10px;" +
        "  padding:18px;margin-top:18px;text-align:center;font-size:1.35em;color:#fff;" +
        "  display:flex;align-items:center;justify-content:center;gap:8px;}" +

        ".note{color:var(--muted);font-size:11px;text-align:center;margin:6px 0;}" +
        ".err{color:var(--red);text-align:center;padding:20px;font-size:14px;}" +
        ".eq{color:var(--muted);font-size:1.1em;}" +
        ".fn{font-family:'Cambria Math','Segoe UI',serif;}" +

        /* ── FRACCIONES ── */
        ".frac{display:inline-flex;flex-direction:column;align-items:center;" +
        "  vertical-align:middle;font-size:0.88em;line-height:1.1;margin:0 2px;}" +
        ".frac>span:first-child{border-bottom:1.5px solid currentColor;padding:0 3px 1px;}" +
        ".frac>span:last-child{padding:1px 3px 0;}" +

        /* Potencias superíndice */
        "sup{font-size:0.72em;vertical-align:super;line-height:0;}" +
        "sub{font-size:0.72em;vertical-align:sub;line-height:0;}" +

        /* Límites en corchete de antiderivada */
        ".bracket-eval{display:inline-flex;align-items:stretch;gap:0;vertical-align:middle;}" +
        ".bracket-eval .bk{font-size:1.8em;line-height:1;color:var(--text);}" +
        ".bracket-eval .bk-limits{display:inline-flex;flex-direction:column;font-size:0.7em;justify-content:space-between;vertical-align:middle;margin-left:1px;}" +
        ".bracket-eval .bk-limits .bk-sup{vertical-align:super;}" +
        ".bracket-eval .bk-limits .bk-sub{vertical-align:sub;}" +

        /* Integral grande */
        ".int-sym{font-size:2em;line-height:1;vertical-align:middle;margin:0 1px;}" +
        ".int-limits{display:inline-flex;flex-direction:column;font-size:0.7em;vertical-align:middle;" +
        "  justify-content:space-between;height:1.8em;margin-right:3px;}" +

        "</style></head><body>" +

        "<div class='app'>" +

        // HEADER
        "<div class='header'>" +
        "<div>" +
        "<h1>&#x222B; Calculadora de Integrales Definidas</h1>" +
        "<p>Álgebra Computacional &mdash; Ingreso por teclado</p>" +
        "</div></div>" +

        // PANEL CALCULADORA
        "<div class='calc-panel'>" +

        // Display función
        "<div class='display-wrap' onclick='focusFunction()'>" +
        "<div class='display-label'>f(x)</div>" +
        "<div id='display-math'><span style='color:#3a3a46'>f(x) = ...</span></div>" +
        "<div id='display-raw'></div>" +
        "</div>" +

        // Límites
        "<div class='limits-row'>" +
        "<div class='limit-box' id='box-a' onclick='focusLimit(\"a\")'>" +
        "<label>Límite inferior &nbsp;a</label>" +
        "<div class='lval' id='disp-a'>&mdash;</div>" +
        "</div>" +
        "<div class='limit-box' id='box-b' onclick='focusLimit(\"b\")'>" +
        "<label>Límite superior &nbsp;b</label>" +
        "<div class='lval' id='disp-b'>&mdash;</div>" +
        "</div>" +
        "</div>" +

        // TECLADO
        buildKeyboard() +

        "</div>" + // fin calc-panel

        // PANEL RESULTADO — div directo (no iframe) para que MathJax funcione
        "<div class='result-panel'>" +
        "<div class='result-header'>Procedimiento</div>" +
        "<div id='result-content'>" +
        "<div class='empty-msg'>Ingresa f(x) y los l&iacute;mites, luego presiona = Calcular</div>" +
        "</div>" +
        "</div>" +

        "</div></body>" + buildScript() + "</html>";
    }

    private String buildKeyboard() {
        return
        // ─── Fila funciones científicas ───
        "<div class='kb-label'>Trigonométricas</div>" +
        "<div class='kb'>" +
        btn("sin(x)", "sin(x)", "\\sin(x)", "fn") +
        btn("cos(x)", "cos(x)", "\\cos(x)", "fn") +
        btn("tan(x)", "tan(x)", "\\tan(x)", "fn") +
        btn("cot(x)", "cot(x)", "\\cot(x)", "fn") +
        btn("sec(x)", "sec(x)", "\\sec(x)", "fn") +
        btn("csc(x)", "csc(x)", "\\csc(x)", "fn") +
        btn("sin²(x)", "sin^2(x)", "\\sin^2(x)", "fn") +
        btn("cos²(x)", "cos^2(x)", "\\cos^2(x)", "fn") +
        btn("asin(x)", "asin(x)", "\\arcsin(x)", "fn") +
        btn("acos(x)", "acos(x)", "\\arccos(x)", "fn") +
        "</div>" +

        "<div class='kb-label' style='margin-top:6px'>Inversas / Exp / Log</div>" +
        "<div class='kb'>" +
        btn("atan(x)", "atan(x)", "\\arctan(x)", "fn") +
        btn("eˣ", "exp(x)", "e^{x}", "fn") +
        btn("e^(2x)", "exp(2*x)", "e^{2x}", "fn") +
        btn("ln(x)", "log(x)", "\\ln(x)", "fn") +
        btn("log₂(x)", "log2(x)", "\\log_2(x)", "fn") +
        btn("√( )", "sqrt(", "√(", "fn") +
        btn("∛( )", "cbrt(", "∛(", "fn") +
        btn("1/x", "1/x", "\\frac{1}{x}", "fn") +
        "</div>" +

        "<div class='kb-label' style='margin-top:6px'>Teclado numérico</div>" +
        "<div class='kb'>" +
        // Columna x y potencias
        btn("x", "x", "x", "x-btn") +
        btn("x²", "x^2", "x^{2}", "fn") +
        btn("x³", "x^3", "x^{3}", "fn") +
        btn("xⁿ", "x^", "x^", "fn") +
        btn("( )", "(", "(", "op") +

        btn("7", "7", "7", "num") +
        btn("8", "8", "8", "num") +
        btn("9", "9", "9", "num") +
        btn("÷", "/", "\\div", "op") +
        btn(")", ")", ")", "op") +

        btn("4", "4", "4", "num") +
        btn("5", "5", "5", "num") +
        btn("6", "6", "6", "num") +
        btn("×", "*", "\\times", "op") +
        btn("π", "pi", "\\pi", "fn") +

        btn("1", "1", "1", "num") +
        btn("2", "2", "2", "num") +
        btn("3", "3", "3", "num") +
        btn("−", "-", "-", "op") +
        btn("E", "E", "e", "fn") +

        btn("0", "0", "0", "num") +
        btn(".", ".", ".", "num") +
        btn("^", "^", "^", "op") +
        btn("+", "+", "+", "op") +
        btn("⌫", "DEL", "", "del") +

        btn("AC", "AC", "", "clr") +
        "<button class='grph' onclick='graficar()'>&#x1F4C8; Ver Gráfica</button>" +
        "<button class='eq' style='grid-column:span 2' onclick='calcular()'>= Calcular</button>" +
        "</div>";
    }

    // Genera un botón con expresión evaluable + latex display
    private String btn(String label, String expr, String latex, String cls) {
        String safe = expr.replace("'", "\\'").replace("\\", "\\\\");
        String safeLatex = latex.replace("'", "\\'").replace("\\", "\\\\");
        return "<button class='" + cls + "' onclick=\"push('" + safe + "','" + safeLatex + "')\">" + label + "</button>";
    }

    private String buildScript() {
        return "<script>" +
        // Estado
        "var exprRaw='';" +      // cadena evaluable exp4j
        "var exprLatex='';" +    // cadena LaTeX para display
        "var exprTokens=[];" +
        "var latexTokens=[];" +
        "var limitTarget=null;" + // 'a' | 'b' | null
        "var limitA='';" +
        "var limitB='';" +

        // Convertidor LaTeX→HTML puro (sin MathJax) para el display
        "function latexToHTML(s){" +
        "  if(!s)return '';" +
        // Fracciones \\frac{a}{b}
        "  var safety=0;" +
        "  while(s.indexOf('\\\\frac{')>=0&&safety++<20){" +
        "    var i=s.indexOf('\\\\frac{');" +
        "    var n1=i+5,n2=findClose(s,n1);" +
        "    var num=s.substring(n1+1,n2);" +
        "    var d1=n2+1,d2=findClose(s,d1);" +
        "    var den=s.substring(d1+1,d2);" +
        "    s=s.substring(0,i)+\"<span class='frac'><span>\"+latexToHTML(num)+\"</span><span>\"+latexToHTML(den)+\"</span></span>\"+s.substring(d2+1);" +
        "  }" +
        // Potencias ^{n}
        "  safety=0;" +
        "  while(s.indexOf('^{')>=0&&safety++<20){" +
        "    var i=s.indexOf('^{'),cl=findClose(s,i+1);" +
        "    s=s.substring(0,i)+'<sup>'+latexToHTML(s.substring(i+2,cl))+'</sup>'+s.substring(cl+1);" +
        "  }" +
        // ^n simple
        "  s=s.replace(/\\^(-?\\d+)/g,'<sup>$1</sup>');" +
        // Subíndices _{n}
        "  safety=0;" +
        "  while(s.indexOf('_{')>=0&&safety++<20){" +
        "    var i=s.indexOf('_{'),cl=findClose(s,i+1);" +
        "    s=s.substring(0,i)+'<sub>'+latexToHTML(s.substring(i+2,cl))+'</sub>'+s.substring(cl+1);" +
        "  }" +
        // Corchetes grandes
        "  s=s.replace(/\\\\Big\\[|\\\\Bigl\\[/g,\"<span style='font-size:1.4em'>[</span>\");" +
        "  s=s.replace(/\\\\Big\\]|\\\\Bigr\\]/g,\"<span style='font-size:1.4em'>]</span>\");" +
        "  s=s.replace(/\\\\left\\(/g,'(').replace(/\\\\right\\)/g,')');" +
        "  s=s.replace(/\\\\left\\[/g,'[').replace(/\\\\right\\]/g,']');" +
        // Símbolos
        "  s=s.replace(/\\\\int/g,\"<span style='font-size:1.6em'>∫</span>\");" +
        "  s=s.replace(/\\\\ln/g,'ln').replace(/\\\\log/g,'log');" +
        "  s=s.replace(/\\\\sin/g,'sin').replace(/\\\\cos/g,'cos').replace(/\\\\tan/g,'tan');" +
        "  s=s.replace(/\\\\sec/g,'sec').replace(/\\\\csc/g,'csc').replace(/\\\\cot/g,'cot');" +
        "  s=s.replace(/\\\\sinh/g,'sinh').replace(/\\\\cosh/g,'cosh').replace(/\\\\tanh/g,'tanh');" +
        "  s=s.replace(/\\\\arcsin/g,'arcsin').replace(/\\\\arccos/g,'arccos').replace(/\\\\arctan/g,'arctan');" +
        "  s=s.replace(/\\\\pi/g,'π').replace(/\\\\infty/g,'∞').replace(/\\\\approx/g,'≈');" +
        "  s=s.replace(/\\\\div/g,'/');" +
        // Multiplicación: antes se perdía (quedaba sin símbolo visible) porque
        // caía en la limpieza final de comandos LaTeX sin reconocer; ahora se
        // traduce explícitamente para que se vea bien junto a funciones
        // trigonométricas/logarítmicas (ej: 2\\times\\sin(x) -> 2×sin(x)).
        "  s=s.replace(/\\\\times/g,'×');" +
        "  s=s.replace(/\\\\cdot/g,'·');" +
        // Raíz n-ésima genérica \\sqrt[n]{...} (cúbica u otra) antes de la cuadrada
        "  s=s.replace(/\\\\sqrt\\[(\\d+)\\]\\{([^}]*)\\}/g,function(m,n,inner){return (n=='3'?'∛':'<sup>'+n+'</sup>√')+'('+inner+')';});" +
        "  s=s.replace(/\\\\sqrt\\{([^}]*)\\}/g,'√($1)');" +
        "  s=s.replace(/\\\\[a-zA-Z]+/g,'');" +
        "  return s;" +
        "}" +
        "function findClose(s,open){var d=0;for(var i=open;i<s.length;i++){if(s[i]=='{')d++;else if(s[i]=='}'){d--;if(d==0)return i;}}return s.length-1;}" +

        "function renderMath(id,tex){" +
        "  var el=document.getElementById(id);" +
        "  if(!el)return;" +
        "  if(!tex||tex==='\\\\phantom{x}'){el.innerHTML='<span style=\"color:#3a3a46\">f(x) = ...</span>';return;}" +
        "  el.innerHTML=\"<span class='fn' style='font-size:1em'>\"+latexToHTML(tex)+\"</span>\";" +
        "}" +

        // Actualizar display función
        "function updateDisplay(){" +
        "  exprRaw=exprTokens.join('');" +
        "  exprLatex=latexTokens.join('');" +
        "  renderMath('display-math', exprLatex||'\\\\phantom{x}');" +
        "  document.getElementById('display-raw').textContent=exprRaw;" +
        "}" +

        // Focus en límite
        "function focusLimit(which){" +
        "  limitTarget=which;" +
        "  document.getElementById('box-a').style.borderColor=(which==='a')?'var(--green)':'var(--border)';" +
        "  document.getElementById('box-b').style.borderColor=(which==='b')?'var(--amber)':'var(--border)';" +
        "}" +

        "function focusFunction(){" +
        "  limitTarget=null;" +
        "  document.getElementById('box-a').style.borderColor='var(--border)';" +
        "  document.getElementById('box-b').style.borderColor='var(--border)';" +
        "}" +

        // Actualizar display de límites
        "function updateLimits(){" +
        "  document.getElementById('disp-a').textContent=limitA||'—';" +
        "  document.getElementById('disp-b').textContent=limitB||'—';" +
        "}" +

        "function limpiarTodo(){" +
        "  exprTokens=[];latexTokens=[];exprRaw='';exprLatex='';limitA='';limitB='';limitTarget=null;" +
        "  updateDisplay();updateLimits();" +
        "  document.getElementById('box-a').style.borderColor='var(--border)';" +
        "  document.getElementById('box-b').style.borderColor='var(--border)';" +
        "  mostrarResultado('<div class=\\'empty-msg\\'>Ingresa f(x) y los l&iacute;mites, luego presiona = Calcular<\\/div>');" +
        "}" +

        // Push token
        "function push(expr,latex){" +
        "  if(expr==='AC'){limpiarTodo();return;}" +
        "  if(limitTarget){" +
        "    if(expr==='DEL'){" +
        "      if(limitTarget==='a')limitA=limitA.slice(0,-1);" +
        "      else limitB=limitB.slice(0,-1);" +
        "    } else {" +
        "      if(!/^[0-9.\\-+*/()piE]+$/.test(expr))return;" +
        "      if(limitTarget==='a')limitA+=expr;" +
        "      else limitB+=expr;" +
        "    }" +
        "    updateLimits();return;" +
        "  }" +
        "  if(expr==='DEL'){exprTokens.pop();latexTokens.pop();}" +
        "  else{exprTokens.push(expr);latexTokens.push(latex);}" +
        "  updateDisplay();" +
        "}" +

        // Mostrar resultado directamente en el div del panel (MathJax del padre lo renderiza)
        "function mostrarResultado(html){" +
        "  var div=document.getElementById('result-content');" +
        "  if(!div)return;" +
        "  div.innerHTML=html;" +
        "}" +

        "function mostrarError(msg){mostrarResultado('<div class=\\'err\\'>⚠ '+msg+'<\\/div>');}" +

        "function evaluarNumero(expr){" +
        "  try{" +
        "    var e=expr.replace(/pi/g,'('+Math.PI+')').replace(/E/g,'('+Math.E+')');" +
        "    if(!/^[0-9.\\-+*/() ]+$/.test(e))return NaN;" +
        "    return Function('\"use strict\";return ('+e+')')();" +
        "  }catch(err){return NaN;}" +
        "}" +

        "function tieneParentesisBalanceados(s){" +
        "  var d=0;" +
        "  for(var i=0;i<s.length;i++){if(s[i]==='(')d++;else if(s[i]===')'){d--;if(d<0)return false;}}" +
        "  return d===0;" +
        "}" +

        "function validarEntrada(requireLimits){" +
        "  updateDisplay();" +
        "  if(!exprRaw){mostrarError('Ingresa una funcion');return false;}" +
        "  if(/[+\\-*\\/^.]$/.test(exprRaw)){mostrarError('La funcion no puede terminar con un operador');return false;}" +
        "  if(!tieneParentesisBalanceados(exprRaw)){mostrarError('Revisa los parentesis de la funcion');return false;}" +
        "  if(requireLimits){" +
        "    if(!limitA||!limitB){mostrarError('Completa los limites inferior y superior');return false;}" +
        "    if(/[+\\-*\\/.]$/.test(limitA)||/[+\\-*\\/.]$/.test(limitB)){mostrarError('Revisa los limites: no pueden terminar con operador');return false;}" +
        "    var a=evaluarNumero(limitA),b=evaluarNumero(limitB);" +
        "    if(!isFinite(a)||!isFinite(b)){mostrarError('Los limites deben ser numericos');return false;}" +
        "    if(a===b){mostrarError('Los limites no pueden ser iguales');return false;}" +
        "  }" +
        "  return true;" +
        "}" +

        "function calcular(){" +
        "  if(!validarEntrada(true))return;" +
        "  if(!exprRaw){mostrarError('Ingresa una función');return;}" +
        "  window.alert('CALCULAR|'+exprRaw+'|'+limitA+'|'+limitB);" +
        "}" +

        "function graficar(){" +
        "  if(!validarEntrada(true))return;" +
        "  if(!exprRaw){mostrarError('Ingresa una función');return;}" +
        "  window.alert('GRAFICAR|'+exprRaw+'|'+limitA+'|'+limitB);" +
        "}" +

        "window.onload=function(){" +
        "  updateDisplay();updateLimits();" +
        "};" +
        "</script>";
    }
}
