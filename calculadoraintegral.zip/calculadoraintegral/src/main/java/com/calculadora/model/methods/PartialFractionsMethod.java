package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/**
 * Descomposición en fracciones parciales (factores lineales, repetidos o no).
 * Se dispara ante cualquier división explícita en la expresión.
 */
public class PartialFractionsMethod extends SubstitutionMethod {

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.FRACCIONES_PARCIALES_NO_REPETIDAS;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        String f = function == null ? "" : function.toLowerCase();
        return f.contains("/");
    }

    @Override
    public int prioridad() {
        return 20;
    }
}
