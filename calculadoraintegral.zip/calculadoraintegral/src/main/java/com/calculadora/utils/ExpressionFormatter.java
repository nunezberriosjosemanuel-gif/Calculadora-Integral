package com.calculadora.utils;

public final class ExpressionFormatter {

    private ExpressionFormatter() {
    }

    public static String normalizar(String expresion) {
        if (expresion == null) {
            return "";
        }
        return expresion.trim().replaceAll("\\s+", "");
    }
}

