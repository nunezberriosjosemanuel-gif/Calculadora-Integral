package com.calculadora.model.graph;

public class Graph3DGenerator extends Graph2DGenerator {

    private final double profundidad;

    public Graph3DGenerator(String puntosCurva, String puntosArea, double profundidad) {
        super(puntosCurva, puntosArea);
        this.profundidad = profundidad;
    }

    public double getProfundidad() {
        return profundidad;
    }
}

