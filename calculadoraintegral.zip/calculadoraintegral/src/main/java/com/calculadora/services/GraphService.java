package com.calculadora.services;

import com.calculadora.config.DependencyContainer;
import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;
import com.calculadora.model.methods.AntiderivativeEngine;
import com.calculadora.utils.ExpressionNormalizer;

public class GraphService {

    /**
     * Calcula el área bajo la curva usando exactamente el mismo motor que el
     * panel principal ({@link SolverService}), en vez de una integración
     * numérica de Gauss-Legendre independiente. Antes esta clase llamaba
     * directamente a {@code AntiderivativeEngine.integrarNumericamente}, lo
     * que hacía que el badge "Area = ..." del gráfico pudiera mostrar un
     * valor distinto al resultado exacto que aparece en el panel de
     * procedimiento para la misma función y el mismo intervalo (bug de
     * resultados inconsistentes en la interfaz).
     */
    public double calculateArea(String function, double lowerLimit, double upperLimit) {
        String evaluable = ExpressionNormalizer.forEvaluation(function);
        try {
            IntegralResponse response = DependencyContainer.getSolverService()
                    .solve(new IntegralRequest(function, lowerLimit, upperLimit));
            double valor = response.getValorDefinido();
            if (Double.isFinite(valor)) return valor;
        } catch (Exception ignored) {
            // Si el resolutor simbólico falla por cualquier motivo, se cae al
            // cálculo numérico directo como último recurso.
        }
        return AntiderivativeEngine.integrarNumericamente(evaluable, lowerLimit, upperLimit);
    }
}
