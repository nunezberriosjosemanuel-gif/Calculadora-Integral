package com.calculadora.config;

import com.calculadora.services.ExportService;
import com.calculadora.services.GraphService;
import com.calculadora.services.HistoryService;
import com.calculadora.services.IntegralService;
import com.calculadora.services.SolverService;
import com.calculadora.services.StepService;
import com.calculadora.services.ValidationService;

public final class ServiceFactory {

    private ServiceFactory() {
    }

    public static IntegralService integralService() {
        return DependencyContainer.getIntegralService();
    }

    public static SolverService solverService() {
        return DependencyContainer.getSolverService();
    }

    public static GraphService graphService() {
        return DependencyContainer.getGraphService();
    }

    public static ValidationService validationService() {
        return DependencyContainer.getValidationService();
    }

    public static HistoryService historyService() {
        return DependencyContainer.getHistoryService();
    }

    public static StepService stepService() {
        return DependencyContainer.getStepService();
    }

    public static ExportService exportService() {
        return DependencyContainer.getExportService();
    }
}
