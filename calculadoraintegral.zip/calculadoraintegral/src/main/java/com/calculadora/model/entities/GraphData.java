package com.calculadora.model.entities;

public class GraphData {

    private final String curvePoints;
    private final String areaPoints;

    public GraphData(String curvePoints, String areaPoints) {
        this.curvePoints = curvePoints;
        this.areaPoints = areaPoints;
    }

    public String getCurvePoints() {
        return curvePoints;
    }

    public String getAreaPoints() {
        return areaPoints;
    }
}
