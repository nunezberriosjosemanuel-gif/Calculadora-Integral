package com.calculadora.controllers;

import com.calculadora.config.DependencyContainer;
import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;

public class IntegralController {

    public IntegralResponse resolve(String function, double lowerLimit, double upperLimit) {
        return DependencyContainer.getIntegralService()
                .resolve(new IntegralRequest(function, lowerLimit, upperLimit));
    }
}
