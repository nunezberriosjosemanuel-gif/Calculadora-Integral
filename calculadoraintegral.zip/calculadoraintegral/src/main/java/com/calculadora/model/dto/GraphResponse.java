package com.calculadora.model.dto;

import com.calculadora.model.entities.GraphData;

public class GraphResponse {

    private final GraphData graphData;
    private final double area;

    public GraphResponse(GraphData graphData, double area) {
        this.graphData = graphData;
        this.area = area;
    }

    public GraphData getGraphData() {
        return graphData;
    }

    public double getArea() {
        return area;
    }
}
