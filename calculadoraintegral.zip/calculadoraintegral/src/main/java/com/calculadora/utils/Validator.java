package com.calculadora.utils;

public final class Validator {

    private Validator() {
    }

    public static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
