package com.calculadora.model.parser;

public class Parser {

    private final Lexer lexer = new Lexer();

    public ExpressionTree parse(String expression) {
        return new ExpressionTree(expression, lexer.tokenize(expression));
    }
}
