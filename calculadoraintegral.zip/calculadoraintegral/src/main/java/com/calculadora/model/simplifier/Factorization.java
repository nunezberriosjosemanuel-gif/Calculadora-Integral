package com.calculadora.model.simplifier;

public class Factorization {

    public String apply(String expression) {
        if ("(x^2+x)/x".equals(expression)) {
            return "x+1";
        }
        return expression;
    }
}
