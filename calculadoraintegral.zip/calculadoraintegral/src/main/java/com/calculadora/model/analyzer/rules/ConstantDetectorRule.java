package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta constantes: no contienen la variable "x". */
public class ConstantDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return !f.contains("x");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.CONSTANTE;
    }

    @Override
    public int prioridad() {
        return 90;
    }
}
