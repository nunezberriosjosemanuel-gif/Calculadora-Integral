package com.calculadora.model.entities;

public class Result {

    private final String exactValue;
    private final double decimalValue;

    public Result(String exactValue, double decimalValue) {
        this.exactValue = exactValue;
        this.decimalValue = decimalValue;
    }

    public String getExactValue() {
        return exactValue;
    }

    public double getDecimalValue() {
        return decimalValue;
    }
}
