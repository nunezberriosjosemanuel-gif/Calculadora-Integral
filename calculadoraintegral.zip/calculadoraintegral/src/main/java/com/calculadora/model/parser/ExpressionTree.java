package com.calculadora.model.parser;

import java.util.Collections;
import java.util.List;

public class ExpressionTree {

    private final String source;
    private final List<String> tokens;

    public ExpressionTree(String source, List<String> tokens) {
        this.source = source == null ? "" : source;
        this.tokens = tokens == null ? List.of() : List.copyOf(tokens);
    }

    public String getSource() {
        return source;
    }

    public List<String> getTokens() {
        return Collections.unmodifiableList(tokens);
    }
}
