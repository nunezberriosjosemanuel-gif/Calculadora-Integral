package com.calculadora.model.entities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ResultadoIntegral {

    private final String antiderivadaLatex;
    private final String antiderivadaExpr;
    private final boolean exito;
    private final boolean numerica;
    private final String mensajeError;
    private final List<String[]> terminos;

    public ResultadoIntegral(String antiderivadaLatex, String antiderivadaExpr,
            boolean exito, boolean numerica, String mensajeError, List<String[]> terminos) {
        this.antiderivadaLatex = antiderivadaLatex;
        this.antiderivadaExpr = antiderivadaExpr;
        this.exito = exito;
        this.numerica = numerica;
        this.mensajeError = mensajeError;
        this.terminos = terminos == null ? new ArrayList<>() : new ArrayList<>(terminos);
    }

    public String getAntiderivadaLatex() {
        return antiderivadaLatex;
    }

    public String getAntiderivadaExpr() {
        return antiderivadaExpr;
    }

    public boolean isExito() {
        return exito;
    }

    public boolean isNumerica() {
        return numerica;
    }

    public String getMensajeError() {
        return mensajeError;
    }

    public List<String[]> getTerminos() {
        return Collections.unmodifiableList(terminos);
    }
}
