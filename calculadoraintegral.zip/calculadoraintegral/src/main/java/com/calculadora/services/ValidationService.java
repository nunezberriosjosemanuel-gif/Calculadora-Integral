package com.calculadora.services;

import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.utils.ExpressionNormalizer;
import com.calculadora.utils.Validator;

public class ValidationService {

    private static final int MUESTRAS_DOMINIO = 400;

    public void validate(IntegralRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("La solicitud no puede ser nula");
        }
        if (!Validator.hasText(request.getFuncion())) {
            throw new IllegalArgumentException("Ingresa una funcion");
        }
        if (tieneDivisionAmbigua(request.getFuncion())) {
            throw new IllegalArgumentException("Usa parentesis claros en el denominador. Ejemplo: x/((4*x-1)*(x+2)).");
        }
        double a = request.getIntervalo().getLimiteInferior();
        double b = request.getIntervalo().getLimiteSuperior();
        if (!Double.isFinite(a) || !Double.isFinite(b)) {
            throw new IllegalArgumentException("Los limites deben ser numeros finitos");
        }
        if (a == b) {
            throw new IllegalArgumentException("Los limites no pueden ser iguales");
        }
        verificarDominio(ExpressionNormalizer.forEvaluation(request.getFuncion()), Math.min(a, b), Math.max(a, b));
    }

    private boolean tieneDivisionAmbigua(String funcion) {
        String f = ExpressionNormalizer.forSymbolic(funcion);
        return f.matches(".*/\\([^()]+\\)\\*\\([^()]+\\).*");
    }

    /**
     * Detecta discontinuidades/asíntotas de la función dentro del intervalo
     * (a, b) muestreando el dominio. Sin este chequeo, funciones como
     * 1/(x-1) integradas en [0,3] (que "pasan" por la asíntota x=1) daban un
     * resultado numérico con apariencia válida — F(3)-F(0) evaluado sin más—
     * cuando en realidad esa integral es impropia y, en este caso, diverge.
     * Se avisa explícitamente en vez de mostrar un número engañoso.
     */
    private void verificarDominio(String funcion, double lo, double hi) {
        try {
            detectarPolosLineales(funcion, lo, hi);
            net.objecthunter.exp4j.Expression expr =
                    new net.objecthunter.exp4j.ExpressionBuilder(funcion).variable("x").build();
            double h = (hi - lo) / MUESTRAS_DOMINIO;
            for (int i = 1; i < MUESTRAS_DOMINIO; i++) { // excluye los extremos exactos a y b
                double x = lo + i * h;
                double y;
                try {
                    y = expr.setVariable("x", x).evaluate();
                } catch (Exception evalEx) {
                    // Un solo punto no evaluable no es concluyente (podría ser
                    // ruido del propio muestreo); se ignora y se sigue.
                    continue;
                }
                if (!Double.isFinite(y)) {
                    throw new IllegalArgumentException(
                            "La función no está definida (o tiende a infinito) en x \u2248 "
                            + formatoCorto(x) + ", dentro del intervalo [" + formatoCorto(lo)
                            + ", " + formatoCorto(hi) + "]. Esa es una integral impropia y "
                            + "no puede calcularse como una integral definida ordinaria.");
                }
            }
        } catch (IllegalArgumentException propagar) {
            throw propagar;
        } catch (Exception ignored) {
            // Si el parser de la expresión falla aquí, se deja que el resto
            // del flujo (resolución simbólica) reporte el error real.
        }
    }

    private void detectarPolosLineales(String funcion, double lo, double hi) {
        if (funcion == null || !funcion.contains("/")) {
            return;
        }
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("\\((-?\\d*(?:\\.\\d+)?)\\*?x([+-]\\d+(?:\\.\\d+)?)?\\)")
                .matcher(funcion);
        while (m.find()) {
            double a = parseCoeficienteX(m.group(1));
            double b = m.group(2) == null ? 0.0 : Double.parseDouble(m.group(2));
            if (Math.abs(a) < 1e-12) {
                continue;
            }
            double root = -b / a;
            if (root > lo + 1e-10 && root < hi - 1e-10) {
                throw new IllegalArgumentException(
                        "Integral impropia: la funcion tiene una discontinuidad en x aprox. "
                        + formatoCorto(root) + " dentro del intervalo [" + formatoCorto(lo)
                        + ", " + formatoCorto(hi) + "].");
            }
        }
    }

    private double parseCoeficienteX(String raw) {
        if (raw == null || raw.isEmpty() || raw.equals("+")) {
            return 1.0;
        }
        if (raw.equals("-")) {
            return -1.0;
        }
        return Double.parseDouble(raw);
    }

    private static String formatoCorto(double v) {
        String s = String.format(java.util.Locale.US, "%.4f", v);
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}
