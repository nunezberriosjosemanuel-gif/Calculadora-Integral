package com.calculadora.model.analyzer;

import com.calculadora.model.enums.TipoFuncion;

import java.util.Comparator;
import java.util.List;

/**
 * Clasifica una expresión en un {@link TipoFuncion} recorriendo una lista de
 * {@link FunctionDetectorRule} inyectadas (Chain of Responsibility).
 *
 * Esta clase ya NO contiene lógica de detección propia: solo agrega los
 * resultados de las reglas registradas y decide el tipo final, incluyendo
 * {@code MIXTA} cuando la expresión combina dos categorías "especiales"
 * (trigonométrica, logarítmica, exponencial, irracional, racional) o cuando
 * hay un producto explícito entre una de esas categorías y un término
 * polinómico/lineal — el caso típico que requiere integración por partes.
 *
 * Para soportar un {@link TipoFuncion} nuevo: se crea una clase que
 * implemente {@link FunctionDetectorRule} y se registra en el
 * {@code DependencyContainer}. Este classifier no se toca (Abierto/Cerrado).
 */
public class FunctionClassifier {

    /**
     * Umbral de prioridad que separa las categorías "especiales" (trig, log,
     * exp, irracional, racional -> prioridad <= 50) de las categorías "base"
     * (cuadrática, lineal, polinómica, constante -> prioridad > 50).
     */
    private static final int UMBRAL_TIPO_ESPECIAL = 50;

    private final List<FunctionDetectorRule> reglas;

    public FunctionClassifier(List<FunctionDetectorRule> reglas) {
        this.reglas = reglas;
    }

    public TipoFuncion classify(String expression) {
        List<FunctionDetectorRule> coincidencias = reglas.stream()
                .filter(r -> r.matches(expression))
                .sorted(Comparator.comparingInt(FunctionDetectorRule::prioridad))
                .toList();

        if (coincidencias.isEmpty()) {
            return TipoFuncion.CONSTANTE;
        }

        long especiales = coincidencias.stream()
                .filter(r -> r.prioridad() <= UMBRAL_TIPO_ESPECIAL)
                .map(FunctionDetectorRule::tipo)
                .distinct()
                .count();

        boolean contieneMultiplicacion = expression != null && expression.toLowerCase().contains("*");
        boolean tieneEspecial = coincidencias.stream().anyMatch(r -> r.prioridad() <= UMBRAL_TIPO_ESPECIAL);
        boolean tieneBase = coincidencias.stream().anyMatch(r -> r.prioridad() > UMBRAL_TIPO_ESPECIAL);
        boolean productoExplicito = contieneMultiplicacion && tieneEspecial && tieneBase;

        if (especiales > 1 || productoExplicito) {
            return TipoFuncion.MIXTA;
        }

        return coincidencias.get(0).tipo();
    }
}
