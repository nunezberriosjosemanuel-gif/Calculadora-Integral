package com.calculadora.model.simplifier;

public class AlgebraSimplifier {

    private final Factorization factorization = new Factorization();
    private final ExponentRules exponentRules = new ExponentRules();
    private final TrigonometricIdentities trigonometricIdentities = new TrigonometricIdentities();

    public String simplify(String expression) {
        String simplified = expression == null ? "" : expression.replace(" ", "");
        simplified = exponentRules.apply(simplified);
        simplified = factorization.apply(simplified);
        return trigonometricIdentities.apply(simplified);
    }
}
