module com.calculadora {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires exp4j;

    opens com.calculadora to javafx.fxml;
    opens com.calculadora.controllers to javafx.fxml;
    exports com.calculadora;
    exports com.calculadora.controllers;
    exports com.calculadora.services;
    exports com.calculadora.model.dto;
    exports com.calculadora.model.entities;
    exports com.calculadora.model.enums;
}
