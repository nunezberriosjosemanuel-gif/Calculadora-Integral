package com.calculadora.services;

import com.calculadora.model.entities.Step;
import java.util.ArrayList;
import java.util.List;

public class StepService {

    public List<Step> fromTerms(List<String[]> terms) {
        List<Step> steps = new ArrayList<>();
        if (terms == null) {
            return steps;
        }
        int index = 1;
        for (String[] term : terms) {
            String expression = term.length > 0 ? term[0] : "";
            String result = term.length > 1 ? term[1] : "";
            String rule = term.length > 2 ? term[2] : "";
            steps.add(new Step(index++, expression, rule, result));
        }
        return steps;
    }
}
