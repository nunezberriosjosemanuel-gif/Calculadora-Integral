package com.calculadora.model.strategies;

import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

public interface IntegrationStrategy {

    ResultadoIntegral integrate(String function);

    MetodoIntegracion getMethod();

    /**
     * Indica si esta estrategia puede resolver la función dada. Sustituye la
     * lógica de enrutamiento que antes vivía en {@code StrategyFactory}: cada
     * estrategia decide por sí misma si aplica, en vez de que una clase
     * externa lo decida con un {@code if/else} (Abierto/Cerrado).
     */
    boolean canHandle(String function, TipoFuncion tipo);

    /**
     * Orden de intento cuando varias estrategias podrían aplicar a la vez
     * (menor número = se intenta primero). Replica el orden que tenía la
     * cadena de {@code if/else} original de {@code StrategyFactory}.
     */
    int prioridad();
}
