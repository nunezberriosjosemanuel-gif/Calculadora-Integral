package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/** Reglas directas para exponenciales (e^u, a^u), incluye compuestas por regla de la cadena. */
public class ExponentialMethod extends AntiderivativeMethod {

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.DIRECTA;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return tipo == TipoFuncion.EXPONENCIAL;
    }

    @Override
    public int prioridad() {
        return 50;
    }
}
