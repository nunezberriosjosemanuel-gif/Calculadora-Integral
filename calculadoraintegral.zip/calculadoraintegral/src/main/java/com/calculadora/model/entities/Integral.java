package com.calculadora.model.entities;

public class Integral {

    private final Function function;
    private final Intervalo intervalo;

    public Integral(Function function, Intervalo intervalo) {
        this.function = function;
        this.intervalo = intervalo;
    }

    public Function getFunction() {
        return function;
    }

    public Intervalo getIntervalo() {
        return intervalo;
    }
}
