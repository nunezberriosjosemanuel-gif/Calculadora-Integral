package com.calculadora.model.simplifier;

public class TrigonometricIdentities {

    public String apply(String expression) {
        return expression == null ? "" : expression
                .replace("sin(x)^2+cos(x)^2", "1")
                .replace("cos(x)^2+sin(x)^2", "1");
    }
}
