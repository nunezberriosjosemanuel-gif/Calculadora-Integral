package com.calculadora.model.repository;

import com.calculadora.model.dto.IntegralRequest;
import com.calculadora.model.dto.IntegralResponse;
import java.util.List;

public interface HistoryRepository {

    void save(IntegralRequest request, IntegralResponse response);

    List<IntegralResponse> list();
}
