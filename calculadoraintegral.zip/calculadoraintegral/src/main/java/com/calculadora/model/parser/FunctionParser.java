package com.calculadora.model.parser;

public class FunctionParser {

    private final ExpressionValidator validator = new ExpressionValidator();

    public String parse(String expression) {
        if (!validator.isValid(expression)) {
            throw new IllegalArgumentException("La funcion no puede estar vacia.");
        }
        return expression.trim().replaceAll("\\s+", "");
    }
}
