package com.calculadora.model.simplifier;

public class ExponentRules {

    public String apply(String expression) {
        return expression == null ? "" : expression.replace("x^1", "x");
    }
}
