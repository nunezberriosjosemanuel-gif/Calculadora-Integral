package com.calculadora.config;

import com.calculadora.model.analyzer.FunctionClassifier;
import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.analyzer.rules.ConstantDetectorRule;
import com.calculadora.model.analyzer.rules.ExponentialDetectorRule;
import com.calculadora.model.analyzer.rules.IrrationalDetectorRule;
import com.calculadora.model.analyzer.rules.LinearDetectorRule;
import com.calculadora.model.analyzer.rules.LogarithmicDetectorRule;
import com.calculadora.model.analyzer.rules.PolynomialDetectorRule;
import com.calculadora.model.analyzer.rules.QuadraticDetectorRule;
import com.calculadora.model.analyzer.rules.RationalDetectorRule;
import com.calculadora.model.analyzer.rules.TrigonometricDetectorRule;
import com.calculadora.model.methods.AntiderivativeMethod;
import com.calculadora.model.methods.ExponentialMethod;
import com.calculadora.model.methods.IntegrationByPartsMethod;
import com.calculadora.model.methods.LogarithmicMethod;
import com.calculadora.model.methods.PartialFractionsMethod;
import com.calculadora.model.methods.PolynomialMethod;
import com.calculadora.model.methods.RadicalMethod;
import com.calculadora.model.methods.SubstitutionMethod;
import com.calculadora.model.methods.TrigonometricMethod;
import com.calculadora.model.methods.TrigonometricSubstitutionMethod;
import com.calculadora.model.repository.HistoryRepository;
import com.calculadora.model.repository.HistoryRepositoryImpl;
import com.calculadora.model.simplifier.FactorizationService;
import com.calculadora.model.simplifier.FactorizationServiceImpl;
import com.calculadora.model.solver.SolverEngine;
import com.calculadora.model.strategies.IntegrationStrategy;
import com.calculadora.model.strategies.StrategyRegistry;
import com.calculadora.services.ExportService;
import com.calculadora.services.GraphService;
import com.calculadora.services.HistoryService;
import com.calculadora.services.IntegralService;
import com.calculadora.services.SolverService;
import com.calculadora.services.StepService;
import com.calculadora.services.ValidationService;

import java.util.List;

/**
 * Contenedor de dependencias. Aquí es donde se "cablean" las implementaciones
 * concretas de {@link FunctionDetectorRule} y {@link IntegrationStrategy}:
 * para agregar un tipo de función o un método de integración nuevo, se crea
 * la clase correspondiente y se agrega a la lista de aquí abajo — no hace
 * falta tocar {@code FunctionClassifier}, {@code StrategyRegistry} ni
 * {@code SolverEngine} (Abierto/Cerrado).
 */
public final class DependencyContainer {

    private static final HistoryRepository HISTORY_REPOSITORY = new HistoryRepositoryImpl();

    // --- Clasificación de funciones (Chain of Responsibility) ---
    private static final List<FunctionDetectorRule> DETECTOR_RULES = List.of(
            new TrigonometricDetectorRule(),
            new LogarithmicDetectorRule(),
            new ExponentialDetectorRule(),
            new IrrationalDetectorRule(),
            new RationalDetectorRule(),
            new QuadraticDetectorRule(),
            new LinearDetectorRule(),
            new PolynomialDetectorRule(),
            new ConstantDetectorRule());
    private static final FunctionClassifier FUNCTION_CLASSIFIER = new FunctionClassifier(DETECTOR_RULES);

    // --- Factorización reutilizable (los 10 casos del formulario) ---
    private static final FactorizationService FACTORIZATION_SERVICE = new FactorizationServiceImpl();

    // --- Estrategias de integración (Strategy + Registry con prioridad) ---
    private static final List<IntegrationStrategy> INTEGRATION_STRATEGIES = List.of(
            new TrigonometricSubstitutionMethod(),
            new PartialFractionsMethod(),
            new IntegrationByPartsMethod(),
            new TrigonometricMethod(),
            new LogarithmicMethod(),
            new ExponentialMethod(),
            new RadicalMethod(),
            new PolynomialMethod(),
            new SubstitutionMethod(new AntiderivativeMethod()));
    private static final StrategyRegistry STRATEGY_REGISTRY = new StrategyRegistry(INTEGRATION_STRATEGIES);

    private static final SolverEngine SOLVER_ENGINE = new SolverEngine(FUNCTION_CLASSIFIER, STRATEGY_REGISTRY);

    private static final ValidationService VALIDATION_SERVICE = new ValidationService();
    private static final SolverService SOLVER_SERVICE = new SolverService(SOLVER_ENGINE);
    private static final HistoryService HISTORY_SERVICE = new HistoryService(HISTORY_REPOSITORY);
    private static final IntegralService INTEGRAL_SERVICE =
            new IntegralService(VALIDATION_SERVICE, SOLVER_SERVICE, HISTORY_SERVICE);
    private static final GraphService GRAPH_SERVICE = new GraphService();
    private static final StepService STEP_SERVICE = new StepService();
    private static final ExportService EXPORT_SERVICE = new ExportService();

    private DependencyContainer() {
    }

    public static IntegralService getIntegralService() {
        return INTEGRAL_SERVICE;
    }

    public static SolverService getSolverService() {
        return SOLVER_SERVICE;
    }

    public static GraphService getGraphService() {
        return GRAPH_SERVICE;
    }

    public static ValidationService getValidationService() {
        return VALIDATION_SERVICE;
    }

    public static HistoryService getHistoryService() {
        return HISTORY_SERVICE;
    }

    public static StepService getStepService() {
        return STEP_SERVICE;
    }

    public static ExportService getExportService() {
        return EXPORT_SERVICE;
    }

    public static FactorizationService getFactorizationService() {
        return FACTORIZATION_SERVICE;
    }
}
