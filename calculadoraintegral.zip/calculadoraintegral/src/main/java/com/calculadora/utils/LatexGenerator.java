package com.calculadora.utils;

import com.calculadora.model.methods.AntiderivativeEngine;

public final class LatexGenerator {

    private LatexGenerator() {
    }

    public static String fraccion(double valor) {
        return AntiderivativeEngine.pasarAFraccionLatex(valor);
    }
}

