package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones trigonométricas: sin, cos, tan, sec, csc, cot. */
public class TrigonometricDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("sin") || f.contains("cos") || f.contains("tan")
                || f.contains("sec") || f.contains("csc") || f.contains("cot");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.TRIGONOMETRICA;
    }

    @Override
    public int prioridad() {
        return 10;
    }
}
