package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/** Regla de la potencia para constantes, lineales, cuadráticas y polinomios en general. */
public class PolynomialMethod extends AntiderivativeMethod {

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.DIRECTA;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return tipo == TipoFuncion.POLINOMICA
                || tipo == TipoFuncion.CUADRATICA
                || tipo == TipoFuncion.LINEAL
                || tipo == TipoFuncion.CONSTANTE;
    }

    @Override
    public int prioridad() {
        return 70;
    }
}
