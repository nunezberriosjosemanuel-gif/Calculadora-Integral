package com.calculadora.config;

public final class AppConfig {

    /** Número de subintervalos usados por la cuadratura de Gauss–Legendre (5 nodos c/u). */
    public static final int NUMERIC_QUADRATURE_SUBINTERVALS = 2_000;
    public static final int GRAPH_SAMPLES = 300;

    private AppConfig() {
    }
}