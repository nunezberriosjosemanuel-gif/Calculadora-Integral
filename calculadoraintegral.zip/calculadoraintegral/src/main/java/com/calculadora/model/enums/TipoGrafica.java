package com.calculadora.model.enums;

public enum TipoGrafica {
    DOS_D,
    TRES_D
}
