package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones racionales: contienen una división explícita "/". */
public class RationalDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("/");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.RACIONAL;
    }

    @Override
    public int prioridad() {
        return 50;
    }
}
