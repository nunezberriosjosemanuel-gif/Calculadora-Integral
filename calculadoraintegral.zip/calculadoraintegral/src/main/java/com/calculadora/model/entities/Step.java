package com.calculadora.model.entities;

public class Step {

    private final int number;
    private final String expression;
    private final String rule;
    private final String result;

    public Step(int number, String expression, String rule, String result) {
        this.number = number;
        this.expression = expression;
        this.rule = rule;
        this.result = result;
    }

    public int getNumber() {
        return number;
    }

    public String getExpression() {
        return expression;
    }

    public String getRule() {
        return rule;
    }

    public String getResult() {
        return result;
    }
}
