package com.calculadora.model.methods;

import com.calculadora.model.methods.AntiderivativeEngine;
import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;
import com.calculadora.model.strategies.IntegrationStrategy;

/**
 * Base legado: delega el cálculo real al {@code AntiderivativeEngine}
 * (marcado {@code @Deprecated}, ver plan de migración). Se usa como
 * estrategia de último recurso: {@link #canHandle} siempre devuelve
 * {@code true} con la prioridad más baja del registro.
 */
public class AntiderivativeMethod implements IntegrationStrategy {

    @Override
    public ResultadoIntegral integrate(String function) {
        AntiderivativeEngine.Resultado legacy = AntiderivativeEngine.integrar(function);
        return new ResultadoIntegral(
                legacy.antiderivadaLatex,
                legacy.antiderivadaExpr,
                legacy.exito,
                legacy.esNumerica,
                legacy.mensajeError,
                legacy.terminos);
    }

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.DIRECTA;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return true;
    }

    @Override
    public int prioridad() {
        return 999;
    }
}
