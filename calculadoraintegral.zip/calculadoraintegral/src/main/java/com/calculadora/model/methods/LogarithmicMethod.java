package com.calculadora.model.methods;

import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

/** Reglas directas para logaritmos (log(u), ln(u)), incluye la forma u'/u = ln|u|. */
public class LogarithmicMethod extends IntegrationByPartsMethod {

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        return tipo == TipoFuncion.LOGARITMICA;
    }

    @Override
    public int prioridad() {
        return 40;
    }
}
