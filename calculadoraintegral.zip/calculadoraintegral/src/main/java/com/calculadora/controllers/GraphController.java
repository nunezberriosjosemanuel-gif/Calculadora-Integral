package com.calculadora.controllers;

import com.calculadora.config.DependencyContainer;
import com.calculadora.services.GraphService;
import com.calculadora.utils.ExpressionNormalizer;
import javafx.fxml.FXML;
import javafx.scene.web.WebView;
import javafx.scene.web.WebEngine;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class GraphController {

    @FXML private WebView webGrafica;
    private final GraphService graphService = DependencyContainer.getGraphService();

    public void graficarFuncion(String funcEval, String funcLatex, double limA, double limB) {
        WebEngine engine = webGrafica.getEngine();
        engine.setJavaScriptEnabled(true);
        String funcionEvaluable = ExpressionNormalizer.forEvaluation(funcEval);

        double rango  = limB - limA;
        double margen = Math.max(rango * 0.6, 2.0);
        double xIni   = limA - margen;
        double xFin   = limB + margen;
        int    n      = 300;
        double delta  = (xFin - xIni) / n;

        try {
            Expression expr = new ExpressionBuilder(funcionEvaluable).variable("x").build();

            double[] xs = new double[n + 1];
            double[] ys = new double[n + 1];
            double yMin = Double.MAX_VALUE, yMax = -Double.MAX_VALUE;

            for (int i = 0; i <= n; i++) {
                double x = xIni + i * delta;
                xs[i] = x;
                try {
                    double y = expr.setVariable("x", x).evaluate();
                    ys[i] = Double.isFinite(y) ? y : Double.NaN;
                    if (Double.isFinite(y)) { yMin = Math.min(yMin, y); yMax = Math.max(yMax, y); }
                } catch (Exception e2) { ys[i] = Double.NaN; }
            }

            if (yMin == Double.MAX_VALUE || yMax == -Double.MAX_VALUE) {
                engine.loadContent("<body style='background:#0d0d0f;color:#f75a68;padding:30px;font-family:sans-serif;'>No hay puntos finitos para graficar en este intervalo.</body>");
                return;
            }

            yMin = Math.min(yMin, 0);
            yMax = Math.max(yMax, 0);
            double yRange  = yMax - yMin;
            double yMargen = yRange == 0 ? 2.0 : yRange * 0.2;
            yMin -= yMargen; yMax += yMargen;

            // Puntos área
            StringBuilder ptsCurva = new StringBuilder("[");
            StringBuilder ptsArea  = new StringBuilder("[");
            boolean firstC = true, firstA = true;
            for (int i = 0; i <= n; i++) {
                if (Double.isNaN(ys[i])) { firstC = false; continue; }
                if (!firstC) ptsCurva.append(",");
                ptsCurva.append("[").append(fmt(xs[i])).append(",").append(fmt(ys[i])).append("]");
                firstC = false;
                if (xs[i] >= limA - 1e-9 && xs[i] <= limB + 1e-9) {
                    if (!firstA) ptsArea.append(",");
                    ptsArea.append("[").append(fmt(xs[i])).append(",").append(fmt(ys[i])).append("]");
                    firstA = false;
                }
            }
            ptsCurva.append("]");
            ptsArea.append("]");

            double areaNum = graphService.calculateArea(funcionEvaluable, limA, limB);
            String areaStr = !Double.isFinite(areaNum) ? "no definida" : String.format(java.util.Locale.US, "%.4f", areaNum);

            String html = buildHTML(funcLatex, ptsCurva.toString(), ptsArea.toString(),
                xIni, xFin, yMin, yMax, limA, limB, areaStr);
            engine.loadContent(html);

        } catch (Exception e) {
            engine.loadContent("<body style='background:#0d0d0f;color:#f75a68;padding:30px;font-family:sans-serif;'>Error: " + e.getMessage() + "</body>");
        }
    }

    private String buildHTML(String funcLatex, String ptsCurva, String ptsArea,
            double xIni, double xFin, double yMin, double yMax,
            double limA, double limB, String areaStr) {

        // Script JS 3D puro con canvas (sin librerias externas - funciona en WebView JavaFX)
        return "<!DOCTYPE html><html><head><meta charset='UTF-8'>" +
        "<script>window.alert=function(){};</script>" +
        "<style>" +
        "*{box-sizing:border-box;margin:0;padding:0;}" +
        "body{background:#0d0d0f;color:#e8e8f0;font-family:'Segoe UI',Arial,sans-serif;" +
        "  height:100vh;display:flex;flex-direction:column;overflow:hidden;}" +
        ".toolbar{background:#17171c;border-bottom:1px solid #2d2d36;padding:8px 14px;" +
        "  display:flex;align-items:center;gap:12px;flex-wrap:wrap;min-height:40px;}" +
        ".func{font-size:13px;color:#00c896;font-weight:700;}" +
        ".info{font-size:11px;color:#6b6b7e;}" +
        ".badge{background:#0f2820;border:1px solid #00c896;border-radius:5px;" +
        "  padding:3px 9px;font-size:12px;color:#00c896;}" +
        ".btn{background:#1e1e24;border:1px solid #2d2d36;border-radius:6px;" +
        "  color:#e8e8f0;padding:4px 12px;font-size:12px;cursor:pointer;" +
        "  transition:all .15s;font-family:inherit;}" +
        ".btn:hover{border-color:#00c896;color:#00c896;}" +
        ".btn.on{background:#0f2820;border-color:#00c896;color:#00c896;}" +
        "#wrap{flex:1;position:relative;}" +
        "canvas{position:absolute;top:0;left:0;width:100%;height:100%;display:block;}" +
        ".hint{position:absolute;bottom:8px;right:12px;font-size:10px;color:#3a3a46;" +
        "  pointer-events:none;background:rgba(13,13,15,.7);padding:3px 7px;border-radius:4px;}" +
        ".legend{background:#17171c;border-top:1px solid #2d2d36;padding:7px 14px;" +
        "  display:flex;gap:18px;font-size:11px;}" +
        ".li{display:flex;align-items:center;gap:6px;}" +
        ".ld{width:14px;height:3px;border-radius:2px;}" +
        "</style></head><body>" +

        "<div class='toolbar'>" +
        "<span class='func'>f(x) = " + funcLatex + "</span>" +
        "<span class='info'>Intervalo: [" + fmt(limA) + ", " + fmt(limB) + "]</span>" +
        "<span class='badge'>Area = " + areaStr + "</span>" +
        "<button class='btn on' id='b3' onclick='modo3D()'>3D</button>" +
        "<button class='btn' id='b2' onclick='modo2D()'>2D</button>" +
        "</div>" +

        "<div id='wrap'>" +
        "<canvas id='cv'></canvas>" +
        "<div class='hint' id='ht'>Arrastra: rotar | Scroll: zoom</div>" +
        "</div>" +

        "<div class='legend'>" +
        "<div class='li'><div class='ld' style='background:#00c896'></div><span>f(x)</span></div>" +
        "<div class='li'><div class='ld' style='background:#f0a500;height:8px'></div><span>Area [a,b]</span></div>" +
        "<div class='li'><div class='ld' style='background:#7090ff;width:2px;height:14px'></div><span>x=a, x=b</span></div>" +
        "</div>" +

        "<script>" +
        "var PC=" + ptsCurva + ";" +
        "var PA=" + ptsArea + ";" +
        "var XLO=" + fmt(xIni) + ",XHI=" + fmt(xFin) + ";" +
        "var YLO=" + fmt(yMin) + ",YHI=" + fmt(yMax) + ";" +
        "var LA=" + fmt(limA) + ",LB=" + fmt(limB) + ";" +

        // Estado 3D
        "var rotX=0.38,rotY=-0.55,zoom=1.0,drag=false,mx0=0,my0=0,rx0=0,ry0=0;" +
        "var is3D=true,animId=null;" +
        "var cv=document.getElementById('cv');" +
        "var ctx=cv.getContext('2d');" +

        // ─── PROYECCIÓN 3D MANUAL (sin librerías) ───
        // Normaliza coord mundo a [-3,3]x[0,3]x[-1.5,0]
        "var XR=XHI-XLO, YR=Math.max(YHI-YLO,0.001);" +
        "function wx(x){return (x-XLO)/XR*6-3;}" +
        "function wy(y){return (y-YLO)/YR*3;}" +

        // Transforma punto 3D mundo → 2D pantalla con rotación orbital
        "function proj(wx2,wy2,wz){" +
        // Rotación Y (horizontal)
        "  var cosY=Math.cos(rotY),sinY=Math.sin(rotY);" +
        "  var x1=wx2*cosY-wz*sinY;" +
        "  var z1=wx2*sinY+wz*cosY;" +
        // Rotación X (vertical)  
        "  var cosX=Math.cos(rotX),sinX=Math.sin(rotX);" +
        "  var y2=wy2*cosX-z1*sinX;" +
        "  var z2=wy2*sinX+z1*cosX;" +
        // Perspectiva
        "  var d=7*zoom,fov=4.5;" +
        "  var scale=fov/(d+z2);" +
        "  var W=cv.width,H=cv.height;" +
        "  return [W/2+x1*scale*Math.min(W,H)*0.4, H/2-y2*scale*Math.min(W,H)*0.4];" +
        "}" +

        // Proyecta array [wx,wy,wz]
        "function p3(a){return proj(a[0],a[1],a[2]);}" +

        // ─── DIBUJO 3D ───
        "function draw3D(){" +
        "  var W=cv.offsetWidth,H=cv.offsetHeight;" +
        "  cv.width=W;cv.height=H;" +
        "  ctx.fillStyle='#0d0d0f';ctx.fillRect(0,0,W,H);" +

        // Grid en plano Y=0
        "  ctx.strokeStyle='#1e1e26';ctx.lineWidth=0.8;" +
        "  for(var gx=-3;gx<=3.01;gx+=0.75){" +
        "    ctx.beginPath();" +
        "    var a=p3([gx,0,-1.5]),b=p3([gx,0,0]);" +
        "    ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();" +
        "  }" +
        "  for(var gz=-1.5;gz<=0.01;gz+=0.75){" +
        "    ctx.beginPath();" +
        "    var a=p3([-3,0,gz]),b=p3([3,0,gz]);" +
        "    ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();" +
        "  }" +

        // Ejes
        "  ctx.lineWidth=1.5;" +
        "  function eje(p1,p2,col){ctx.strokeStyle=col;ctx.beginPath();var a=p3(p1),b=p3(p2);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();}" +
        "  eje([-3,0,-0.75],[3,0,-0.75],'#3a3a46');" + // eje X
        "  eje([0,0,-0.75],[0,3.2,-0.75],'#3a3a46');" + // eje Y
        "  eje([-3,0,-1.5],[-3,0,0.2],'#3a3a46');" +   // eje Z

        // Etiquetas ejes
        "  function label3(pt,txt,col){var p=p3(pt);ctx.fillStyle=col;ctx.font='bold 11px Segoe UI,Arial';ctx.textAlign='center';ctx.fillText(txt,p[0],p[1]);}" +
        "  label3([3.3,0,-0.75],'x','#00c896');" +
        "  label3([0,3.4,-0.75],'f(x)','#00c896');" +
        "  label3([-3.1,0,0.35],'z','#6b6b7e');" +

        // Superficie área (extrusión 3D desde z=0 a z=-1.5)
        "  if(PA.length>1){" +
        "    var depth=-1.4;" +
        "    var y0w=wy(0);" +
        // Cara frontal z=0
        "    ctx.beginPath();" +
        "    var p0=p3([wx(PA[0][0]),y0w,0]);ctx.moveTo(p0[0],p0[1]);" +
        "    for(var i=0;i<PA.length;i++){var p=p3([wx(PA[i][0]),wy(PA[i][1]),0]);ctx.lineTo(p[0],p[1]);}" +
        "    var pe=p3([wx(PA[PA.length-1][0]),y0w,0]);ctx.lineTo(pe[0],pe[1]);ctx.closePath();" +
        "    ctx.fillStyle='rgba(240,165,0,0.22)';ctx.fill();" +
        "    ctx.strokeStyle='#f0a50088';ctx.lineWidth=1.2;ctx.stroke();" +
        // Cara trasera z=depth
        "    ctx.beginPath();" +
        "    var p0b=p3([wx(PA[0][0]),y0w,depth]);ctx.moveTo(p0b[0],p0b[1]);" +
        "    for(var i=0;i<PA.length;i++){var p=p3([wx(PA[i][0]),wy(PA[i][1]),depth]);ctx.lineTo(p[0],p[1]);}" +
        "    var peb=p3([wx(PA[PA.length-1][0]),y0w,depth]);ctx.lineTo(peb[0],peb[1]);ctx.closePath();" +
        "    ctx.fillStyle='rgba(240,165,0,0.14)';ctx.fill();" +
        "    ctx.strokeStyle='#f0a50066';ctx.lineWidth=1;ctx.stroke();" +
        // Laterales izquierdo y derecho
        "    function quad(w1,h1,w2,h2,z1,z2,fill,str){" +
        "      ctx.beginPath();" +
        "      var a=p3([w1,h1,z1]),b=p3([w1,h1,z2]),cc=p3([w2,h2,z2]),dd=p3([w2,h2,z1]);" +
        "      ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(cc[0],cc[1]);ctx.lineTo(dd[0],dd[1]);ctx.closePath();" +
        "      ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle=str;ctx.lineWidth=1;ctx.stroke();" +
        "    }" +
        "    var wxA=wx(PA[0][0]),wyA=wy(PA[0][1]);" +
        "    var wxB=wx(PA[PA.length-1][0]),wyB=wy(PA[PA.length-1][1]);" +
        "    quad(wxA,y0w,wxA,wyA,0,depth,'rgba(240,165,0,0.18)','#f0a50055');" +
        "    quad(wxB,y0w,wxB,wyB,0,depth,'rgba(240,165,0,0.18)','#f0a50055');" +
        // Techo (superficie superior)
        "    for(var i=0;i<PA.length-1;i++){" +
        "      var x1=wx(PA[i][0]),y1=wy(PA[i][1]);" +
        "      var x2=wx(PA[i+1][0]),y2=wy(PA[i+1][1]);" +
        "      quad(x1,y1,x2,y2,0,depth,'rgba(240,165,0,0.16)','#f0a50033');" +
        "    }" +
        // Aristas superiores z=0 y z=depth (borde brillante)
        "    ctx.beginPath();ctx.strokeStyle='#f0a500';ctx.lineWidth=2;" +
        "    var q=p3([wx(PA[0][0]),wy(PA[0][1]),0]);ctx.moveTo(q[0],q[1]);" +
        "    for(var i=1;i<PA.length;i++){var q=p3([wx(PA[i][0]),wy(PA[i][1]),0]);ctx.lineTo(q[0],q[1]);}ctx.stroke();" +
        "    ctx.beginPath();ctx.strokeStyle='#f0a500aa';ctx.lineWidth=1.5;" +
        "    var q=p3([wx(PA[0][0]),wy(PA[0][1]),depth]);ctx.moveTo(q[0],q[1]);" +
        "    for(var i=1;i<PA.length;i++){var q=p3([wx(PA[i][0]),wy(PA[i][1]),depth]);ctx.lineTo(q[0],q[1]);}ctx.stroke();" +
        "  }" +

        // Líneas verticales a y b (en z=0 y z=-1.4)
        "  ctx.setLineDash([5,3]);ctx.strokeStyle='#7090ff';ctx.lineWidth=1.5;" +
        "  function vline(xw){" +
        "    var bot=p3([xw,wy(0),0]),top=p3([xw,wy(YHI),-0.75]);" +
        "    ctx.beginPath();ctx.moveTo(bot[0],bot[1]);ctx.lineTo(top[0],top[1]);ctx.stroke();" +
        "  }" +
        "  vline(wx(LA));vline(wx(LB));" +
        "  ctx.setLineDash([]);" +

        // Etiquetas a y b
        "  ctx.fillStyle='#7090ff';ctx.font='bold 11px Segoe UI,Arial';ctx.textAlign='center';" +
        "  var pa=p3([wx(LA),wy(YHI)+0.25,-0.75]);ctx.fillText('a='+LA,pa[0],pa[1]-6);" +
        "  var pb=p3([wx(LB),wy(YHI)+0.25,-0.75]);ctx.fillText('b='+LB,pb[0],pb[1]-6);" +

        // Curva f(x) en z=0
        "  ctx.beginPath();ctx.strokeStyle='#00c896';ctx.lineWidth=2.5;" +
        "  var moved=false;" +
        "  for(var i=0;i<PC.length;i++){" +
        "    var pt=PC[i];if(!pt){moved=false;continue;}" +
        "    var p=p3([wx(pt[0]),wy(pt[1]),0]);" +
        "    if(!moved){ctx.moveTo(p[0],p[1]);moved=true;}else ctx.lineTo(p[0],p[1]);" +
        "  }ctx.stroke();" +
        // Misma curva en z=depth (sombra)
        "  ctx.beginPath();ctx.strokeStyle='#00c89655';ctx.lineWidth=1.5;" +
        "  moved=false;" +
        "  for(var i=0;i<PC.length;i++){" +
        "    var pt=PC[i];if(!pt){moved=false;continue;}" +
        "    var p=p3([wx(pt[0]),wy(pt[1]),-1.4]);" +
        "    if(!moved){ctx.moveTo(p[0],p[1]);moved=true;}else ctx.lineTo(p[0],p[1]);" +
        "  }ctx.stroke();" +
        "}" + // fin draw3D

        // ─── DIBUJO 2D ───
        "var PAD2={t:30,r:40,b:50,l:60};" +
        "function draw2D(){" +
        "  var W=cv.offsetWidth,H=cv.offsetHeight;" +
        "  cv.width=W;cv.height=H;" +
        "  var PW=W-PAD2.l-PAD2.r,PH=H-PAD2.t-PAD2.b;" +
        "  function px(x){return PAD2.l+(x-XLO)/XR*PW;}" +
        "  function py(y){return PAD2.t+(YHI-y)/YR*PH;}" +
        "  function nt(r,m){var raw=r/m,mag=Math.pow(10,Math.floor(Math.log10(raw)));var n=[1,2,2.5,5,10];for(var i=0;i<n.length;i++)if(n[i]*mag>=raw)return n[i]*mag;return 10*mag;}" +
        "  ctx.fillStyle='#0d0d0f';ctx.fillRect(0,0,W,H);" +
        "  ctx.save();ctx.beginPath();ctx.rect(PAD2.l,PAD2.t,PW,PH);ctx.clip();" +
        "  ctx.fillStyle='#18181c';ctx.fillRect(PAD2.l,PAD2.t,PW,PH);" +
        "  var xT=nt(XHI-XLO,10),yT=nt(YHI-YLO,8);" +
        "  ctx.strokeStyle='#1e1e26';ctx.lineWidth=1;" +
        "  for(var g=Math.ceil(XLO/xT)*xT;g<=XHI+1e-9;g+=xT){ctx.beginPath();ctx.moveTo(px(g),PAD2.t);ctx.lineTo(px(g),PAD2.t+PH);ctx.stroke();}" +
        "  for(var g=Math.ceil(YLO/yT)*yT;g<=YHI+1e-9;g+=yT){ctx.beginPath();ctx.moveTo(PAD2.l,py(g));ctx.lineTo(PAD2.l+PW,py(g));ctx.stroke();}" +
        "  ctx.strokeStyle='#3a3a46';ctx.lineWidth=1.5;" +
        "  var y0=py(0);if(y0>=PAD2.t&&y0<=PAD2.t+PH){ctx.beginPath();ctx.moveTo(PAD2.l,y0);ctx.lineTo(PAD2.l+PW,y0);ctx.stroke();}" +
        "  var x0=px(0);if(x0>=PAD2.l&&x0<=PAD2.l+PW){ctx.beginPath();ctx.moveTo(x0,PAD2.t);ctx.lineTo(x0,PAD2.t+PH);ctx.stroke();}" +
        "  if(PA.length>1){ctx.beginPath();var y0p=py(0);ctx.moveTo(px(PA[0][0]),y0p);for(var i=0;i<PA.length;i++)ctx.lineTo(px(PA[i][0]),py(PA[i][1]));ctx.lineTo(px(PA[PA.length-1][0]),y0p);ctx.closePath();ctx.fillStyle='rgba(240,165,0,0.2)';ctx.fill();ctx.strokeStyle='#f0a500';ctx.lineWidth=2;ctx.stroke();}" +
        "  ctx.setLineDash([5,4]);ctx.strokeStyle='#7090ff';ctx.lineWidth=1.5;" +
        "  ctx.beginPath();ctx.moveTo(px(LA),PAD2.t);ctx.lineTo(px(LA),PAD2.t+PH);ctx.stroke();" +
        "  ctx.beginPath();ctx.moveTo(px(LB),PAD2.t);ctx.lineTo(px(LB),PAD2.t+PH);ctx.stroke();" +
        "  ctx.setLineDash([]);" +
        "  ctx.beginPath();ctx.strokeStyle='#00c896';ctx.lineWidth=2.5;var mv=false;" +
        "  for(var i=0;i<PC.length;i++){var pt=PC[i];if(!pt){mv=false;continue;}var cx=px(pt[0]),cy=py(pt[1]);if(!mv){ctx.moveTo(cx,cy);mv=true;}else ctx.lineTo(cx,cy);}ctx.stroke();" +
        "  ctx.restore();" +
        "  ctx.fillStyle='#9090a0';ctx.font='10px Segoe UI,Arial';ctx.textAlign='center';" +
        "  for(var g=Math.ceil(XLO/xT)*xT;g<=XHI+1e-9;g+=xT){var gp=px(g);if(gp<PAD2.l-2||gp>PAD2.l+PW+2)continue;ctx.fillText(parseFloat(g.toFixed(3)),gp,PAD2.t+PH+14);}" +
        "  ctx.textAlign='right';" +
        "  for(var g=Math.ceil(YLO/yT)*yT;g<=YHI+1e-9;g+=yT){var gp=py(g);if(gp<PAD2.t-2||gp>PAD2.t+PH+2)continue;ctx.fillText(parseFloat(g.toFixed(3)),PAD2.l-8,gp+3);}" +
        "  ctx.fillStyle='#00c896';ctx.font='bold 12px Segoe UI,Arial';ctx.textAlign='center';" +
        "  ctx.fillText('x',PAD2.l+PW+30,PAD2.t+PH+4);" +
        "  ctx.save();ctx.translate(14,PAD2.t+PH/2);ctx.rotate(-Math.PI/2);ctx.fillText('f(x)',0,0);ctx.restore();" +
        "  ctx.fillStyle='#7090ff';ctx.font='bold 11px Segoe UI,Arial';ctx.textAlign='center';" +
        "  ctx.fillText('a='+LA,px(LA),PAD2.t-8);ctx.fillText('b='+LB,px(LB),PAD2.t-8);" +
        "}" +

        // Render loop animado 3D (suave)
        "function renderLoop(){if(!is3D)return;draw3D();animId=requestAnimationFrame(renderLoop);}" +

        // Cambio de modo
        "function modo3D(){is3D=true;document.getElementById('b3').className='btn on';document.getElementById('b2').className='btn';document.getElementById('ht').textContent='Arrastra: rotar | Scroll: zoom';if(!animId||animId==-1)renderLoop();}" +
        "function modo2D(){is3D=false;if(animId)cancelAnimationFrame(animId);animId=-1;document.getElementById('b2').className='btn on';document.getElementById('b3').className='btn';document.getElementById('ht').textContent='Vista plana 2D';draw2D();}" +

        // Controles mouse 3D
        "cv.addEventListener('mousedown',function(e){drag=true;mx0=e.clientX;my0=e.clientY;rx0=rotX;ry0=rotY;});" +
        "cv.addEventListener('mousemove',function(e){if(!drag||!is3D)return;var dx=(e.clientX-mx0)*0.008,dy=(e.clientY-my0)*0.008;rotY=ry0+dx;rotX=Math.max(-1.3,Math.min(1.3,rx0+dy));});" +
        "cv.addEventListener('mouseup',function(){drag=false;});" +
        "cv.addEventListener('mouseleave',function(){drag=false;});" +
        "cv.addEventListener('wheel',function(e){zoom*=(e.deltaY>0)?1.1:0.9;zoom=Math.max(0.25,Math.min(5,zoom));e.preventDefault();},{passive:false});" +

        // Resize
        "window.addEventListener('resize',function(){if(is3D)draw3D();else draw2D();});" +

        // Init
        "window.onload=function(){renderLoop();};" +
        "</script></body></html>";
    }

    private String fmt(double v) {
        if (v == Math.floor(v) && Math.abs(v) < 1e9 && !Double.isInfinite(v))
            return String.valueOf((long) v);
        return String.format(java.util.Locale.US, "%.4f", v)
            .replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}
