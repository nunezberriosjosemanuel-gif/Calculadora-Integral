package com.calculadora.model.graph;

public class Graph2DGenerator {

    private final String puntosCurva;
    private final String puntosArea;

    public Graph2DGenerator(String puntosCurva, String puntosArea) {
        this.puntosCurva = puntosCurva;
        this.puntosArea = puntosArea;
    }

    public String getPuntosCurva() {
        return puntosCurva;
    }

    public String getPuntosArea() {
        return puntosArea;
    }
}

