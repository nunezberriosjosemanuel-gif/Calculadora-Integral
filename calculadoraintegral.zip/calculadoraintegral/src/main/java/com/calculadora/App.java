package com.calculadora;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import com.calculadora.config.RouteManager;

public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("Main"), 920, 680);
        stage.setTitle("Calculadora de Integrales Definidas");
        stage.setMinWidth(700);
        stage.setMinHeight(550);
        stage.setScene(scene);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader l = new FXMLLoader(App.class.getResource(RouteManager.view(fxml)));
        return l.load();
    }

    public static void main(String[] args) { launch(); }
}
