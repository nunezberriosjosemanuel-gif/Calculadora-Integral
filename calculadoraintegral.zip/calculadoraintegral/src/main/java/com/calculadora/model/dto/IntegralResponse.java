package com.calculadora.model.dto;

import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

public class IntegralResponse {

    private final ResultadoIntegral resultado;
    private final TipoFuncion tipoFuncion;
    private final MetodoIntegracion metodoIntegracion;
    private final double valorDefinido;

    public IntegralResponse(ResultadoIntegral resultado, TipoFuncion tipoFuncion,
            MetodoIntegracion metodoIntegracion, double valorDefinido) {
        this.resultado = resultado;
        this.tipoFuncion = tipoFuncion;
        this.metodoIntegracion = metodoIntegracion;
        this.valorDefinido = valorDefinido;
    }

    public ResultadoIntegral getResultado() {
        return resultado;
    }

    public TipoFuncion getTipoFuncion() {
        return tipoFuncion;
    }

    public MetodoIntegracion getMetodoIntegracion() {
        return metodoIntegracion;
    }

    public double getValorDefinido() {
        return valorDefinido;
    }
}
