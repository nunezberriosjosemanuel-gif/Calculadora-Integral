package com.calculadora.model.enums;

public enum TipoFuncion {
    EXPONENCIAL,
    LOGARITMICA,
    TRIGONOMETRICA,
    IRRACIONAL,
    RACIONAL,
    CUADRATICA,
    LINEAL,
    CONSTANTE,
    POLINOMICA,
    MIXTA
}
