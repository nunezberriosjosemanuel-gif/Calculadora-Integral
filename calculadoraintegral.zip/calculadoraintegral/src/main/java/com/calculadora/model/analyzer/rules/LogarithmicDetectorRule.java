package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones logarítmicas: log(...), ln(...). */
public class LogarithmicDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("log") || f.contains("ln");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.LOGARITMICA;
    }

    @Override
    public int prioridad() {
        return 20;
    }
}
