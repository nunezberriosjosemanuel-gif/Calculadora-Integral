package com.calculadora.model.strategies;

import com.calculadora.model.enums.TipoFuncion;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Registro de estrategias de integración disponibles. Reemplaza a
 * {@code StrategyFactory}: en vez de un método gigante que decide con
 * {@code if/else} qué clase concreta instanciar, cada {@link IntegrationStrategy}
 * ya sabe si puede resolver una función ({@link IntegrationStrategy#canHandle}),
 * y este registro solo filtra y ordena por prioridad.
 *
 * Agregar una estrategia nueva = crear la clase e inscribirla en el
 * {@code DependencyContainer}; este registro no cambia (Abierto/Cerrado).
 */
public class StrategyRegistry {

    private final List<IntegrationStrategy> estrategias;

    public StrategyRegistry(List<IntegrationStrategy> estrategias) {
        this.estrategias = estrategias;
    }

    /** Devuelve la estrategia de mayor prioridad que pueda resolver la función. */
    public Optional<IntegrationStrategy> seleccionar(String function, TipoFuncion tipo) {
        return candidatos(function, tipo).stream().findFirst();
    }

    /** Devuelve todas las estrategias aplicables, ordenadas por prioridad ascendente. */
    public List<IntegrationStrategy> candidatos(String function, TipoFuncion tipo) {
        return estrategias.stream()
                .filter(s -> s.canHandle(function, tipo))
                .sorted(Comparator.comparingInt(IntegrationStrategy::prioridad))
                .toList();
    }
}
