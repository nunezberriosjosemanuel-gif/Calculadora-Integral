package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones exponenciales: exp(...), e^... */
public class ExponentialDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("exp") || f.contains("e^");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.EXPONENCIAL;
    }

    @Override
    public int prioridad() {
        return 30;
    }
}
