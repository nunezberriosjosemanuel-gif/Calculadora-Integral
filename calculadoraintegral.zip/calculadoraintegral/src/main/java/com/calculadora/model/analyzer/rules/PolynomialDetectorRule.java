package com.calculadora.model.analyzer.rules;

import com.calculadora.model.analyzer.FunctionDetectorRule;
import com.calculadora.model.enums.TipoFuncion;

/** Detecta funciones polinómicas: fallback genérico cuando aparece "x". */
public class PolynomialDetectorRule implements FunctionDetectorRule {

    @Override
    public boolean matches(String expression) {
        String f = expression == null ? "" : expression.toLowerCase();
        return f.contains("x");
    }

    @Override
    public TipoFuncion tipo() {
        return TipoFuncion.POLINOMICA;
    }

    @Override
    public int prioridad() {
        return 80;
    }
}
