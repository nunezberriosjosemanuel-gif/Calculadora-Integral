package com.calculadora.model.methods;

import com.calculadora.model.entities.ResultadoIntegral;
import com.calculadora.model.enums.MetodoIntegracion;
import com.calculadora.model.enums.TipoFuncion;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Integración por partes: producto de funciones de distinta naturaleza
 * (∫ u dv = u·v - ∫ v du). Se dispara cuando el clasificador detecta
 * {@code TipoFuncion.MIXTA} (p. ej. x*sin(x)) o cuando el patrón de texto
 * clásico de un producto polinomio/trascendente está presente.
 *
 * <p>A diferencia de la implementación anterior (que sólo heredaba la
 * sustitución genérica de {@link SubstitutionMethod} y por lo tanto nunca
 * mostraba el procedimiento real de "por partes", cayendo casi siempre a
 * integración numérica de Gauss-Legendre), esta clase resuelve simbólicamente los
 * casos clásicos de LIATE mediante integración por partes tabular:</p>
 * <ul>
 *   <li>x^n · sin(k x)  y  x^n · cos(k x)</li>
 *   <li>x^n · e^(k x)   (también escrito exp(k x))</li>
 *   <li>x^n · ln(k x)   (también log(k x))</li>
 * </ul>
 * Si la expresión no calza con ninguno de estos patrones (por ejemplo,
 * porque el producto es de una función sin antiderivada elemental como
 * x^2·tan(x)) se delega en la estrategia heredada, tal como antes.
 */
public class IntegrationByPartsMethod extends SubstitutionMethod {

    private static final int MAX_GRADO = 6;
    private static final double[] PUNTOS_VALIDACION = {0.4, 0.9, 1.3, 1.8, -0.5, -1.1};
    private static final double H = 1e-4;

    @Override
    public MetodoIntegracion getMethod() {
        return MetodoIntegracion.INTEGRACION_POR_PARTES;
    }

    @Override
    public boolean canHandle(String function, TipoFuncion tipo) {
        String f = function == null ? "" : function.toLowerCase();
        boolean patronProducto = f.contains("*")
                && (f.contains("ln") || f.contains("log") || f.contains("exp")
                    || f.contains("sin") || f.contains("cos") || f.contains("e^"));
        return tipo == TipoFuncion.MIXTA || patronProducto;
    }

    @Override
    public int prioridad() {
        return 25;
    }

    @Override
    public ResultadoIntegral integrate(String function) {
        try {
            ResultadoIntegral propio = intentarPorPartes(function);
            if (propio != null) return propio;
        } catch (Exception ignored) {
            // Cualquier fallo inesperado del parser tabular: se cae al motor heredado.
        }
        return super.integrate(function);
    }

    // -----------------------------------------------------------------------
    // Intento de resolución simbólica real (tabular)
    // -----------------------------------------------------------------------
    private ResultadoIntegral intentarPorPartes(String funcionOriginal) {
        if (funcionOriginal == null || funcionOriginal.trim().isEmpty()) return null;

        String f = funcionOriginal.trim().replaceAll("\\s+", "");
        // Multiplicación implícita: 3x -> 3*x, 2sin -> 2*sin
        f = f.replaceAll("(\\d)(\\(|[a-zA-Z])", "$1*$2");

        double signoGlobal = 1;
        if (f.startsWith("-")) { signoGlobal = -1; f = f.substring(1); }
        else if (f.startsWith("+")) { f = f.substring(1); }

        // Sólo se maneja un término único (sin sumas/restas de nivel superior);
        // si la expresión combina varios sumandos, se deja que el motor por
        // término se encargue (linealidad de la integral).
        if (tieneSumaDeNivelSuperior(f)) return null;

        // Copia normalizada (multiplicación implícita ya resuelta) para la
        // validación numérica posterior — evita que exp4j falle al parsear
        // algo como "3x^2*sin(x)" si el usuario no escribió el '*' explícito.
        final String fNormalizadoSinSigno = f;

        List<String> factores = splitFactoresTopLevel(f);
        double coef = signoGlobal;
        List<String> resto = new ArrayList<>();
        for (String fac : factores) {
            if (fac.matches("^-?\\d+\\.?\\d*$")) {
                coef *= Double.parseDouble(fac);
            } else {
                resto.add(fac);
            }
        }

        Integer n = null;
        String[] trans = null; // {tipo, kStr}

        if (resto.size() == 2) {
            Integer n0 = parsePotenciaX(resto.get(0));
            String[] t0 = parseTranscendente(resto.get(1));
            if (n0 != null && t0 != null) { n = n0; trans = t0; }
            if (n == null) {
                Integer n1 = parsePotenciaX(resto.get(1));
                String[] t1 = parseTranscendente(resto.get(0));
                if (n1 != null && t1 != null) { n = n1; trans = t1; }
            }
        } else if (resto.size() == 1) {
            String[] t0 = parseTranscendente(resto.get(0));
            if (t0 != null) { n = 0; trans = t0; }
        }

        if (n == null || trans == null) return null;
        if (n < 0 || n > MAX_GRADO) return null;

        String tipoTrans = trans[0];
        double k = Double.parseDouble(trans[1]);
        if (k == 0) return null;

        Resultado calculo;
        if (tipoTrans.equals("ln")) {
            calculo = porPartesLn(coef, n, k);
        } else {
            calculo = porPartesTabular(coef, n, k, tipoTrans);
        }
        if (calculo == null) return null;

        // Validación numérica: se deriva la antiderivada propuesta y se
        // compara contra la función original en varios puntos, para evitar
        // presentar un resultado incorrecto si algún caso límite no se
        // contempló bien.
        String funcionCompleta = (signoGlobal < 0 ? "-1*(" : "(") + fNormalizadoSinSigno + ")";
        if (!validar(funcionCompleta, calculo.antiderivadaExpr)) return null;

        List<String[]> terminos = new ArrayList<>();
        String termOrig = termToLatexSimple(funcionOriginal);
        terminos.add(new String[]{termOrig, calculo.antiderivadaLatex,
                "Integración por partes (tabular): \\int u\\,dv=uv-\\int v\\,du"});

        return new ResultadoIntegral(
                calculo.antiderivadaLatex, calculo.antiderivadaExpr, true, false, null, terminos);
    }

    private static String funcionOriginalSinSigno(String original) {
        String s = original.trim();
        if (s.startsWith("-") || s.startsWith("+")) return s.substring(1);
        return s;
    }

    // -----------------------------------------------------------------------
    // Caso x^n * ln(k x)  (o log(k x))
    // ∫ x^n ln(kx) dx = x^(n+1)/(n+1) * ln(kx) - x^(n+1)/(n+1)^2 + C   (n != -1)
    // -----------------------------------------------------------------------
    private Resultado porPartesLn(double coef, int n, double k) {
        double exp = n + 1;
        String kx = fmtKx(k);
        String kxEval = fmtKxEval(k);

        String c1Latex = AntiderivativeEngine.pasarAFraccionLatex(coef / exp);
        String c1Eval = AntiderivativeEngine.fmtExacto(coef / exp);
        String c2Latex = AntiderivativeEngine.pasarAFraccionLatex(coef / (exp * exp));
        String c2Eval = AntiderivativeEngine.fmtExacto(coef / (exp * exp));

        String xExpLatex = (exp == 1) ? "x" : "x^{" + AntiderivativeEngine.fmt(exp) + "}";
        String xExpEval = (exp == 1) ? "x" : "x^(" + AntiderivativeEngine.fmt(exp) + ")";

        String latex = "(" + c1Latex + ")" + xExpLatex + "\\ln(" + kx + ")-(" + c2Latex + ")" + xExpLatex;
        String eval = "(" + c1Eval + ")*" + xExpEval + "*log(" + kxEval + ")-(" + c2Eval + ")*" + xExpEval;
        return new Resultado(latex, eval);
    }

    // -----------------------------------------------------------------------
    // Caso x^n * sin(kx) / cos(kx) / e^(kx)  — integración por partes tabular
    // ∫ u dv = Σ_{i=0}^{n} (-1)^i D_i(x) · V_{i+1}(x)
    // D_i = coef * n!/(n-i)! · x^{n-i}      (derivadas sucesivas de u = coef·x^n)
    // V_m = antiderivada m-ésima de dv
    // -----------------------------------------------------------------------
    private Resultado porPartesTabular(double coef, int n, double k, String tipo) {
        StringBuilder latex = new StringBuilder();
        StringBuilder eval = new StringBuilder();
        boolean primero = true;

        double coefD = coef;
        for (int i = 0; i <= n; i++) {
            int m = i + 1;
            int potenciaX = n - i;

            String funcName; // "sin", "cos", "sinh", "cosh" o "exp"
            double extraSigno;
            if (tipo.equals("exp")) {
                funcName = "exp";
                extraSigno = 1;
            } else if (tipo.equals("sin")) {
                switch (m % 4) {
                    case 1: funcName = "cos"; extraSigno = -1; break;
                    case 2: funcName = "sin"; extraSigno = -1; break;
                    case 3: funcName = "cos"; extraSigno = 1; break;
                    default: funcName = "sin"; extraSigno = 1; break;
                }
            } else if (tipo.equals("cos")) {
                switch (m % 4) {
                    case 1: funcName = "sin"; extraSigno = 1; break;
                    case 2: funcName = "cos"; extraSigno = -1; break;
                    case 3: funcName = "sin"; extraSigno = -1; break;
                    default: funcName = "cos"; extraSigno = 1; break;
                }
            } else if (tipo.equals("sinh")) {
                // d/dx cosh = sinh, d/dx sinh = cosh: ciclo de 2, sin cambio de signo
                funcName = (m % 2 == 1) ? "cosh" : "sinh";
                extraSigno = 1;
            } else { // cosh
                funcName = (m % 2 == 1) ? "sinh" : "cosh";
                extraSigno = 1;
            }

            double signoTermino = Math.pow(-1, i) * extraSigno;
            double coefTermino = signoTermino * coefD / Math.pow(k, m);
            if (Math.abs(coefTermino) < 1e-14) { coefD *= (n - i); continue; }

            String kx = fmtKx(k);
            String kxEval = fmtKxEval(k);
            String funcLatex = (funcName.equals("exp") ? "e^{" + kx + "}" : "\\" + funcName + "(" + kx + ")");
            String funcEval = (funcName.equals("exp") ? "exp(" + kxEval + ")" : funcName + "(" + kxEval + ")");

            String xPartLatex = potenciaX == 0 ? "" : (potenciaX == 1 ? "x" : "x^{" + potenciaX + "}");
            String xPartEval = potenciaX == 0 ? "" : (potenciaX == 1 ? "x" : "x^(" + potenciaX + ")");

            boolean neg = coefTermino < 0;
            double mag = Math.abs(coefTermino);
            String coefLatex = AntiderivativeEngine.pasarAFraccionLatex(mag);
            String coefEval = AntiderivativeEngine.fmtExacto(mag);

            String piezaLatex = (coefLatex.equals("1") ? "" : coefLatex) + xPartLatex + funcLatex;
            String piezaEval = "(" + coefEval + ")" + (xPartEval.isEmpty() ? "" : "*" + xPartEval) + "*" + funcEval;

            if (primero) {
                latex.append(neg ? "-" : "").append(piezaLatex);
                eval.append(neg ? "-" : "").append(piezaEval);
                primero = false;
            } else {
                latex.append(neg ? "-" : "+").append(piezaLatex);
                eval.append(neg ? "-" : "+").append(piezaEval);
            }

            coefD *= (n - i);
        }

        if (primero) { // todos los términos se anularon (no debería ocurrir en la práctica)
            latex.append("0"); eval.append("0");
        }

        return new Resultado(latex.toString(), eval.toString());
    }

    // -----------------------------------------------------------------------
    // Parsing auxiliar
    // -----------------------------------------------------------------------

    /** true si hay un '+' o '-' fuera de todo paréntesis (varios sumandos). */
    private static boolean tieneSumaDeNivelSuperior(String s) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (depth == 0 && (c == '+' || c == '-')) return true;
        }
        return false;
    }

    private static List<String> splitFactoresTopLevel(String s) {
        List<String> out = new ArrayList<>();
        int depth = 0, inicio = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (depth == 0 && c == '*') {
                out.add(s.substring(inicio, i));
                inicio = i + 1;
            }
        }
        out.add(s.substring(inicio));
        return out;
    }

    /** Reconoce "x", "x^n" o "x^(n)" con n entero entre 0 y MAX_GRADO. */
    private static Integer parsePotenciaX(String s) {
        if (s.equals("x")) return 1;
        Matcher m = Pattern.compile("^x\\^\\(?(-?\\d+)\\)?$").matcher(s);
        if (m.matches()) {
            return Integer.parseInt(m.group(1));
        }
        return null;
    }

    /** Reconoce sin/cos/exp/e^/ln/log aplicados a "x" o a "k*x". Devuelve {tipo, k}. */
    private static String[] parseTranscendente(String s) {
        Matcher m;
        m = Pattern.compile("^sin\\((.+)\\)$").matcher(s);
        if (m.matches()) { Double k = kLineal(m.group(1)); return k == null ? null : new String[]{"sin", String.valueOf(k)}; }
        m = Pattern.compile("^cos\\((.+)\\)$").matcher(s);
        if (m.matches()) { Double k = kLineal(m.group(1)); return k == null ? null : new String[]{"cos", String.valueOf(k)}; }
        m = Pattern.compile("^(?:exp|e\\^)\\((.+)\\)$").matcher(s);
        if (m.matches()) { Double k = kLineal(m.group(1)); return k == null ? null : new String[]{"exp", String.valueOf(k)}; }
        m = Pattern.compile("^(?:ln|log)\\((.+)\\)$").matcher(s);
        if (m.matches()) { Double k = kLineal(m.group(1)); return k == null ? null : new String[]{"ln", String.valueOf(k)}; }
        m = Pattern.compile("^sinh\\((.+)\\)$").matcher(s);
        if (m.matches()) { Double k = kLineal(m.group(1)); return k == null ? null : new String[]{"sinh", String.valueOf(k)}; }
        m = Pattern.compile("^cosh\\((.+)\\)$").matcher(s);
        if (m.matches()) { Double k = kLineal(m.group(1)); return k == null ? null : new String[]{"cosh", String.valueOf(k)}; }
        return null;
    }

    /** "x" -> 1.0 ; "k*x" -> k ; cualquier otra cosa -> null (no es lineal simple). */
    private static Double kLineal(String inner) {
        if (inner.equals("x")) return 1.0;
        Matcher m = Pattern.compile("^(-?\\d+\\.?\\d*)\\*x$").matcher(inner);
        if (m.matches()) return Double.parseDouble(m.group(1));
        return null;
    }

    private static String fmtKx(double k) {
        if (Math.abs(k - 1.0) < 1e-12) return "x";
        if (Math.abs(k + 1.0) < 1e-12) return "-x";
        return AntiderivativeEngine.pasarAFraccionLatex(k) + "x";
    }

    private static String fmtKxEval(double k) {
        if (Math.abs(k - 1.0) < 1e-12) return "x";
        return "(" + AntiderivativeEngine.fmtExacto(k) + ")*x";
    }

    /** Conversión simple a LaTeX legible del término original (sin resolver funciones). */
    private static String termToLatexSimple(String t) {
        String s = t;
        s = s.replaceAll("\\^\\(([^)]+)\\)", "^{$1}");
        s = s.replaceAll("\\*", "");
        return s;
    }

    // -----------------------------------------------------------------------
    // Validación numérica del resultado propuesto
    // -----------------------------------------------------------------------
    private static boolean validar(String funcionOriginal, String antiderivadaExpr) {
        int ok = 0, total = 0;
        for (double x : PUNTOS_VALIDACION) {
            try {
                double original = new net.objecthunter.exp4j.ExpressionBuilder(funcionOriginal)
                        .variable("x").build().setVariable("x", x).evaluate();
                if (!Double.isFinite(original)) continue;
                double derivada = derivadaNumerica(antiderivadaExpr, x);
                if (!Double.isFinite(derivada)) continue;
                total++;
                double tol = Math.max(2e-2, Math.abs(original) * 3e-2);
                if (Math.abs(derivada - original) < tol) ok++;
            } catch (Exception ignored) {
                // punto fuera de dominio: se descarta
            }
        }
        return total >= 3 && ok == total;
    }

    private static double derivadaNumerica(String expr, double x) {
        net.objecthunter.exp4j.Expression e = new net.objecthunter.exp4j.ExpressionBuilder(expr)
                .variable("x").build();
        double f1 = e.setVariable("x", x + H).evaluate();
        double f2 = e.setVariable("x", x - H).evaluate();
        return (f1 - f2) / (2 * H);
    }

    /** Resultado interno de un cálculo tabular. */
    private static final class Resultado {
        final String antiderivadaLatex;
        final String antiderivadaExpr;
        Resultado(String latex, String expr) {
            this.antiderivadaLatex = latex;
            this.antiderivadaExpr = expr;
        }
    }
}